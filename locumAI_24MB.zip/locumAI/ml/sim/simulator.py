"""LocumIQ Agent-Based Marketplace Simulator.
Generates 24 months of synthetic history across facilities, locums, and shifts
with embedded ground-truth effects (price elasticity, seasonality, injected pay gap).
"""
import os
import json
import math
import random
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd

SPECIALTIES = [
    "GP", "Emergency", "Anesthesia", "OBG",
    "Pediatrics", "Radiology", "Nursing-ICU", "Nursing-Ward"
]

BASE_MARKET_RATES = {
    "GP": 3500,
    "Emergency": 5500,
    "Anesthesia": 7000,
    "OBG": 6000,
    "Pediatrics": 5000,
    "Radiology": 6500,
    "Nursing-ICU": 2500,
    "Nursing-Ward": 2000,
}

TIERS = ["metro", "tier-2", "rural"]
TIER_WEIGHTS = [0.45, 0.35, 0.20]
TIER_MULTIPLIERS = {"metro": 1.30, "tier-2": 1.00, "rural": 0.85}

GROUND_TRUTH = {
    "true_price_elasticity": -0.35,       # 10% rate increase -> ~3.5% faster fill
    "true_rate_effect_per_500": -2.5,     # -2.5 hours per ₹500 increase
    "injected_gender_pay_gap": -250.0,    # Injected residual gap in female rate quotes
    "monsoon_surge_multiplier": 1.35,     # Coastal emergency/ICU demand surge
    "max_consecutive_nights_limit": 4,    # Hard safety constraint
    "min_rest_hours_limit": 11,           # Hard safety constraint
    "max_weekly_hours_limit": 60,         # Hard safety constraint
}


class MarketplaceSimulator:
    def __init__(self, seed: int = 42, n_facilities: int = 150, n_locums: int = 2000):
        self.seed = seed
        self.n_facilities = n_facilities
        self.n_locums = n_locums
        random.seed(seed)
        np.random.seed(seed)

    def generate_facilities(self) -> pd.DataFrame:
        facilities = []
        for i in range(self.n_facilities):
            tier = random.choices(TIERS, weights=TIER_WEIGHTS)[0]
            base_rel = min(0.99, max(0.65, np.random.beta(12, 2)))
            f = {
                "id": f"fac_{i+1:04d}",
                "name": f"Hospital {i+1} ({tier.capitalize()})",
                "tier": tier,
                "latent_reliability": round(float(base_rel), 3),
                "payment_delay_days": round(float(np.random.gamma(2, 2))),
                "acuity_ratio": round(float(np.random.uniform(0.15, 0.40)), 2),
                "avg_opd_load": int(np.random.randint(20, 70)),
            }
            facilities.append(f)
        return pd.DataFrame(facilities)

    def generate_locums(self) -> pd.DataFrame:
        locums = []
        for i in range(self.n_locums):
            spec = random.choice(SPECIALTIES)
            exp_yrs = int(np.clip(np.random.exponential(5) + 1, 1, 35))
            gender = random.choice(["F", "M"])
            latent_rel = min(0.99, max(0.70, np.random.beta(15, 2)))
            locums.append({
                "id": f"loc_{i+1:05d}",
                "name": f"Dr. Locum {i+1}",
                "specialty": spec,
                "gender": gender,
                "experience_years": exp_yrs,
                "latent_reliability": round(float(latent_rel), 3),
                "distance_radius_km": round(float(np.random.uniform(5, 50)), 1),
            })
        return pd.DataFrame(locums)

    def generate_shifts(self, facilities_df: pd.DataFrame, n_shifts: int = 10000) -> pd.DataFrame:
        """Simulates historical shifts over 24 months with embedded seasonal patterns."""
        start_date = datetime(2024, 11, 1)
        shifts = []

        fac_dict = facilities_df.set_index("id").to_dict("index")
        fac_ids = list(fac_dict.keys())

        for s_idx in range(n_shifts):
            day_offset = random.randint(0, 720)
            shift_date = start_date + timedelta(days=day_offset)
            month = shift_date.month

            f_id = random.choice(fac_ids)
            f_info = fac_dict[f_id]
            spec = random.choice(SPECIALTIES)
            base_rate = BASE_MARKET_RATES[spec] * TIER_MULTIPLIERS[f_info["tier"]]

            # Monsoon shock (June - August: months 6, 7, 8)
            is_monsoon = month in [6, 7, 8] and spec in ["Emergency", "Nursing-ICU"]
            surge_mult = GROUND_TRUTH["monsoon_surge_multiplier"] if is_monsoon else 1.0

            # Lead time & shift flags
            lead_time_days = int(np.clip(np.random.exponential(4) + 1, 1, 28))
            is_night = random.random() < 0.35
            is_urgent = lead_time_days <= 2

            # Offered rate variation (market ratio)
            rate_noise = np.random.normal(1.0, 0.15)
            offered_rate = round(base_rate * rate_noise * surge_mult)

            # True fill probability (logistic ground truth)
            rate_ratio = offered_rate / (base_rate * surge_mult)
            lead_effect = min(lead_time_days / 14.0, 1.0) * 0.8
            night_pen = -0.4 if is_night else 0.0
            urgent_pen = -0.3 if is_urgent else 0.0
            tier_pen = -0.2 if f_info["tier"] == "rural" else 0.0

            true_logit = -2.0 + 3.5 * rate_ratio + lead_effect + night_pen + urgent_pen + tier_pen
            true_fill_prob = 1.0 / (1.0 + math.exp(-true_logit))

            filled = random.random() < true_fill_prob
            fill_time_hours = None
            if filled:
                # Time to fill depends causally on rate ratio (elasticity)
                base_hours = 24.0 / max(0.2, rate_ratio)
                fill_time_hours = max(1.0, round(float(np.random.exponential(base_hours)), 1))

            shifts.append({
                "shift_id": f"sh_{s_idx+1:06d}",
                "facility_id": f_id,
                "specialty": spec,
                "tier": f_info["tier"],
                "shift_date": shift_date.strftime("%Y-%m-%d"),
                "lead_time_days": lead_time_days,
                "is_night": is_night,
                "is_urgent": is_urgent,
                "market_base_rate": round(base_rate),
                "offered_rate": offered_rate,
                "rate_ratio": round(rate_ratio, 3),
                "filled": filled,
                "fill_time_hours": fill_time_hours,
                "true_fill_prob": round(true_fill_prob, 4),
            })

        return pd.DataFrame(shifts)

    def run_simulation(self, output_dir: str = "ml/sim") -> Dict[str, str]:
        os.makedirs(output_dir, exist_ok=True)
        print(f"[SIMULATOR] Running LocumIQ Market Simulator (seed={self.seed})...")

        fac_df = self.generate_facilities()
        loc_df = self.generate_locums()
        shifts_df = self.generate_shifts(fac_df, n_shifts=12000)

        fac_path = os.path.join(output_dir, "facilities.parquet")
        loc_path = os.path.join(output_dir, "locums.parquet")
        shifts_path = os.path.join(output_dir, "shifts.parquet")
        truth_path = os.path.join(output_dir, "sim_truth.json")

        # Save to parquet and json
        try:
            fac_df.to_parquet(fac_path)
            loc_df.to_parquet(loc_path)
            shifts_df.to_parquet(shifts_path)
        except Exception:
            # Fallback to csv if pyarrow/fastparquet not available
            fac_df.to_csv(fac_path.replace(".parquet", ".csv"), index=False)
            loc_df.to_csv(loc_path.replace(".parquet", ".csv"), index=False)
            shifts_df.to_csv(shifts_path.replace(".parquet", ".csv"), index=False)

        with open(truth_path, "w", encoding="utf-8") as f:
            json.dump({
                "generated_at": datetime.now().isoformat(),
                "seed": self.seed,
                "n_facilities": len(fac_df),
                "n_locums": len(loc_df),
                "n_shifts": len(shifts_df),
                "fill_rate": round(float(shifts_df["filled"].mean()), 3),
                "ground_truth_effects": GROUND_TRUTH,
            }, f, indent=2)

        print(f"[SUCCESS] Simulation complete! {len(shifts_df)} shifts exported to {output_dir}")
        return {
            "facilities": fac_path,
            "locums": loc_path,
            "shifts": shifts_path,
            "truth": truth_path,
        }


if __name__ == "__main__":
    sim = MarketplaceSimulator()
    sim.run_simulation()
