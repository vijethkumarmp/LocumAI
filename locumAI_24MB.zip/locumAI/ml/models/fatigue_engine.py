"""Fatigue-Safe Engine - Two-Process Sleep Homeostasis & Unbreachable Hard Constraints."""
import math
from typing import Dict, Any, List, Tuple

# Hard safety constraints (Never overridable by statistical models or humans)
MAX_CONSECUTIVE_NIGHTS = 4
MIN_REST_HOURS = 11.0
MAX_WEEKLY_HOURS = 60.0
MAX_DAILY_HOURS = 14.0


class FatigueEngine:
    @staticmethod
    def calculate_continuous_load(
        hours_7d: float,
        consecutive_nights: int,
        hours_24h: float,
        rest_hours_since_last: float,
    ) -> float:
        """Exponential-decay cumulative fatigue score (0.0 to 1.0).
        Borrowing from sleep-science two-process model (Process S homeostatic sleep pressure).
        """
        # Sleep pressure accumulation: asymptotic exponential rise
        sleep_pressure = 1.0 - math.exp(-hours_7d / 40.0)
        # Circadian phase disruption penalty
        circadian_pen = min(consecutive_nights / float(MAX_CONSECUTIVE_NIGHTS), 1.0) * 0.30
        # Acute 24-hour sleep debt
        acute_debt = min(hours_24h / float(MAX_DAILY_HOURS), 1.0) * 0.30
        # Recovery rest factor
        recovery_bonus = max(0.0, (1.0 - rest_hours_since_last / 24.0)) * 0.20 if rest_hours_since_last is not None else 0.10

        score = min(1.0, sleep_pressure * 0.40 + circadian_pen + acute_debt + recovery_bonus)
        return round(float(score), 3)

    @classmethod
    def evaluate_safety(
        cls,
        locum_id: str,
        hours_last_7d: float,
        consecutive_nights: int,
        hours_last_24h: float,
        rest_hours_since_last: float,
        proposed_shift_hours: float = 12.0,
        is_proposed_night: bool = False,
    ) -> Dict[str, Any]:
        """Evaluates shift safety. Returns hard block reasons if violated."""
        block_reasons = []

        # Rule 1: Max consecutive nights
        if consecutive_nights >= MAX_CONSECUTIVE_NIGHTS and is_proposed_night:
            block_reasons.append(
                f"Maximum consecutive night shifts reached ({consecutive_nights}/{MAX_CONSECUTIVE_NIGHTS}). "
                f"Mandatory 24h rest required prior to subsequent night duty."
            )

        # Rule 2: Weekly hour cap
        if (hours_last_7d + proposed_shift_hours) > MAX_WEEKLY_HOURS:
            block_reasons.append(
                f"Weekly hour cap exceeded ({hours_last_7d:.1f}h + {proposed_shift_hours:.1f}h = "
                f"{hours_last_7d + proposed_shift_hours:.1f}h > {MAX_WEEKLY_HOURS}h limit)."
            )

        # Rule 3: Minimum continuous rest period
        if rest_hours_since_last < MIN_REST_HOURS:
            block_reasons.append(
                f"Insufficient rest since prior shift ({rest_hours_since_last:.1f}h < {MIN_REST_HOURS}h minimum mandatory rest)."
            )

        # Rule 4: Daily shift limit
        if (hours_last_24h + proposed_shift_hours) > MAX_DAILY_HOURS:
            block_reasons.append(
                f"Daily working hour ceiling exceeded ({hours_last_24h:.1f}h + {proposed_shift_hours:.1f}h > {MAX_DAILY_HOURS}h limit)."
            )

        score = cls.calculate_continuous_load(
            hours_last_7d, consecutive_nights, hours_last_24h, rest_hours_since_last
        )

        return {
            "locum_id": locum_id,
            "is_safe": len(block_reasons) == 0,
            "fatigue_score": score,
            "block_reasons": block_reasons,
            "consecutive_nights": consecutive_nights,
            "hours_last_7d": hours_last_7d,
            "rest_hours_since_last": rest_hours_since_last,
            "hard_constraints_evaluated": 4,
        }
