"""Two-Sided Bayesian Reliability Engine - Beta-Binomial Posterior and Shrinkage."""
import math
from typing import Dict, Any, List, Tuple


class BayesianReliabilityEngine:
    def __init__(self, prior_a: float = 8.0, prior_b: float = 1.0):
        # Prior Beta(8, 1) encodes empirical prior belief that most professionals are ~89% reliable
        self.prior_a = prior_a
        self.prior_b = prior_b

    def update_beta_binomial(
        self,
        successes: int,
        failures: int,
        time_decay_factor: float = 1.0,
    ) -> Tuple[float, List[float]]:
        """Computes Beta-Binomial posterior mean and 95% credible interval.
        Applies empirical-Bayes prior shrinkage for new users with low sample size.
        """
        adj_successes = successes * time_decay_factor
        adj_failures = failures * time_decay_factor

        post_a = self.prior_a + adj_successes
        post_b = self.prior_b + adj_failures

        # Posterior mean = a / (a + b)
        mean = post_a / (post_a + post_b)

        # Posterior variance
        variance = (post_a * post_b) / ((post_a + post_b) ** 2 * (post_a + post_b + 1))
        std = math.sqrt(variance)

        # 95% Credible Interval (normal approximation to Beta)
        ci_lower = max(0.0, mean - 1.96 * std)
        ci_upper = min(1.0, mean + 1.96 * std)

        return round(float(mean), 3), [round(float(ci_lower), 3), round(float(ci_upper), 3)]

    def score_locum(
        self,
        completed_shifts: int,
        no_shows: int,
        on_time_shifts: int,
        avg_rating: float = 4.8,
    ) -> Dict[str, Any]:
        """Calculates comprehensive reliability score for a locum doctor/nurse."""
        mean, ci = self.update_beta_binomial(completed_shifts, no_shows)
        is_new_user = (completed_shifts + no_shows) < 10

        return {
            "score": mean,
            "credible_interval": ci,
            "n_observations": completed_shifts + no_shows,
            "is_new_user": is_new_user,
            "components": {
                "completion_rate": round(completed_shifts / max(1, completed_shifts + no_shows), 3),
                "on_time_rate": round(on_time_shifts / max(1, completed_shifts), 3),
                "avg_rating": round(avg_rating, 2),
            },
            "plain_language": (
                f"{'New user — shrunk toward population prior. ' if is_new_user else ''}"
                f"Score {mean:.0%} (95% Credible Interval: {ci[0]:.0%}–{ci[1]:.0%}) "
                f"derived from {completed_shifts + no_shows} shifts."
            ),
        }
