"""Causal Rate Elasticity - Double Machine Learning (DML) with Confounder Control."""
import numpy as np
from typing import Dict, Any, Tuple
from sklearn.linear_model import LinearRegression


class DoubleMLElasticityEstimator:
    """Estimates the true causal effect of rate increases on time-to-fill.
    Resolves the Confounder Trap:
      Hospitals offer higher rates on urgent/hard-to-fill shifts.
      Naive OLS treats rate as the cause of long fill times.
      DML residualizes out confounders:
        Y_res = Y - E[Y | Confounders]
        T_res = T - E[T | Confounders]
        Y_res = theta * T_res + epsilon
    """

    def __init__(self):
        self.ground_truth = -2.5  # Hours reduction per ₹500 (from simulator)

    def estimate(
        self,
        rates: np.ndarray,
        fill_times: np.ndarray,
        confounders: np.ndarray,
    ) -> Dict[str, Any]:
        """Runs Double ML residualization vs naive OLS regression."""
        # 1. Naive regression (T -> Y) without confounders
        naive_model = LinearRegression()
        naive_model.fit(rates.reshape(-1, 1), fill_times)
        naive_coef_per_500 = float(naive_model.coef_[0] * 500.0)

        # 2. Double ML stage 1: predict Y from confounders
        model_y = LinearRegression()
        model_y.fit(confounders, fill_times)
        y_residual = fill_times - model_y.predict(confounders)

        # Double ML stage 2: predict T (rates) from confounders
        model_t = LinearRegression()
        model_t.fit(confounders, rates)
        t_residual = rates - model_t.predict(confounders)

        # Stage 3: regressed orthogonal residuals
        dml_model = LinearRegression(fit_intercept=False)
        dml_model.fit(t_residual.reshape(-1, 1), y_residual)
        theta_per_500 = float(dml_model.coef_[0] * 500.0)

        # Approximate 95% confidence interval
        residuals = y_residual - dml_model.predict(t_residual.reshape(-1, 1))
        se = float(np.std(residuals) / (np.std(t_residual) * np.sqrt(len(rates)))) * 500.0
        ci_lower = theta_per_500 - 1.96 * se
        ci_upper = theta_per_500 + 1.96 * se

        ground_truth_in_ci = (ci_lower <= self.ground_truth <= ci_upper)

        return {
            "causal_effect_per_500": round(theta_per_500, 3),
            "ci_95": [round(ci_lower, 3), round(ci_upper, 3)],
            "naive_estimate_per_500": round(naive_coef_per_500, 3),
            "naive_bias_note": "Naive OLS is severely biased by urgency and shift scarcity confounders.",
            "simulator_ground_truth": self.ground_truth,
            "ground_truth_in_ci": ground_truth_in_ci,
            "n_samples": len(rates),
        }
