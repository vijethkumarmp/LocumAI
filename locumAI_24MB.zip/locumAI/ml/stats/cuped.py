"""CUPED Variance Reduction and Sequential Testing (mSPRT) Module."""
import numpy as np
from typing import Dict, Any, Tuple


class CUPEDAdjuster:
    """Applies Controlled-experiment Using Pre-Experiment Data (CUPED) variance reduction.
    Y_cuped = Y - theta * (X - E[X])
    where theta = Cov(Y, X) / Var(X).
    """

    @staticmethod
    def adjust(y_metric: np.ndarray, x_pre_experiment: np.ndarray) -> Tuple[np.ndarray, float]:
        cov_matrix = np.cov(y_metric, x_pre_experiment)
        cov_yx = cov_matrix[0, 1]
        var_x = cov_matrix[1, 1]

        theta = cov_yx / max(var_x, 1e-6)
        x_mean = np.mean(x_pre_experiment)
        y_cuped = y_metric - theta * (x_pre_experiment - x_mean)

        # Variance reduction ratio = 1 - corr^2
        corr = np.corrcoef(y_metric, x_pre_experiment)[0, 1]
        variance_reduction = corr ** 2

        return y_cuped, float(variance_reduction)


class SequentialMSPRT:
    """Wald mixture Sequential Probability Ratio Test (mSPRT) with alpha-spending."""

    @staticmethod
    def check_early_stopping(
        t_stat: float,
        current_n: int,
        alpha: float = 0.05,
    ) -> Dict[str, Any]:
        """Calculates if test statistic crosses the curved alpha-spending boundary."""
        # Standard mixture SPRT boundary approximation: sqrt(2 * log((n+1) / alpha))
        boundary = np.sqrt(2.0 * np.log(max(1.0, current_n / (100.0 * alpha))))
        stop_early = abs(t_stat) > boundary

        return {
            "t_statistic": round(float(t_stat), 3),
            "boundary": round(float(boundary), 3),
            "stop_early": bool(stop_early),
            "current_sample": current_n,
            "verdict": "Reject Null & Stop Early" if stop_early else "Continue Collecting Data",
        }
