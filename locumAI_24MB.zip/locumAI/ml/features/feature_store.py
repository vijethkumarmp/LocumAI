"""LocumIQ Feature Store - Single Code Path for Train & Serve Parity.
Guarantees identical feature extraction across batch offline training and real-time inference.
"""
from typing import Dict, Any, List, Union, Tuple
import numpy as np
import pandas as pd

FEATURE_NAMES = [
    "rate_ratio",
    "lead_time_days",
    "is_night",
    "is_urgent",
    "is_metro",
    "is_rural",
    "specialty_scarcity",
]

SPECIALTY_SCARCITY = {
    "GP": 0.20,
    "Emergency": 0.85,
    "Anesthesia": 0.90,
    "OBG": 0.75,
    "Pediatrics": 0.60,
    "Radiology": 0.80,
    "Nursing-ICU": 0.70,
    "Nursing-Ward": 0.30,
}

BASE_MARKET_RATES = {
    "GP": 3500,
    "Emergency": 5500,
    "Anesthesia": 7000,
    "OBG": 6000,
    "Pediatrics": 5000,
    "Radiology": 6500,
    "Nursing-ICU": 2500,
    "Nursing-Ward": 2000,
}

TIER_MULTIPLIERS = {"metro": 1.30, "tier-2": 1.00, "rural": 0.85}


def compute_market_rate(specialty: str, tier: str) -> float:
    base = BASE_MARKET_RATES.get(specialty, 4000)
    mult = TIER_MULTIPLIERS.get(tier, 1.0)
    return float(base * mult)


def extract_features_single(input_data: Dict[str, Any]) -> np.ndarray:
    """Extracts features for a single real-time serving request."""
    offered_rate = float(input_data.get("offered_rate", 4000))
    specialty = input_data.get("specialty", "GP")
    tier = input_data.get("tier", "metro")

    market_rate = input_data.get("market_rate")
    if not market_rate:
        market_rate = compute_market_rate(specialty, tier)

    rate_ratio = offered_rate / max(market_rate, 100.0)
    lead_time = float(input_data.get("lead_time_days", 3))
    is_night = 1.0 if input_data.get("is_night", False) else 0.0
    is_urgent = 1.0 if input_data.get("is_urgent", lead_time <= 2) else 0.0
    is_metro = 1.0 if tier == "metro" else 0.0
    is_rural = 1.0 if tier == "rural" else 0.0
    scarcity = float(SPECIALTY_SCARCITY.get(specialty, 0.50))

    vec = np.array([
        rate_ratio,
        lead_time,
        is_night,
        is_urgent,
        is_metro,
        is_rural,
        scarcity,
    ], dtype=np.float32)

    return vec


def extract_features_df(df: pd.DataFrame) -> Tuple[np.ndarray, List[str]]:
    """Extracts features for batch dataframe during training."""
    n_rows = len(df)
    features = np.zeros((n_rows, len(FEATURE_NAMES)), dtype=np.float32)

    for i in range(n_rows):
        row = df.iloc[i]
        item = {
            "offered_rate": row["offered_rate"],
            "specialty": row["specialty"],
            "tier": row["tier"],
            "market_rate": row.get("market_base_rate"),
            "lead_time_days": row.get("lead_time_days", 3),
            "is_night": row.get("is_night", False),
            "is_urgent": row.get("is_urgent", False),
        }
        features[i] = extract_features_single(item)

    return features, FEATURE_NAMES
