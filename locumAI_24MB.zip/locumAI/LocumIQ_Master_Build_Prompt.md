# LocumIQ: Master Build Prompt (paste into Claude Code, in an empty repo)

---

## ROLE

You are a principal ML engineer + full-stack architect. Build **LocumIQ**, a predictive staffing exchange for locum doctors/nurses (India-first), as a **complete, deployable, demo-ready product in ONE DAY (about 10 working hours)**. Work autonomously. Do not ask questions; make sensible decisions and log them in `docs/DECISIONS.md`. Commit after every milestone with clear messages. Prefer working end-to-end over breadth: **every feature listed must run on real (simulated) data, be reachable from the UI, and have at least one test.**

## PRODUCT THESIS

Existing locum platforms are job boards. LocumIQ is a marketplace that **forecasts, prices, matches, and protects**: airline-style revenue management + credit-score-style two-sided trust + fatigue-safety guardrails. Every feature is backed by a statistical/ML model with **uncertainty, calibration, and explanations exposed in the UI**.

## HARD CONSTRAINTS

1. **100% free tier / open source.** No paid APIs. LLM features must work with a **rule/template fallback** when no key is present; optionally use Groq/Gemini/OpenRouter free keys via env vars.
2. **Deployable free:** frontend on Vercel/Netlify/Cloudflare Pages; backend (FastAPI + models) on Hugging Face Spaces (Docker) or Render free; DB on Neon/Supabase free Postgres **with SQLite fallback** for local; MLflow local file store (`mlruns/`) with optional DagsHub remote via env.
3. **One-command local run:** `make setup && make seed && make train && make dev` (also `docker compose up`).
4. **Single day scope control:** if a component threatens the schedule, ship the simpler variant listed under "Fallback" and move on.
5. Python 3.11, type hints, `ruff` + `pytest`. TypeScript strict on frontend.
6. Healthcare data is sensitive: **synthetic data only**; no real PII. Add a visible "Synthetic data demo" banner.
7. This is staffing logistics, **not clinical decision-making**. Safety rules (fatigue, credentials) are hard constraints that can never be overridden by a model; humans see and can override soft recommendations with an audit-logged reason.

## TECH STACK (fixed)

- **Frontend:** React 18 + TypeScript + Vite + Tailwind + shadcn/ui + Recharts (+ visx or d3 for fan charts) + TanStack Query + React Router + Framer Motion. Dark/light theme, responsive, accessible (WCAG AA).
- **Backend:** FastAPI + SQLModel/SQLAlchemy + Alembic (or create_all) + Pydantic v2 + JWT auth (roles: `locum`, `facility`, `admin`).
- **Data/ML:** pandas, numpy, scipy, statsmodels, scikit-learn, lightgbm, lifelines, shap, fairlearn, ortools, mapie (conformal), pandera, evidently, mlflow, joblib, optuna (small budgets), faker, networkx. Optional: prophet (fallback statsmodels ETS/SARIMAX), pymc (fallback empirical-Bayes via scipy).
- **MLOps:** MLflow (tracking + registry), Pandera data contracts, lightweight feature store module (single `features/` code path used by both training and serving, with a parity test), GitHub Actions (CI + scheduled retrain), Docker, Evidently drift reports, Prometheus metrics endpoint (`/metrics`), structured JSON logs.
- **Orchestration:** Prefect-free to save time: a `pipelines/` package with plain Python flows + `make` targets + a GitHub Actions cron; each flow is idempotent and logs to MLflow.

## REPO STRUCTURE

```
locumiq/
  apps/
    web/                      # React app
    api/                      # FastAPI app (routers, services, auth, db)
  ml/
    sim/                      # agent-based marketplace simulator
    features/                 # feature definitions (train/serve parity)
    models/                   # one module per model family
    stats/                    # inferential tools (AB test, CUPED, DiD, PSM...)
    optimize/                 # OR-Tools roster + overbooking
    evaluation/               # calibration, fairness, backtests
    registry/                 # promotion gates, model cards
    monitoring/               # drift, performance decay, retrain triggers
  pipelines/                  # ingest, validate, train_all, score_batch, retrain_if_drift
  tests/
  docs/                       # ARCHITECTURE.md, MODEL_CARDS/, DECISIONS.md, DEMO_SCRIPT.md
  .github/workflows/          # ci.yml, retrain.yml
  docker-compose.yml  Makefile  README.md  .env.example
```

## DATA LAYER

### Schema (core tables)
`users, facilities, locums, credentials, shifts, applications, bookings, shift_outcomes, ratings_locum_to_facility, ratings_facility_to_locum, payments, rate_quotes, fatigue_logs, contracts, notifications, nudge_events, model_predictions (audit), audit_log, drift_reports`.

### Simulator (`ml/sim`): the most important component
Build an agent-based simulator producing **24 months of history** (about 150 facilities, 2,000 locums, about 40k shifts). It must embed **known ground-truth effects** so models can be validated against truth:
- Specialties (GP, Emergency, Anesthesia, OBG, Pediatrics, Radiology, Nursing-ICU, Nursing-Ward), tiers (metro/tier-2/rural), facility types.
- Seasonality (dengue/monsoon spikes, festival dips, exam months), weekly cycles, outbreak shocks (regional).
- Fill probability = logistic function of rate-vs-market ratio, lead time, urgency, night flag, location remoteness, facility reliability, specialty scarcity (true price elasticity encoded, so causal estimates can be checked).
- Locum no-show/cancel hazard depends on latent reliability, fatigue, travel distance, notice period.
- Latent facility behaviors (late payment, workload mismatch), gender-neutral base pay with an **injected small pay gap** for the equity auditor to detect.
- Missingness, noise, and mild drift injected on a schedule so monitoring has something to catch (`make drift-demo` shifts the distribution).
- Seeded RNG, config-driven, exports Parquet + loads to DB. Writes a `sim_truth.json` for validation tests.

## STATISTICAL / ML MODULES (implement ALL; each with model card + backtest + UI)

For each: train script, MLflow logging (params, metrics, plots, signature, input example), Pandera contract, unit test, API endpoint, UI surface, model card in `docs/MODEL_CARDS/`.

1. **Vacancy Forecaster:** hierarchical time series per facility/specialty (statsmodels ETS/SARIMAX or Prophet) + **NegBin/Poisson GLM** for gap counts with exogenous regressors (season, outbreak index, leave rate); **survival model (Cox PH / Weibull AFT via lifelines)** for staff turnover; rolling-origin cross-validation; metrics: MASE, sMAPE, pinball loss, interval coverage. UI: **fan chart** with 50/80/95% bands.
2. **Fill-Probability Meter:** LightGBM + **isotonic/Platt calibration**; reliability diagram, Brier, ECE, log-loss, AUC. **Uplift/what-if curve:** probability vs rate (monotone constraint on rate), highlighting "rate needed for 90%". **Conformal prediction** wrapper for interval on time-to-fill. UI: interactive slider that re-queries the model live.
3. **Time-to-Fill:** Kaplan-Meier by segment + Cox/AFT with covariates, concordance index, median fill time with CI.
4. **Fair-Rate Engine:** **quantile regression** (LightGBM quantile + statsmodels QuantReg baseline) for P10/P50/P90 rate band; **empirical-Bayes/hierarchical shrinkage** across specialty×region cells for sparse segments; **hard cap on surge multiplier** (config, default 1.5x) with logged justification; monotonic crossing fix on quantiles; coverage check.
5. **Shadow Roster (probabilistic overbooking):** no-show classifier (calibrated) + **expected-cost optimization** (cost of unfilled shift vs standby retainer) via OR-Tools; show expected coverage ≥ target (e.g., 98%). UI: roster board with standby badges and risk heat.
6. **Bayesian Reliability Score (two-sided):** **Beta-Binomial with empirical-Bayes prior** per cohort (and Normal-Normal for ratings); posterior mean + **95% credible interval**, "new user" shrinkage, time decay; separate scores for locums and facilities (payment delay, cancellation, workload match). UI: score with interval bar and plain-language meaning.
7. **Workload Fingerprint:** regression (patients/shift, acuity share) with prediction intervals + **k-means/GMM facility clustering** with PCA/UMAP-lite 2D map; text summary card ("~38 OPD patients, 22% high acuity, 1 senior backup").
8. **Fatigue-Safe Scheduler:** rule engine (max consecutive nights, min rest hours, weekly hour cap, travel time) as **hard constraints** + a continuous **cumulative fatigue score** (exponential-decay load model, borrowed from sleep-science style two-process model, documented as a simplification) + risk classifier. Unsafe bookings are **blocked with explanation**. UI: fatigue timeline per locum.
9. **Multi-Shift Match Optimizer:** stage 1: two-tower style embeddings (sklearn/TruncatedSVD or small PyTorch-free implementation) + LightGBM **LambdaRank** for candidate ranking; stage 2: **OR-Tools CP-SAT ILP** for whole-roster assignment minimizing cost + travel + fatigue risk, subject to credentials, rest rules, availability, fairness (max share per locum). Show solver status and optimality gap. Metrics: NDCG@k, fill rate, cost vs greedy baseline.
10. **True Net-Pay Calculator:** deterministic engine (gross, TDS slab simulation labeled "illustrative", travel cost, accommodation, insurance) + travel-cost regression. Disclaimer: not tax advice.
11. **Credential Passport + Expiry Graph:** NetworkX graph of credential dependencies/expiries, alert scheduler, **document-anomaly detection (IsolationForest on metadata/OCR-confidence features)**; OCR optional (pytesseract) with mocked fallback.
12. **Contract Risk Scanner:** clause library + retrieval (TF-IDF/BM25 + embeddings if available) + rules + optional free LLM; flags non-compete, payment delay, tail coverage, liability, termination; **evaluated on a small labeled clause set** with precision/recall.
13. **Try-Before-You-Hire Conversion Score:** calibrated logistic/GBM on tenure, ratings, skill adjacency, facility fit; includes **SHAP** explanations.
14. **Pay-Equity Auditor:** OLS/mixed regression of rate on legitimate covariates; residual analysis by gender/region/seniority; **Fairlearn** metrics, bootstrap CIs, Benjamini-Hochschberg multiple-testing correction; must **recover the injected gap** from the simulator (test).
15. **Surge Mode:** spatio-temporal demand forecast (district-level features, outbreak index, lag features) + geofenced candidate list; alert preview in UI map.
16. **Smart Nudges:** **contextual Thompson-sampling bandit** (Beta/linear) per channel×hour; offline replay evaluation vs random baseline; live endpoint + regret chart.
17. **"Why this match?" Explainer:** **SHAP** (global + local) and **counterfactuals** ("+₹300 raises fill chance from 64% to 85%"); waterfall chart in UI.
18. **WhatsApp/Voice Agent (simulated):** chat UI that calls the booking API via tool-calling (LLM if key, else intent-rule fallback); transcripts logged.
19. **Privacy-Preserving Benchmarks:** k-anonymity (k≥5) suppression + **Laplace differential-privacy** noise on aggregates with ε budget tracking; UI shows ε used.
20. **Experimentation Lab (stat toolkit, own page):** A/B test with **CUPED**, **sequential testing (mSPRT or alpha-spending)**, power/MDE calculator, **diff-in-diff**, **propensity-score matching/IPW** for "does higher rate cause faster fill?", bootstrap CIs, Bayesian A/B (Beta posterior, expected loss). Pre-loaded experiments on simulated data with known truth.
21. **Anomaly/Fraud Watch:** facility/locum behavior anomalies (IsolationForest + robust z-scores), e.g., repeated last-minute cancellations, rate outliers.
22. **Causal Rate Elasticity:** estimates elasticity of fill vs rate with confounder control (DML-lite using LightGBM residualization); validate against simulator ground truth.

**Evaluation standard (apply to every model):** time-based splits (no leakage; add a leakage test), baseline comparison, calibration, subgroup metrics, uncertainty, and a **model card** (intended use, data, metrics, limits, fairness, retrain policy).

## MLOPS REQUIREMENTS (must be demonstrable in the UI "MLOps Console")

- **Data contracts:** Pandera schemas on raw and feature tables; failing batch is quarantined with a report.
- **Feature parity:** one `features/` code path for train & serve; test asserts identical outputs.
- **Experiment tracking:** every training run logs to MLflow; Optuna tuning with small budget (≤30 trials, time-boxed).
- **Registry & gates:** challenger auto-promoted to `Production` only if it beats champion on primary metric **and** passes calibration (ECE ≤ threshold), fairness (subgroup gap ≤ threshold), and latency checks; otherwise stays `Staging` with report. One-click **rollback** endpoint.
- **Serving:** FastAPI loads Production models from registry at startup + hot-reload endpoint; every prediction written to `model_predictions` (inputs hash, version, output, latency) for audit and delayed-label evaluation.
- **Release safety:** **shadow mode** (challenger scores logged, not served) → canary percentage → full; configurable per model.
- **Monitoring:** Evidently data & prediction drift (PSI/KS), **rolling calibration/performance decay on delayed ground truth**, latency/error rates via `/metrics`; alert rules in config.
- **Retrain triggers:** drift threshold, schedule, or performance drop → `pipelines/retrain_if_drift.py` → train → gate → promote. `make drift-demo` must visibly trigger this loop end-to-end.
- **CI/CD:** GitHub Actions: lint, type-check, unit tests, data-contract tests, small-sample training smoke test, model-quality gates, Docker build; deploy on main. Scheduled workflow for retrain cron.
- **Governance:** model cards, audit log of every automated decision, human-override logging with reason, reproducible seeds, `requirements.lock`.
- **LLM ops (light):** prompt versions in files, tiny eval set (promptfoo-style in pytest), cost/latency logging, output guardrails.

## FRONTEND: PAGES (all must be real, polished, and wired to the API)

Design language: clean clinical-modern, trustworthy; one accent color; generous whitespace; every number with its uncertainty; loading/empty/error states; keyboard accessible.

**Public:** Landing (value props, live animated fill-probability demo, how it works), Login/Register (role select).

**Facility portal:** Dashboard (KPIs + vacancy fan chart) · Post Shift (live Fill-Probability + Fair-Rate band + what-if slider) · Roster Board (shadow roster, optimizer run with solver stats) · Candidates (ranked, with "Why this match?") · Reliability (own score) · Benchmarks (DP-protected) · Contract Scanner · Pay-Equity report.

**Locum portal:** Shift Feed (with Workload Fingerprint, Net-Pay, fatigue check, facility reliability interval) · Fatigue Timeline · Credential Passport (expiry graph) · Earnings · Agent Chat (WhatsApp-style) · Surge Alerts map.

**Admin:** MLOps Console (experiments, registry stages, promote/rollback, shadow/canary, drift reports, calibration decay, retrain triggers + run history) · Experimentation Lab · Model Cards browser · Fairness dashboard · Audit log · Simulator controls (seed, drift injection, outbreak shock) · System health.

Include a **guided "Demo Mode"** that walks a viewer through the 6 killer moments (fill-probability slider, shadow roster, reliability interval, workload fingerprint, fatigue block, drift→retrain→promote).

## API (minimum)

Auth: `/auth/register|login|me`. Shifts: CRUD + `/shifts/{id}/fill-probability`, `/rate-band`, `/candidates`, `/explain`. Forecast: `/forecast/vacancy`, `/forecast/surge`. Roster: `/roster/optimize`, `/roster/shadow`. Reliability: `/reliability/{locum|facility}/{id}`. Fatigue: `/fatigue/{locum}`, `/fatigue/check`. Net pay: `/netpay`. Credentials: `/credentials/*`, `/credentials/graph`. Contracts: `/contracts/scan`. Equity: `/equity/audit`. Bench: `/benchmarks`. Nudge: `/nudge/decide|feedback`. Agent: `/agent/chat`. Experiments: `/lab/*`. MLOps: `/mlops/models|runs|promote|rollback|drift|retrain|shadow`. Meta: `/health`, `/metrics`. OpenAPI docs complete with examples. Rate limiting + input validation + CORS config + consistent error schema.

## EXECUTION PLAN (strict timebox; commit at each checkpoint)

| Hours | Deliverable |
|---|---|
| 0:00-0:45 | Scaffold repo, Makefile, Docker, CI skeleton, DB models, auth, seed pipeline |
| 0:45-2:15 | Simulator + Parquet export + Pandera contracts + EDA notebook-free report (`docs/DATA_REPORT.md`) |
| 2:15-4:30 | Core models: fill-prob (+calibration), time-to-fill, fair-rate, reliability, forecaster, workload, fatigue. MLflow logging + registry gates |
| 4:30-6:00 | Optimizer (CP-SAT), shadow roster, ranking + SHAP/counterfactuals, net-pay, equity auditor, nudges, DP benchmarks |
| 6:00-7:30 | API wiring for everything, prediction audit log, drift/monitoring + retrain loop, experimentation lab |
| 7:30-9:30 | Frontend: portals, charts, MLOps console, demo mode, polish |
| 9:30-10:30 | Tests, README, architecture diagram (Mermaid), model cards, deploy (Vercel + HF Spaces), record `DEMO_SCRIPT.md` |

If behind schedule, cut in this order (keep the rest): voice/OCR extras → surge map polish → conversion score → anomaly watch → LLM agent (keep rule fallback).
**Never cut:** simulator, fill-probability + calibration, fair-rate, reliability, fatigue blocking, optimizer, MLOps console with drift→retrain→promote loop, experimentation lab.

## ACCEPTANCE CRITERIA (verify and report at the end)

1. `make setup seed train dev` works from a clean clone; `docker compose up` works.
2. Fill-probability ECE < 0.05 and AUC reported on a time-based holdout; reliability diagram visible in UI.
3. Fair-rate band empirical coverage within ±5 points of nominal (e.g., 80% band covers 75-85%).
4. Equity auditor recovers the injected pay gap within its CI (automated test).
5. Causal elasticity estimate's CI contains simulator ground truth; naive estimate shown as biased for contrast.
6. Optimizer beats greedy baseline on cost and fill rate; solver status shown.
7. Fatigue rules block an unsafe booking with a human-readable reason.
8. `make drift-demo` triggers drift alert → retrain → gate → promote/hold, visible in MLOps Console with history.
9. CI passes (lint, tests, contracts, smoke training). Test coverage ≥ 70% on `ml/` and `apps/api/`.
10. Every model has a model card; every UI prediction shows an uncertainty or confidence element.
11. Deployed public URLs (or documented one-command deploy) + README with screenshots/GIF placeholders.

## FINAL OUTPUT

When finished, print: (a) what was built vs cut and why, (b) metrics table for every model, (c) how to run and deploy, (d) known limitations and honest caveats (synthetic data; real pilot data required before any real-world claims), (e) a 5-minute demo script. Be rigorous and honest: do not report a metric you did not compute.

Begin now. Start with the scaffold and the simulator.
