"""Pydantic schemas for request/response validation."""
from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field, ConfigDict


# ── Auth ───────────────────────────────────────────
class UserRegister(BaseModel):
    email: str
    password: str = Field(min_length=6)
    full_name: str
    role: str = "locum"  # locum | facility | admin


class UserLogin(BaseModel):
    email: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


# ── Facility ───────────────────────────────────────
class FacilityOut(BaseModel):
    id: str
    name: str
    facility_type: str
    tier: str
    city: str
    state: str
    district: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    bed_count: Optional[int] = None
    avg_daily_opd: Optional[int] = None
    reliability_score: float

    model_config = ConfigDict(from_attributes=True)


# ── Locum ──────────────────────────────────────────
class LocumOut(BaseModel):
    id: str
    full_name: str
    specialty: str
    experience_years: int
    city: str
    state: str
    reliability_score: float
    cumulative_fatigue: float

    model_config = ConfigDict(from_attributes=True)


# ── Shift ──────────────────────────────────────────
class ShiftCreate(BaseModel):
    specialty: str
    shift_date: date
    start_time: str
    end_time: str
    is_night: bool = False
    is_urgent: bool = False
    offered_rate: float


class ShiftOut(BaseModel):
    id: str
    facility_id: str
    specialty: str
    shift_date: date
    start_time: str
    end_time: str
    is_night: bool
    is_urgent: bool
    offered_rate: float
    market_rate: Optional[float] = None
    status: str
    fill_probability: Optional[float] = None
    lead_time_days: Optional[int] = None
    created_at: datetime
    facility: Optional[FacilityOut] = None

    model_config = ConfigDict(from_attributes=True)


# ── ML Predictions ─────────────────────────────────
class FillProbabilityRequest(BaseModel):
    specialty: str
    tier: str
    offered_rate: float
    market_rate: Optional[float] = None
    lead_time_days: int = 7
    is_night: bool = False
    is_urgent: bool = False


class FillProbabilityResponse(BaseModel):
    probability: float
    confidence_interval: List[float]
    calibrated: bool
    rate_curve: List[dict]  # [{rate, probability}]
    rate_for_90pct: Optional[float] = None
    model_version: str


class RateBandResponse(BaseModel):
    p10: float
    p50: float
    p90: float
    surge_multiplier: float
    surge_capped: bool
    specialty: str
    region: str


class ReliabilityResponse(BaseModel):
    score: float
    credible_interval: List[float]
    n_observations: int
    is_new_user: bool
    components: dict
    plain_language: str


class FatigueCheckResponse(BaseModel):
    is_safe: bool
    fatigue_score: float
    consecutive_nights: int
    hours_last_7d: float
    hours_last_24h: float
    rest_hours_since_last: Optional[float] = None
    block_reasons: List[str]
    timeline: List[dict]


class NetPayResponse(BaseModel):
    gross_amount: float
    tds_amount: float
    travel_cost: float
    accommodation: float
    insurance: float
    net_amount: float
    effective_hourly: float
    disclaimer: str = "Illustrative only. Not tax advice."


class VacancyForecastResponse(BaseModel):
    dates: List[str]
    forecast: List[float]
    lower_50: List[float]
    upper_50: List[float]
    lower_80: List[float]
    upper_80: List[float]
    lower_95: List[float]
    upper_95: List[float]
    metrics: dict


class WorkloadFingerprintResponse(BaseModel):
    avg_patients: float
    acuity_high_pct: float
    acuity_medium_pct: float
    acuity_low_pct: float
    senior_backup: bool
    cluster_label: str
    summary: str
    cluster_map: List[dict]


class MatchExplanation(BaseModel):
    score: float
    rank: int
    shap_values: dict
    counterfactuals: List[dict]
    top_factors: List[dict]


class DriftReportOut(BaseModel):
    id: str
    model_name: str
    report_type: str
    metrics: dict
    is_drifted: bool
    action_taken: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ModelRegistryEntry(BaseModel):
    name: str
    version: str
    stage: str  # None, Staging, Production, Archived
    metrics: dict
    created_at: str
    run_id: str


class ExperimentResult(BaseModel):
    experiment_name: str
    method: str
    effect_size: float
    ci_lower: float
    ci_upper: float
    p_value: Optional[float] = None
    significant: bool
    details: dict
