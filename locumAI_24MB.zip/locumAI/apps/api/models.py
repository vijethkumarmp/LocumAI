"""Database models for LocumIQ."""
import uuid
from datetime import datetime, date
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, Date, Text,
    ForeignKey, Enum, JSON, Index
)
from sqlalchemy.orm import relationship
from apps.api.database import Base
import enum


def gen_uuid():
    return str(uuid.uuid4())


class UserRole(str, enum.Enum):
    LOCUM = "locum"
    FACILITY = "facility"
    ADMIN = "admin"


class ShiftStatus(str, enum.Enum):
    OPEN = "open"
    FILLED = "filled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class BookingStatus(str, enum.Enum):
    CONFIRMED = "confirmed"
    STANDBY = "standby"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"
    COMPLETED = "completed"


class Specialty(str, enum.Enum):
    GP = "GP"
    EMERGENCY = "Emergency"
    ANESTHESIA = "Anesthesia"
    OBG = "OBG"
    PEDIATRICS = "Pediatrics"
    RADIOLOGY = "Radiology"
    NURSING_ICU = "Nursing-ICU"
    NURSING_WARD = "Nursing-Ward"


class FacilityTier(str, enum.Enum):
    METRO = "metro"
    TIER2 = "tier-2"
    RURAL = "rural"


# ── Users ──────────────────────────────────────────
class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=gen_uuid)
    email = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(String, nullable=False, default=UserRole.LOCUM)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ── Facilities ─────────────────────────────────────
class Facility(Base):
    __tablename__ = "facilities"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)
    facility_type = Column(String, nullable=False)  # hospital, clinic, PHC
    tier = Column(String, nullable=False)
    city = Column(String, nullable=False)
    state = Column(String, nullable=False)
    district = Column(String, nullable=False)
    latitude = Column(Float)
    longitude = Column(Float)
    bed_count = Column(Integer)
    avg_daily_opd = Column(Integer)
    reliability_score = Column(Float, default=0.5)
    payment_delay_days = Column(Float, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    shifts = relationship("Shift", back_populates="facility")


# ── Locums ─────────────────────────────────────────
class Locum(Base):
    __tablename__ = "locums"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    full_name = Column(String, nullable=False)
    specialty = Column(String, nullable=False)
    experience_years = Column(Integer, default=0)
    gender = Column(String)
    city = Column(String, nullable=False)
    state = Column(String, nullable=False)
    latitude = Column(Float)
    longitude = Column(Float)
    preferred_radius_km = Column(Float, default=100)
    reliability_score = Column(Float, default=0.5)
    cumulative_fatigue = Column(Float, default=0.0)
    max_weekly_hours = Column(Float, default=60)
    created_at = Column(DateTime, default=datetime.utcnow)
    credentials = relationship("Credential", back_populates="locum")
    bookings = relationship("Booking", back_populates="locum")


# ── Credentials ────────────────────────────────────
class Credential(Base):
    __tablename__ = "credentials"
    id = Column(String, primary_key=True, default=gen_uuid)
    locum_id = Column(String, ForeignKey("locums.id"), nullable=False)
    credential_type = Column(String, nullable=False)  # MCI, state_reg, DEA, etc.
    credential_number = Column(String)
    issued_date = Column(Date)
    expiry_date = Column(Date)
    status = Column(String, default="valid")
    verified = Column(Boolean, default=False)
    depends_on = Column(String, ForeignKey("credentials.id"), nullable=True)
    locum = relationship("Locum", back_populates="credentials")


# ── Shifts ─────────────────────────────────────────
class Shift(Base):
    __tablename__ = "shifts"
    id = Column(String, primary_key=True, default=gen_uuid)
    facility_id = Column(String, ForeignKey("facilities.id"), nullable=False)
    specialty = Column(String, nullable=False)
    shift_date = Column(Date, nullable=False)
    start_time = Column(String, nullable=False)
    end_time = Column(String, nullable=False)
    is_night = Column(Boolean, default=False)
    is_urgent = Column(Boolean, default=False)
    offered_rate = Column(Float, nullable=False)
    market_rate = Column(Float)
    status = Column(String, default=ShiftStatus.OPEN)
    lead_time_days = Column(Integer)
    fill_probability = Column(Float)
    time_to_fill_hours = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    filled_at = Column(DateTime)
    facility = relationship("Facility", back_populates="shifts")
    bookings = relationship("Booking", back_populates="shift")

    __table_args__ = (
        Index("ix_shifts_date_specialty", "shift_date", "specialty"),
        Index("ix_shifts_facility_status", "facility_id", "status"),
    )


# ── Bookings ───────────────────────────────────────
class Booking(Base):
    __tablename__ = "bookings"
    id = Column(String, primary_key=True, default=gen_uuid)
    shift_id = Column(String, ForeignKey("shifts.id"), nullable=False)
    locum_id = Column(String, ForeignKey("locums.id"), nullable=False)
    status = Column(String, default=BookingStatus.CONFIRMED)
    is_standby = Column(Boolean, default=False)
    booked_rate = Column(Float)
    fatigue_score_at_booking = Column(Float)
    fatigue_blocked = Column(Boolean, default=False)
    block_reason = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    shift = relationship("Shift", back_populates="bookings")
    locum = relationship("Locum", back_populates="bookings")


# ── Shift Outcomes ─────────────────────────────────
class ShiftOutcome(Base):
    __tablename__ = "shift_outcomes"
    id = Column(String, primary_key=True, default=gen_uuid)
    booking_id = Column(String, ForeignKey("bookings.id"), nullable=False)
    showed_up = Column(Boolean, default=True)
    patients_seen = Column(Integer)
    acuity_high_pct = Column(Float)
    hours_worked = Column(Float)
    overtime_hours = Column(Float, default=0)
    incident_reported = Column(Boolean, default=False)


# ── Ratings ────────────────────────────────────────
class RatingLocumToFacility(Base):
    __tablename__ = "ratings_locum_to_facility"
    id = Column(String, primary_key=True, default=gen_uuid)
    booking_id = Column(String, ForeignKey("bookings.id"), nullable=False)
    locum_id = Column(String, ForeignKey("locums.id"), nullable=False)
    facility_id = Column(String, ForeignKey("facilities.id"), nullable=False)
    overall = Column(Float, nullable=False)
    workload_accuracy = Column(Float)
    staff_support = Column(Float)
    payment_timeliness = Column(Float)
    comment = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class RatingFacilityToLocum(Base):
    __tablename__ = "ratings_facility_to_locum"
    id = Column(String, primary_key=True, default=gen_uuid)
    booking_id = Column(String, ForeignKey("bookings.id"), nullable=False)
    locum_id = Column(String, ForeignKey("locums.id"), nullable=False)
    facility_id = Column(String, ForeignKey("facilities.id"), nullable=False)
    overall = Column(Float, nullable=False)
    punctuality = Column(Float)
    clinical_skill = Column(Float)
    communication = Column(Float)
    comment = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Payments ───────────────────────────────────────
class Payment(Base):
    __tablename__ = "payments"
    id = Column(String, primary_key=True, default=gen_uuid)
    booking_id = Column(String, ForeignKey("bookings.id"), nullable=False)
    gross_amount = Column(Float, nullable=False)
    tds_amount = Column(Float, default=0)
    travel_allowance = Column(Float, default=0)
    net_amount = Column(Float, nullable=False)
    status = Column(String, default="pending")
    due_date = Column(Date)
    paid_date = Column(Date)
    delay_days = Column(Integer, default=0)


# ── Rate Quotes ────────────────────────────────────
class RateQuote(Base):
    __tablename__ = "rate_quotes"
    id = Column(String, primary_key=True, default=gen_uuid)
    shift_id = Column(String, ForeignKey("shifts.id"))
    specialty = Column(String, nullable=False)
    region = Column(String, nullable=False)
    tier = Column(String, nullable=False)
    p10 = Column(Float)
    p50 = Column(Float)
    p90 = Column(Float)
    surge_multiplier = Column(Float, default=1.0)
    computed_at = Column(DateTime, default=datetime.utcnow)


# ── Fatigue Logs ───────────────────────────────────
class FatigueLog(Base):
    __tablename__ = "fatigue_logs"
    id = Column(String, primary_key=True, default=gen_uuid)
    locum_id = Column(String, ForeignKey("locums.id"), nullable=False)
    date = Column(Date, nullable=False)
    cumulative_score = Column(Float, nullable=False)
    consecutive_nights = Column(Integer, default=0)
    hours_last_7d = Column(Float, default=0)
    hours_last_24h = Column(Float, default=0)
    rest_hours_since_last = Column(Float)
    is_safe = Column(Boolean, default=True)
    reason = Column(Text)


# ── Model Predictions (Audit) ─────────────────────
class ModelPrediction(Base):
    __tablename__ = "model_predictions"
    id = Column(String, primary_key=True, default=gen_uuid)
    model_name = Column(String, nullable=False, index=True)
    model_version = Column(String)
    input_hash = Column(String)
    input_data = Column(JSON)
    output_data = Column(JSON)
    latency_ms = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Audit Log ──────────────────────────────────────
class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    action = Column(String, nullable=False)
    entity_type = Column(String)
    entity_id = Column(String)
    details = Column(JSON)
    human_override = Column(Boolean, default=False)
    override_reason = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Drift Reports ─────────────────────────────────
class DriftReport(Base):
    __tablename__ = "drift_reports"
    id = Column(String, primary_key=True, default=gen_uuid)
    model_name = Column(String, nullable=False)
    report_type = Column(String)  # data_drift, prediction_drift, performance_decay
    metrics = Column(JSON)
    is_drifted = Column(Boolean, default=False)
    action_taken = Column(String)  # retrain, alert, none
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Nudge Events ──────────────────────────────────
class NudgeEvent(Base):
    __tablename__ = "nudge_events"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    channel = Column(String)  # push, sms, email, whatsapp
    hour_bucket = Column(Integer)
    nudge_type = Column(String)
    arm_selected = Column(String)
    reward = Column(Float)  # 1=clicked, 0=ignored
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Contracts ──────────────────────────────────────
class Contract(Base):
    __tablename__ = "contracts"
    id = Column(String, primary_key=True, default=gen_uuid)
    facility_id = Column(String, ForeignKey("facilities.id"))
    locum_id = Column(String, ForeignKey("locums.id"))
    contract_text = Column(Text)
    risk_flags = Column(JSON)
    risk_score = Column(Float)
    scanned_at = Column(DateTime, default=datetime.utcnow)


# ── Notifications ─────────────────────────────────
class Notification(Base):
    __tablename__ = "notifications"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    title = Column(String, nullable=False)
    body = Column(Text)
    notification_type = Column(String)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
