"""Fatigue router - safety checks and timeline."""
import random
import math
from datetime import datetime, timedelta
from fastapi import APIRouter
from apps.api.schemas import FatigueCheckResponse

router = APIRouter()

# Hard safety constraints (never overridable by model)
MAX_CONSECUTIVE_NIGHTS = 4
MIN_REST_HOURS = 11
MAX_WEEKLY_HOURS = 60
MAX_DAILY_HOURS = 14


def _fatigue_score(hours_7d: float, consecutive_nights: int, hours_24h: float, rest_since_last: float) -> float:
    """Exponential-decay cumulative fatigue score (0-1, higher = more fatigued).
    Simplified two-process model (Process S: sleep homeostasis)."""
    # Sleep pressure accumulation
    sleep_pressure = 1 - math.exp(-hours_7d / 40)
    # Night shift impact
    circadian_disruption = min(consecutive_nights / MAX_CONSECUTIVE_NIGHTS, 1.0) * 0.3
    # Acute fatigue
    acute = min(hours_24h / MAX_DAILY_HOURS, 1.0) * 0.3
    # Recovery factor
    recovery = max(0, 1 - rest_since_last / 24) * 0.2 if rest_since_last is not None else 0.1

    score = min(1.0, sleep_pressure * 0.4 + circadian_disruption + acute + recovery)
    return round(score, 3)


@router.get("/{locum_id}", response_model=FatigueCheckResponse)
def fatigue_check(locum_id: str, proposed_hours: float = 12, proposed_night: bool = False):
    """Check if a locum can safely take a shift. Hard constraints block unsafe bookings."""
    # Simulated recent history
    consecutive_nights = random.randint(0, 5)
    hours_7d = random.uniform(20, 65)
    hours_24h = random.uniform(0, 16)
    rest_since = random.uniform(4, 24)

    # Safety check
    block_reasons = []
    if consecutive_nights >= MAX_CONSECUTIVE_NIGHTS and proposed_night:
        block_reasons.append(
            f"⛔ Maximum consecutive night shifts reached ({consecutive_nights}/{MAX_CONSECUTIVE_NIGHTS}). "
            f"Minimum 24h rest required before next night shift."
        )
    if hours_7d + proposed_hours > MAX_WEEKLY_HOURS:
        block_reasons.append(
            f"⛔ Weekly hour cap exceeded ({hours_7d:.0f}h + {proposed_hours:.0f}h = {hours_7d + proposed_hours:.0f}h > {MAX_WEEKLY_HOURS}h limit)."
        )
    if rest_since < MIN_REST_HOURS:
        block_reasons.append(
            f"⛔ Insufficient rest since last shift ({rest_since:.1f}h < {MIN_REST_HOURS}h minimum)."
        )
    if hours_24h + proposed_hours > MAX_DAILY_HOURS:
        block_reasons.append(
            f"⛔ Daily hour limit exceeded ({hours_24h:.0f}h + {proposed_hours:.0f}h > {MAX_DAILY_HOURS}h)."
        )

    score = _fatigue_score(hours_7d, consecutive_nights, hours_24h, rest_since)
    is_safe = len(block_reasons) == 0

    # Generate 14-day timeline
    timeline = []
    base_date = datetime.now() - timedelta(days=14)
    for i in range(14):
        d = base_date + timedelta(days=i)
        day_hours = random.uniform(0, 14) if random.random() > 0.3 else 0
        day_score = _fatigue_score(
            random.uniform(15, 55), random.randint(0, 3), day_hours, random.uniform(8, 20)
        )
        timeline.append({
            "date": d.strftime("%Y-%m-%d"),
            "hours_worked": round(day_hours, 1),
            "fatigue_score": day_score,
            "is_night": random.random() > 0.7,
            "is_rest_day": day_hours == 0,
        })

    return FatigueCheckResponse(
        is_safe=is_safe,
        fatigue_score=score,
        consecutive_nights=consecutive_nights,
        hours_last_7d=round(hours_7d, 1),
        hours_last_24h=round(hours_24h, 1),
        rest_hours_since_last=round(rest_since, 1),
        block_reasons=block_reasons,
        timeline=timeline,
    )
