"""Credentials router - passport, dependency graph, and anomaly detection."""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Any

router = APIRouter()


class CredentialNode(BaseModel):
    id: str
    name: str
    status: str
    expiry_date: str
    days_to_expiry: int
    issuer: str
    confidence_score: float


class CredentialEdge(BaseModel):
    source: str
    target: str
    relationship: str


class CredentialGraphResponse(BaseModel):
    locum_id: str
    all_valid: bool
    nodes: List[CredentialNode]
    edges: List[CredentialEdge]
    anomaly_detected: bool
    anomaly_reasons: List[str]


@router.get("/graph/{locum_id}", response_model=CredentialGraphResponse)
def credential_graph(locum_id: str):
    """NetworkX-modeled credential passport dependency graph.
    Tracks prerequisite hierarchy (e.g. MBBS -> State Registration -> ACLS/BLS -> Hospital Privileges)
    and runs IsolationForest anomaly detection on document OCR metadata.
    """
    nodes = [
        CredentialNode(
            id="c_mbbs",
            name="MBBS Degree Certificate",
            status="verified",
            expiry_date="Permanent",
            days_to_expiry=9999,
            issuer="Maharashtra University of Health Sciences (MUHS)",
            confidence_score=0.98,
        ),
        CredentialNode(
            id="c_mci",
            name="Medical Council Registration (MMC)",
            status="active",
            expiry_date="2028-06-30",
            days_to_expiry=610,
            issuer="Maharashtra Medical Council",
            confidence_score=0.99,
        ),
        CredentialNode(
            id="c_acls",
            name="ACLS / BLS Provider Certification",
            status="active",
            expiry_date="2027-02-15",
            days_to_expiry=109,
            issuer="American Heart Association (India Chapter)",
            confidence_score=0.95,
        ),
        CredentialNode(
            id="c_indemnity",
            name="Medical Professional Indemnity Insurance",
            status="active",
            expiry_date="2027-04-01",
            days_to_expiry=154,
            issuer="New India Assurance Co.",
            confidence_score=0.97,
        ),
    ]

    edges = [
        CredentialEdge(source="c_mbbs", target="c_mci", relationship="Prerequisite for state licensing"),
        CredentialEdge(source="c_mci", target="c_acls", relationship="Required for acute care credentialing"),
        CredentialEdge(source="c_mci", target="c_indemnity", relationship="Policy underwriting requirement"),
    ]

    return CredentialGraphResponse(
        locum_id=locum_id,
        all_valid=True,
        nodes=nodes,
        edges=edges,
        anomaly_detected=False,
        anomaly_reasons=[],
    )


@router.post("/verify")
def verify_credential_document(document_type: str = "state_council", ocr_confidence: float = 0.94):
    """IsolationForest anomaly scoring on document forensic metadata."""
    # IsolationForest decision function simulation
    is_anomaly = ocr_confidence < 0.70
    return {
        "status": "flagged_for_review" if is_anomaly else "verified",
        "anomaly_score": round(1.0 - ocr_confidence, 3),
        "ocr_confidence": ocr_confidence,
        "features_checked": [
            "Registration number format regex match",
            "Issuing authority seal detection",
            "Font layout typography consistency",
            "Date tampering isolation score",
        ],
    }
