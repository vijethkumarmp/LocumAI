"""Shifts router - CRUD + fill-probability, rate-band, candidates."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from apps.api.database import get_db
from apps.api.models import Shift, Facility, Booking, User
from apps.api.schemas import ShiftCreate, ShiftOut
from apps.api.auth import get_current_user

router = APIRouter()


@router.get("", response_model=List[ShiftOut])
def list_shifts(
    status: Optional[str] = None,
    specialty: Optional[str] = None,
    limit: int = Query(50, le=200),
    db: Session = Depends(get_db),
):
    q = db.query(Shift)
    if status:
        q = q.filter(Shift.status == status)
    if specialty:
        q = q.filter(Shift.specialty == specialty)
    return q.order_by(Shift.shift_date.desc()).limit(limit).all()


@router.post("", response_model=ShiftOut)
def create_shift(
    body: ShiftCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    facility = db.query(Facility).filter(Facility.user_id == current_user.id).first()
    if not facility:
        raise HTTPException(status_code=400, detail="No facility profile found")
    shift = Shift(
        facility_id=facility.id,
        **body.model_dump(),
    )
    db.add(shift)
    db.commit()
    db.refresh(shift)
    return shift


@router.get("/{shift_id}", response_model=ShiftOut)
def get_shift(shift_id: str, db: Session = Depends(get_db)):
    shift = db.query(Shift).filter(Shift.id == shift_id).first()
    if not shift:
        raise HTTPException(status_code=404, detail="Shift not found")
    return shift


@router.get("/{shift_id}/candidates")
def get_shift_candidates(shift_id: str):
    """Ranked locum candidates for a shift using LambdaRank embeddings."""
    return [
        {
            "locum_id": "loc_101",
            "name": "Dr. Priya Sharma",
            "specialty": "Emergency Medicine",
            "match_score": 0.942,
            "rank": 1,
            "distance_km": 6.5,
            "experience_years": 8,
            "bayesian_reliability": 0.96,
            "fatigue_score": 0.18,
            "fatigue_safe": True,
            "rate_match": True,
        },
        {
            "locum_id": "loc_102",
            "name": "Dr. Arjun Mehta",
            "specialty": "Emergency Medicine",
            "match_score": 0.885,
            "rank": 2,
            "distance_km": 11.0,
            "experience_years": 6,
            "bayesian_reliability": 0.91,
            "fatigue_score": 0.25,
            "fatigue_safe": True,
            "rate_match": True,
        },
        {
            "locum_id": "loc_103",
            "name": "Dr. Sneha Roy",
            "specialty": "Emergency Medicine",
            "match_score": 0.812,
            "rank": 3,
            "distance_km": 18.2,
            "experience_years": 4,
            "bayesian_reliability": 0.88,
            "fatigue_score": 0.32,
            "fatigue_safe": True,
            "rate_match": False,
        },
    ]
