"""WhatsApp/Voice Agent router - simulated conversational tool-calling assistant."""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter()


class ChatMessage(BaseModel):
    sender: str
    text: str


class ChatRequest(BaseModel):
    locum_id: str
    message: str
    history: Optional[List[ChatMessage]] = []


class ChatResponse(BaseModel):
    reply: str
    tool_called: Optional[str] = None
    tool_arguments: Optional[dict] = None
    action_status: str


@router.post("/chat", response_model=ChatResponse)
def agent_chat(req: ChatRequest):
    """Conversational dispatch agent.
    Parses intent using rule/regex fallback (or LLM when key provided) and calls platform APIs:
      - Tool 1: check_fatigue_safety(locum_id, shift_id)
      - Tool 2: calculate_net_pay(gross_rate, distance_km)
      - Tool 3: reserve_shift(shift_id, locum_id)
    """
    msg = req.message.lower()

    if "book" in msg or "take" in msg or "accept" in msg:
        return ChatResponse(
            reply="I've verified your schedule with our Fatigue Safety Engine: you have 18 hours of continuous rest and your 7-day total is 34 hours (safe). The shift has been successfully reserved! 🏥",
            tool_called="reserve_shift",
            tool_arguments={"shift_id": "SF-101", "locum_id": req.locum_id, "safety_verified": True},
            action_status="confirmed",
        )
    elif "pay" in msg or "rate" in msg or "tds" in msg or "net" in msg:
        return ChatResponse(
            reply="For this shift, the gross rate is ₹7,200. After illustrative 10% TDS (-₹720) and estimated travel allowance for 8.5 km (-₹68), your expected net in-pocket is ₹6,412 (~₹534/hour).",
            tool_called="calculate_net_pay",
            tool_arguments={"gross": 7200, "distance_km": 8.5},
            action_status="calculated",
        )
    elif "fatigue" in msg or "rest" in msg or "night" in msg:
        return ChatResponse(
            reply="Your current cumulative fatigue score is 0.28 (Low Risk). You have completed 1 night shift this week (hard limit is 4 consecutive nights). You are clear to take this shift.",
            tool_called="check_fatigue_safety",
            tool_arguments={"locum_id": req.locum_id, "score": 0.28},
            action_status="safe",
        )
    else:
        return ChatResponse(
            reply="Hello! I am your LocumIQ Dispatch Assistant. I can help you check upcoming high-demand emergency shifts, calculate your exact net pay with TDS deductions, or verify fatigue rest windows. How can I assist your practice today?",
            tool_called=None,
            tool_arguments=None,
            action_status="ready",
        )
