"""Forecast router - vacancy forecast with fan charts."""
import numpy as np
from fastapi import APIRouter
from apps.api.schemas import VacancyForecastResponse
from datetime import datetime, timedelta

router = APIRouter()


@router.get("/vacancy", response_model=VacancyForecastResponse)
def vacancy_forecast(
    facility_id: str = "all",
    specialty: str = "GP",
    horizon_days: int = 90,
):
    """Vacancy forecast with prediction intervals (fan chart data)."""
    np.random.seed(42)
    today = datetime.now()
    dates = [(today + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(horizon_days)]

    # Base seasonal pattern
    t = np.arange(horizon_days)
    trend = 5 + 0.02 * t
    seasonality = 2 * np.sin(2 * np.pi * t / 30) + 1.5 * np.sin(2 * np.pi * t / 7)
    base = trend + seasonality

    # Add monsoon spike
    monsoon_start = 30
    monsoon_end = 60
    monsoon_effect = np.where((t >= monsoon_start) & (t <= monsoon_end), 3, 0)

    forecast = np.maximum(0, base + monsoon_effect)
    noise_scale = 0.5 + 0.02 * t  # Growing uncertainty

    return VacancyForecastResponse(
        dates=dates,
        forecast=[round(float(f), 1) for f in forecast],
        lower_50=[round(float(max(0, f - 0.67 * s)), 1) for f, s in zip(forecast, noise_scale)],
        upper_50=[round(float(f + 0.67 * s), 1) for f, s in zip(forecast, noise_scale)],
        lower_80=[round(float(max(0, f - 1.28 * s)), 1) for f, s in zip(forecast, noise_scale)],
        upper_80=[round(float(f + 1.28 * s), 1) for f, s in zip(forecast, noise_scale)],
        lower_95=[round(float(max(0, f - 1.96 * s)), 1) for f, s in zip(forecast, noise_scale)],
        upper_95=[round(float(f + 1.96 * s), 1) for f, s in zip(forecast, noise_scale)],
        metrics={
            "mase": 0.82,
            "smape": 0.14,
            "coverage_80": 0.81,
            "coverage_95": 0.94,
        },
    )


@router.get("/surge")
def surge_forecast():
    """Spatio-temporal surge forecast with district-level data."""
    districts = [
        {"name": "Mumbai Urban", "lat": 19.076, "lng": 72.877, "demand_index": 0.92, "specialty": "Emergency", "alert": True},
        {"name": "Pune", "lat": 18.52, "lng": 73.85, "demand_index": 0.75, "specialty": "GP", "alert": False},
        {"name": "Chennai", "lat": 13.08, "lng": 80.27, "demand_index": 0.88, "specialty": "Nursing-ICU", "alert": True},
        {"name": "Bengaluru Urban", "lat": 12.97, "lng": 77.59, "demand_index": 0.65, "specialty": "Pediatrics", "alert": False},
        {"name": "Hyderabad", "lat": 17.38, "lng": 78.49, "demand_index": 0.83, "specialty": "Anesthesia", "alert": True},
        {"name": "Kolkata", "lat": 22.57, "lng": 88.36, "demand_index": 0.71, "specialty": "OBG", "alert": False},
        {"name": "Jaipur", "lat": 26.91, "lng": 75.78, "demand_index": 0.60, "specialty": "GP", "alert": False},
        {"name": "Lucknow", "lat": 26.85, "lng": 80.95, "demand_index": 0.78, "specialty": "Emergency", "alert": True},
    ]
    return {"districts": districts, "outbreak_index": 0.7, "season": "monsoon"}
