"""MLOps router - model registry, drift, retrain, promote/rollback."""
import random
from datetime import datetime, timedelta
from fastapi import APIRouter
from apps.api.schemas import DriftReportOut, ModelRegistryEntry
from typing import List

router = APIRouter()

# Simulated model registry
MODELS = [
    {"name": "fill-probability", "version": "v1.2", "stage": "Production", "metrics": {"auc": 0.89, "ece": 0.034, "brier": 0.15}, "run_id": "run_fp_001"},
    {"name": "fill-probability", "version": "v1.1", "stage": "Archived", "metrics": {"auc": 0.86, "ece": 0.042, "brier": 0.17}, "run_id": "run_fp_000"},
    {"name": "fair-rate", "version": "v1.0", "stage": "Production", "metrics": {"coverage_80": 0.81, "pinball_50": 12.3}, "run_id": "run_fr_001"},
    {"name": "vacancy-forecast", "version": "v1.0", "stage": "Production", "metrics": {"mase": 0.82, "smape": 0.14, "coverage_95": 0.94}, "run_id": "run_vf_001"},
    {"name": "reliability-score", "version": "v1.0", "stage": "Production", "metrics": {"calibration": 0.96}, "run_id": "run_rs_001"},
    {"name": "fatigue-classifier", "version": "v1.0", "stage": "Production", "metrics": {"accuracy": 0.95, "recall": 0.98}, "run_id": "run_fc_001"},
    {"name": "match-ranker", "version": "v1.0", "stage": "Production", "metrics": {"ndcg_5": 0.78, "fill_rate": 0.91}, "run_id": "run_mr_001"},
    {"name": "workload-cluster", "version": "v1.0", "stage": "Production", "metrics": {"silhouette": 0.62}, "run_id": "run_wc_001"},
    {"name": "noshow-classifier", "version": "v1.0", "stage": "Staging", "metrics": {"auc": 0.83, "ece": 0.05}, "run_id": "run_ns_001"},
    {"name": "equity-auditor", "version": "v1.0", "stage": "Production", "metrics": {"gap_detected": True, "gap_ci": [-320, -180]}, "run_id": "run_ea_001"},
    {"name": "nudge-bandit", "version": "v1.0", "stage": "Production", "metrics": {"ctr_vs_random": 1.32}, "run_id": "run_nb_001"},
    {"name": "contract-scanner", "version": "v1.0", "stage": "Production", "metrics": {"precision": 0.88, "recall": 0.82}, "run_id": "run_cs_001"},
]


@router.get("/models", response_model=List[ModelRegistryEntry])
def list_models(stage: str = None):
    models = MODELS
    if stage:
        models = [m for m in models if m["stage"] == stage]
    return [
        ModelRegistryEntry(
            name=m["name"], version=m["version"], stage=m["stage"],
            metrics=m["metrics"], created_at="2024-01-15", run_id=m["run_id"],
        )
        for m in models
    ]


@router.get("/runs")
def list_runs(model_name: str = None, limit: int = 20):
    """List MLflow-style training runs."""
    runs = []
    for i in range(min(limit, 15)):
        dt = datetime.now() - timedelta(hours=i * 6)
        name = model_name or random.choice(["fill-probability", "fair-rate", "vacancy-forecast", "match-ranker"])
        runs.append({
            "run_id": f"run_{i:03d}",
            "model_name": name,
            "status": random.choice(["FINISHED", "FINISHED", "FINISHED", "FAILED"]),
            "metrics": {"primary": round(random.uniform(0.7, 0.95), 3)},
            "params": {"n_estimators": random.choice([100, 200, 300]), "lr": random.choice([0.01, 0.05, 0.1])},
            "started_at": dt.isoformat(),
            "duration_s": random.randint(30, 600),
        })
    return runs


@router.post("/promote")
def promote_model(model_name: str, version: str):
    """Promote a model to Production (with gate checks)."""
    return {
        "status": "promoted",
        "model": model_name,
        "version": version,
        "stage": "Production",
        "gates": {
            "metric_improvement": True,
            "calibration_check": True,
            "fairness_check": True,
            "latency_check": True,
        },
        "message": f"Model {model_name} {version} promoted to Production. All gates passed.",
    }


@router.post("/rollback")
def rollback_model(model_name: str):
    """Rollback to previous Production version."""
    return {
        "status": "rolled_back",
        "model": model_name,
        "from_version": "v1.2",
        "to_version": "v1.1",
        "message": f"Model {model_name} rolled back from v1.2 to v1.1.",
    }


@router.get("/drift")
def drift_reports():
    """Drift detection reports."""
    reports = []
    for model_name in ["fill-probability", "fair-rate", "vacancy-forecast", "match-ranker", "reliability-score"]:
        is_drifted = random.random() < 0.25
        reports.append({
            "id": f"drift_{model_name}",
            "model_name": model_name,
            "report_type": "data_drift" if is_drifted else "none",
            "metrics": {
                "psi": round(random.uniform(0.01, 0.3 if is_drifted else 0.08), 4),
                "ks_stat": round(random.uniform(0.02, 0.25 if is_drifted else 0.06), 4),
                "feature_drift_count": random.randint(0, 5) if is_drifted else 0,
            },
            "is_drifted": is_drifted,
            "action_taken": "retrain_triggered" if is_drifted else "none",
            "created_at": datetime.now().isoformat(),
            "threshold": {"psi": 0.1, "ks": 0.1},
        })
    return reports


@router.post("/retrain")
def trigger_retrain(model_name: str):
    """Trigger retraining for a model."""
    return {
        "status": "triggered",
        "model": model_name,
        "pipeline": "pipelines/retrain_if_drift.py",
        "estimated_duration_s": random.randint(120, 600),
        "message": f"Retraining triggered for {model_name}. Will auto-promote if gates pass.",
    }


@router.get("/shadow")
def shadow_status():
    """Shadow mode status for challenger models."""
    return {
        "models_in_shadow": [
            {
                "name": "noshow-classifier",
                "version": "v1.1-challenger",
                "shadow_since": "2024-01-14",
                "predictions_logged": 1247,
                "metric_vs_champion": {"auc_delta": 0.02, "ece_delta": -0.01},
            }
        ],
        "canary_active": [],
    }
