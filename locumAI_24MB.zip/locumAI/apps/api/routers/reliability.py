"""Reliability router - Bayesian reliability scores."""
import random
from fastapi import APIRouter
from apps.api.schemas import ReliabilityResponse

router = APIRouter()


def _beta_binomial_score(successes: int, failures: int, prior_a: float = 2.0, prior_b: float = 2.0):
    """Beta-Binomial posterior with empirical-Bayes prior."""
    a = prior_a + successes
    b = prior_b + failures
    mean = a / (a + b)
    # 95% credible interval (approximation)
    from math import sqrt
    var = (a * b) / ((a + b) ** 2 * (a + b + 1))
    std = sqrt(var)
    ci = [round(max(0, mean - 1.96 * std), 3), round(min(1, mean + 1.96 * std), 3)]
    return round(mean, 3), ci


@router.get("/locum/{locum_id}", response_model=ReliabilityResponse)
def locum_reliability(locum_id: str):
    """Bayesian reliability score for a locum."""
    # Simulated data
    n_shifts = random.randint(5, 120)
    n_shows = int(n_shifts * random.uniform(0.85, 0.99))
    n_noshows = n_shifts - n_shows
    score, ci = _beta_binomial_score(n_shows, n_noshows)
    is_new = n_shifts < 10

    return ReliabilityResponse(
        score=score,
        credible_interval=ci,
        n_observations=n_shifts,
        is_new_user=is_new,
        components={
            "show_rate": round(n_shows / n_shifts, 3) if n_shifts > 0 else 0,
            "on_time_rate": round(random.uniform(0.88, 0.99), 3),
            "rating_avg": round(random.uniform(3.8, 4.9), 2),
            "cancellation_rate": round(random.uniform(0.01, 0.12), 3),
        },
        plain_language=f"{'New user — limited data. ' if is_new else ''}Score {score:.0%} (95% CI: {ci[0]:.0%}–{ci[1]:.0%}) based on {n_shifts} completed shifts. {'Highly reliable.' if score > 0.9 else 'Above average.' if score > 0.8 else 'Some reliability concerns.'}",
    )


@router.get("/facility/{facility_id}", response_model=ReliabilityResponse)
def facility_reliability(facility_id: str):
    """Bayesian reliability score for a facility."""
    n_bookings = random.randint(20, 300)
    n_timely = int(n_bookings * random.uniform(0.7, 0.98))
    n_late = n_bookings - n_timely
    score, ci = _beta_binomial_score(n_timely, n_late)

    return ReliabilityResponse(
        score=score,
        credible_interval=ci,
        n_observations=n_bookings,
        is_new_user=n_bookings < 15,
        components={
            "payment_timeliness": round(random.uniform(0.75, 0.99), 3),
            "workload_accuracy": round(random.uniform(0.7, 0.95), 3),
            "cancellation_rate": round(random.uniform(0.02, 0.15), 3),
            "rating_avg": round(random.uniform(3.5, 4.8), 2),
        },
        plain_language=f"Score {score:.0%} (95% CI: {ci[0]:.0%}–{ci[1]:.0%}) based on {n_bookings} bookings. Payment timeliness is {'excellent' if score > 0.9 else 'good' if score > 0.8 else 'a concern'}.",
    )
