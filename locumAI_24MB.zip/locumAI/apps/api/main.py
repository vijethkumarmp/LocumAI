"""LocumIQ FastAPI Application - Main Entry Point."""
import os
import time
import json
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from apps.api.database import init_db
from apps.api.routers import (
    auth, shifts, predictions, mlops, forecast, reliability, fatigue,
    experiments, roster, credentials, contracts, equity, benchmarks, nudge, agent
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("locumiq")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown."""
    logger.info("🚀 LocumIQ starting up…")
    init_db()
    logger.info("✅ Database initialized")
    yield
    logger.info("🛑 LocumIQ shutting down")


app = FastAPI(
    title="LocumIQ API",
    description="Predictive Staffing Exchange for Locum Healthcare Workers",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Logging middleware ──────────────────────────────
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    elapsed = (time.time() - start) * 1000
    logger.info(json.dumps({
        "method": request.method,
        "path": str(request.url.path),
        "status": response.status_code,
        "latency_ms": round(elapsed, 2),
    }))
    return response


# ── Routers ─────────────────────────────────────────
app.include_router(auth.router, prefix="/api/auth", tags=["Auth"])
app.include_router(shifts.router, prefix="/api/shifts", tags=["Shifts"])
app.include_router(predictions.router, prefix="/api", tags=["Predictions"])
app.include_router(mlops.router, prefix="/api/mlops", tags=["MLOps"])
app.include_router(forecast.router, prefix="/api/forecast", tags=["Forecast"])
app.include_router(reliability.router, prefix="/api/reliability", tags=["Reliability"])
app.include_router(fatigue.router, prefix="/api/fatigue", tags=["Fatigue"])
app.include_router(experiments.router, prefix="/api/lab", tags=["Experiments"])
app.include_router(roster.router, prefix="/api/roster", tags=["Roster"])
app.include_router(credentials.router, prefix="/api/credentials", tags=["Credentials"])
app.include_router(contracts.router, prefix="/api/contracts", tags=["Contracts"])
app.include_router(equity.router, prefix="/api/equity", tags=["Equity"])
app.include_router(benchmarks.router, prefix="/api/benchmarks", tags=["Benchmarks"])
app.include_router(nudge.router, prefix="/api/nudge", tags=["Nudge"])
app.include_router(agent.router, prefix="/api/agent", tags=["Agent"])


@app.get("/health")
@app.get("/api/health")
def health():
    return {"status": "healthy", "version": "1.0.0", "service": "LocumIQ"}


@app.get("/api/metrics")
def metrics():
    return {
        "requests_total": 0,
        "predictions_total": 0,
        "models_loaded": 0,
        "drift_alerts": 0,
    }
