import React, { Suspense, lazy } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'

const Landing = lazy(() => import('./pages/Landing'))
const Dashboard = lazy(() => import('./pages/Dashboard'))
const FillProbability = lazy(() => import('./pages/FillProbability'))
const ForecastPage = lazy(() => import('./pages/ForecastPage'))
const FatiguePage = lazy(() => import('./pages/FatiguePage'))
const ReliabilityPage = lazy(() => import('./pages/ReliabilityPage'))
const MLOpsConsole = lazy(() => import('./pages/MLOpsConsole'))
const ExperimentsLab = lazy(() => import('./pages/ExperimentsLab'))
const RosterBoard = lazy(() => import('./pages/RosterBoard'))
const ShiftFeed = lazy(() => import('./pages/ShiftFeed'))
const CredentialPassport = lazy(() => import('./pages/CredentialPassport'))
const SurgeAlertsMap = lazy(() => import('./pages/SurgeAlertsMap'))

function LoadingFallback() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4" />
        <p className="text-text-secondary text-sm">Loading module…</p>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route element={<Layout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/fill-probability" element={<FillProbability />} />
          <Route path="/forecast" element={<ForecastPage />} />
          <Route path="/fatigue" element={<FatiguePage />} />
          <Route path="/reliability" element={<ReliabilityPage />} />
          <Route path="/mlops" element={<MLOpsConsole />} />
          <Route path="/experiments" element={<ExperimentsLab />} />
          <Route path="/roster" element={<RosterBoard />} />
          <Route path="/shifts" element={<ShiftFeed />} />
          <Route path="/credentials" element={<CredentialPassport />} />
          <Route path="/surge-map" element={<SurgeAlertsMap />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  )
}
