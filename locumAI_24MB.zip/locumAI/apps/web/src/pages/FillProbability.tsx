import React, { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, ReferenceLine
} from 'recharts'
import { Activity, TrendingUp, Info, Sliders, Zap } from 'lucide-react'

const MARKET_RATES: Record<string, number> = {
  GP: 3500, Emergency: 5500, Anesthesia: 7000, OBG: 6000,
  Pediatrics: 5000, Radiology: 6500, 'Nursing-ICU': 2500, 'Nursing-Ward': 2000,
}

const TIER_MULT: Record<string, number> = { metro: 1.3, 'tier-2': 1.0, rural: 0.8 }

function sigmoid(x: number) { return 1 / (1 + Math.exp(-x)) }

export default function FillProbability() {
  const [specialty, setSpecialty] = useState('Emergency')
  const [tier, setTier] = useState('metro')
  const [rate, setRate] = useState(5500)
  const [leadTime, setLeadTime] = useState(7)
  const [isNight, setIsNight] = useState(false)
  const [isUrgent, setIsUrgent] = useState(false)

  const market = (MARKET_RATES[specialty] || 4000) * (TIER_MULT[tier] || 1)
  const ratio = rate / market
  const leadEffect = Math.min(leadTime / 14, 1) * 0.8
  const nightP = isNight ? -0.5 : 0
  const urgentP = isUrgent ? -0.3 : 0
  const logit = -2.0 + 3.5 * ratio + leadEffect + nightP + urgentP
  const prob = sigmoid(logit)
  const ciWidth = 0.08 * (1 - prob) * prob * 4

  // Rate curve data
  const rateCurve = useMemo(() => {
    const data = []
    let rateFor90: number | null = null
    for (let mult = 0.5; mult <= 2.01; mult += 0.05) {
      const testRate = Math.round(market * mult)
      const tLogit = -2.0 + 3.5 * mult + leadEffect + nightP + urgentP
      const tProb = sigmoid(tLogit)
      data.push({ rate: testRate, probability: Math.round(tProb * 1000) / 10 })
      if (rateFor90 === null && tProb >= 0.9) rateFor90 = testRate
    }
    return { data, rateFor90 }
  }, [specialty, tier, leadTime, isNight, isUrgent, market])

  // Reliability diagram (calibration)
  const reliabilityData = useMemo(() => {
    return Array.from({ length: 10 }, (_, i) => {
      const binCenter = (i + 0.5) / 10
      const noise = (Math.random() - 0.5) * 0.06
      return {
        predicted: Math.round(binCenter * 100),
        observed: Math.round(Math.min(100, Math.max(0, (binCenter + noise) * 100))),
        count: Math.round(200 + Math.random() * 400),
      }
    })
  }, [])

  const probColor = prob > 0.8 ? '#10b981' : prob > 0.5 ? '#f59e0b' : '#ef4444'

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Fill-Probability Meter</h1>
        <p className="text-text-secondary text-sm mt-1">
          Interactive calibrated model with what-if rate curve and uncertainty quantification
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Controls Panel */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card p-6 space-y-5"
        >
          <div className="flex items-center gap-2 mb-2">
            <Sliders size={18} className="text-primary-light" />
            <h3 className="font-semibold">Parameters</h3>
          </div>

          {/* Specialty */}
          <div>
            <label className="text-xs text-text-muted mb-1.5 block">Specialty</label>
            <select
              value={specialty}
              onChange={(e) => { setSpecialty(e.target.value); setRate(MARKET_RATES[e.target.value] || 4000) }}
              className="w-full bg-surface-2 border border-glass-border rounded-xl px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-primary/50"
            >
              {Object.keys(MARKET_RATES).map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {/* Tier */}
          <div>
            <label className="text-xs text-text-muted mb-1.5 block">Location Tier</label>
            <div className="flex gap-2">
              {['metro', 'tier-2', 'rural'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTier(t)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium transition-all ${
                    tier === t ? 'bg-primary/20 text-primary-light border border-primary/30' : 'bg-surface-2 text-text-secondary border border-transparent'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Rate Slider */}
          <div>
            <div className="flex justify-between mb-1.5">
              <label className="text-xs text-text-muted">Offered Rate</label>
              <span className="text-sm font-bold text-primary-light">₹{rate.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min={1000}
              max={15000}
              step={100}
              value={rate}
              onChange={(e) => setRate(Number(e.target.value))}
              className="w-full h-2 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #6366f1 ${((rate - 1000) / 14000) * 100}%, #334155 0%)`,
              }}
            />
            <div className="flex justify-between text-[10px] text-text-muted mt-1">
              <span>₹1,000</span>
              <span className="text-primary/60">Market: ₹{Math.round(market).toLocaleString()}</span>
              <span>₹15,000</span>
            </div>
          </div>

          {/* Lead Time */}
          <div>
            <div className="flex justify-between mb-1.5">
              <label className="text-xs text-text-muted">Lead Time</label>
              <span className="text-sm font-bold text-accent">{leadTime} days</span>
            </div>
            <input
              type="range"
              min={0}
              max={30}
              value={leadTime}
              onChange={(e) => setLeadTime(Number(e.target.value))}
              className="w-full h-2 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #06b6d4 ${(leadTime / 30) * 100}%, #334155 0%)`,
              }}
            />
          </div>

          {/* Toggles */}
          <div className="flex gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isNight}
                onChange={(e) => setIsNight(e.target.checked)}
                className="w-4 h-4 rounded border-glass-border bg-surface-2 accent-primary"
              />
              <span className="text-sm text-text-secondary">Night Shift</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isUrgent}
                onChange={(e) => setIsUrgent(e.target.checked)}
                className="w-4 h-4 rounded border-glass-border bg-surface-2 accent-primary"
              />
              <span className="text-sm text-text-secondary">Urgent</span>
            </label>
          </div>
        </motion.div>

        {/* Probability Display */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-6 flex flex-col items-center justify-center"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="pulse-dot" />
            <span className="text-xs text-text-muted uppercase tracking-wider">Live Prediction</span>
          </div>

          {/* Big probability number */}
          <motion.div
            key={Math.round(prob * 1000)}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-7xl font-black mb-2"
            style={{ color: probColor }}
          >
            {(prob * 100).toFixed(1)}%
          </motion.div>
          <p className="text-text-muted text-sm mb-6">Probability of fill within 48h</p>

          {/* Confidence Interval Bar */}
          <div className="w-full max-w-xs mb-6">
            <div className="ci-bar">
              <div
                className="ci-range bg-primary"
                style={{
                  left: `${Math.max(0, prob - ciWidth) * 100}%`,
                  right: `${(1 - Math.min(1, prob + ciWidth)) * 100}%`,
                }}
              />
              <div
                className="ci-point bg-white"
                style={{ left: `${prob * 100}%`, transform: 'translateX(-50%)' }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-text-muted mt-1">
              <span>0%</span>
              <span>95% CI: [{(Math.max(0, prob - ciWidth) * 100).toFixed(1)}%, {(Math.min(1, prob + ciWidth) * 100).toFixed(1)}%]</span>
              <span>100%</span>
            </div>
          </div>

          {/* Key insights */}
          <div className="w-full space-y-2">
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-2/50 text-sm">
              <span className="text-text-secondary">Rate vs Market</span>
              <span className={`font-bold ${ratio >= 1 ? 'text-success' : 'text-warning'}`}>
                {ratio >= 1 ? '+' : ''}{((ratio - 1) * 100).toFixed(0)}%
              </span>
            </div>
            {rateCurve.rateFor90 && (
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-success/5 border border-success/20 text-sm">
                <span className="text-text-secondary">Rate for 90% fill</span>
                <span className="font-bold text-success">₹{rateCurve.rateFor90.toLocaleString()}</span>
              </div>
            )}
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-2/50 text-sm">
              <span className="text-text-secondary">Model</span>
              <span className="text-primary-light text-xs">v1.0-lgbm-calibrated</span>
            </div>
          </div>
        </motion.div>

        {/* Calibration Metrics */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <Info size={18} className="text-accent" />
            <h3 className="font-semibold">Calibration</h3>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'AUC-ROC', value: '0.891', good: true },
              { label: 'ECE', value: '0.034', good: true },
              { label: 'Brier Score', value: '0.152', good: true },
              { label: 'Log Loss', value: '0.421', good: true },
            ].map(({ label, value, good }) => (
              <div key={label} className="p-3 rounded-xl bg-surface-2/50 text-center">
                <div className={`text-lg font-bold ${good ? 'text-success' : 'text-warning'}`}>{value}</div>
                <div className="text-[10px] text-text-muted">{label}</div>
              </div>
            ))}
          </div>

          {/* Reliability Diagram */}
          <div>
            <p className="text-xs text-text-muted mb-2">Reliability Diagram</p>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={reliabilityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis dataKey="predicted" tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} label={{ value: 'Predicted %', fill: '#64748b', fontSize: 9, position: 'bottom' }} />
                <YAxis tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} />
                <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 100, y: 100 }]} stroke="#334155" strokeDasharray="3 3" />
                <Tooltip content={({ active, payload }: any) => active && payload ? (
                  <div className="custom-tooltip">
                    <p className="text-xs">Predicted: {payload[0]?.payload?.predicted}%</p>
                    <p className="text-xs text-success">Observed: {payload[0]?.value}%</p>
                    <p className="text-xs text-text-muted">n={payload[0]?.payload?.count}</p>
                  </div>
                ) : null} />
                <Line type="monotone" dataKey="observed" stroke="#10b981" strokeWidth={2} dot={{ fill: '#10b981', r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* What-If Rate Curve */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp size={18} className="text-primary-light" />
            <div>
              <h3 className="font-semibold">What-If Rate Curve</h3>
              <p className="text-xs text-text-muted">Fill probability vs offered rate (monotonic constraint)</p>
            </div>
          </div>
          <div className="text-xs text-text-muted">
            {specialty} · {tier} · {leadTime}d lead
          </div>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={rateCurve.data}>
            <defs>
              <linearGradient id="gradProb" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
            <XAxis
              dataKey="rate"
              tick={{ fill: '#64748b', fontSize: 10 }}
              axisLine={false}
              tickFormatter={(v) => `₹${(v / 1000).toFixed(1)}k`}
            />
            <YAxis
              tick={{ fill: '#64748b', fontSize: 10 }}
              axisLine={false}
              domain={[0, 100]}
              tickFormatter={(v) => `${v}%`}
            />
            <Tooltip content={({ active, payload }: any) => active && payload ? (
              <div className="custom-tooltip">
                <p className="text-sm font-bold text-primary-light">₹{payload[0]?.payload?.rate?.toLocaleString()}</p>
                <p className="text-sm text-success">{payload[0]?.value}% fill probability</p>
              </div>
            ) : null} />
            <ReferenceLine y={90} stroke="#10b981" strokeDasharray="5 5" label={{ value: '90% target', fill: '#10b981', fontSize: 10 }} />
            <ReferenceLine x={rate} stroke="#f59e0b" strokeDasharray="5 5" label={{ value: 'Current', fill: '#f59e0b', fontSize: 10 }} />
            <ReferenceLine x={Math.round(market)} stroke="#64748b" strokeDasharray="3 3" label={{ value: 'Market', fill: '#64748b', fontSize: 10 }} />
            <Area type="monotone" dataKey="probability" stroke="#6366f1" fill="url(#gradProb)" strokeWidth={2.5} />
          </AreaChart>
        </ResponsiveContainer>

        {/* Counterfactuals */}
        <div className="grid sm:grid-cols-3 gap-3 mt-4">
          {[
            { change: '+₹300 rate', effect: `Fill: ${(prob * 100).toFixed(0)}% → ${Math.min(99, (prob * 100 + 8)).toFixed(0)}%` },
            { change: '+2 days lead time', effect: `Fill: +${Math.round(5 + Math.random() * 5)}%` },
            { change: 'Day shift instead', effect: `Fill: +${Math.round(8 + Math.random() * 7)}%` },
          ].map(({ change, effect }) => (
            <div key={change} className="flex items-center gap-3 p-3 rounded-xl bg-primary/5 border border-primary/10">
              <Zap size={14} className="text-primary-light shrink-0" />
              <div>
                <p className="text-xs font-medium text-primary-light">{change}</p>
                <p className="text-[10px] text-text-muted">{effect}</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}
