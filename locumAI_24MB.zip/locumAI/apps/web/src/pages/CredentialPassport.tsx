import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  FileCheck, Shield, AlertTriangle, CheckCircle2, Clock,
  Upload, Sparkles, ExternalLink, RefreshCw, Eye, AlertOctagon,
  ArrowRight, Award, Lock, FileText, Check
} from 'lucide-react'

interface CredentialNode {
  id: string
  name: string
  issuer: string
  regNumber: string
  issuedDate: string
  expiryDate: string
  status: 'verified' | 'expiring_soon' | 'expired' | 'permanent'
  daysLeft: number
  anomalyScore: number // IsolationForest anomaly score (0-1, lower = genuine)
  prerequisiteOf?: string[]
}

const CREDENTIALS: CredentialNode[] = [
  {
    id: 'c1',
    name: 'MBBS Degree Certificate',
    issuer: 'Maharashtra University of Health Sciences (MUHS)',
    regNumber: 'MBBS/2018/84920',
    issuedDate: '2018-05-15',
    expiryDate: 'Permanent Lifetime',
    status: 'permanent',
    daysLeft: 99999,
    anomalyScore: 0.02,
    prerequisiteOf: ['c2']
  },
  {
    id: 'c2',
    name: 'State Medical Council Registration (MMC)',
    issuer: 'Maharashtra Medical Council, Mumbai',
    regNumber: 'MMC-2018-09-4821',
    issuedDate: '2018-09-10',
    expiryDate: '2028-09-09',
    status: 'verified',
    daysLeft: 680,
    anomalyScore: 0.03,
    prerequisiteOf: ['c3', 'c4']
  },
  {
    id: 'c3',
    name: 'ACLS / BLS Emergency Provider Certification',
    issuer: 'American Heart Association (India Authorized Chapter)',
    regNumber: 'AHA-ACLS-98214-IN',
    issuedDate: '2025-02-14',
    expiryDate: '2027-02-14',
    status: 'verified',
    daysLeft: 108,
    anomalyScore: 0.04,
    prerequisiteOf: ['c5']
  },
  {
    id: 'c4',
    name: 'Professional Medical Indemnity Insurance',
    issuer: 'New India Assurance Co. Ltd.',
    regNumber: 'POL-IND-849281-26',
    issuedDate: '2026-04-01',
    expiryDate: '2027-03-31',
    status: 'verified',
    daysLeft: 153,
    anomalyScore: 0.01,
    prerequisiteOf: ['c5']
  },
  {
    id: 'c5',
    name: 'Hospital Acute ICU / Emergency Clinical Privileges',
    issuer: 'Lilavati Hospital Credentialing Committee',
    regNumber: 'PRIV-LIL-EM-049',
    issuedDate: '2026-06-01',
    expiryDate: '2026-12-01',
    status: 'expiring_soon',
    daysLeft: 33,
    anomalyScore: 0.05,
  }
]

export default function CredentialPassport() {
  const [selectedDoc, setSelectedDoc] = useState<CredentialNode>(CREDENTIALS[1])
  const [isVerifying, setIsVerifying] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const showToast = (msg: string) => {
    setToast(msg)
    setTimeout(() => setToast(null), 3500)
  }

  const handleRunForensicScan = () => {
    setIsVerifying(true)
    setTimeout(() => {
      setIsVerifying(false)
      showToast('✅ IsolationForest Forensic Scan Complete: 0 anomalies detected (99.2% authentic).')
    }, 1100)
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 glass-card bg-surface-1/95 border-accent text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 text-xs font-semibold"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-accent animate-ping" />
            <span>{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 rounded-xl bg-accent/15 text-accent">
              <Award size={26} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Credential Passport & Dependency Graph</h1>
              <p className="text-sm text-text-muted">
                NetworkX-structured credential hierarchy, automated renewal alerts & IsolationForest document anomaly forensics
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunForensicScan}
            disabled={isVerifying}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              isVerifying
                ? 'bg-surface-3 text-text-muted cursor-not-allowed'
                : 'bg-primary hover:bg-primary-hover text-white shadow-lg shadow-primary/20 active:scale-95'
            }`}
          >
            <RefreshCw size={14} className={isVerifying ? 'animate-spin' : ''} />
            {isVerifying ? 'Scanning Metadata…' : 'Run IsolationForest Audit'}
          </button>
        </div>
      </div>

      {/* Passport Summary Banner */}
      <div className="glass-card p-5 border-l-4 border-accent">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-primary/20">
              Dr. P
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-text-primary">Dr. Priya Sharma, MBBS, MD</h3>
                <span className="text-[10px] bg-accent/15 text-accent font-bold px-2 py-0.5 rounded-full border border-accent/30 flex items-center gap-1">
                  <CheckCircle2 size={11} /> All Core Licenses Active
                </span>
              </div>
              <p className="text-xs text-text-muted mt-0.5">
                Specialty: Emergency Medicine • Maharashtra Medical Council #MMC-2018-09-4821
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="bg-surface-2 p-2.5 rounded-xl border border-glass-border text-center">
              <span className="text-[10px] text-text-muted block">Verified Nodes</span>
              <span className="font-bold text-accent text-sm">5 / 5 Active</span>
            </div>
            <div className="bg-surface-2 p-2.5 rounded-xl border border-glass-border text-center">
              <span className="text-[10px] text-text-muted block">Next Expiry</span>
              <span className="font-bold text-warning text-sm">33 Days</span>
            </div>
            <div className="bg-surface-2 p-2.5 rounded-xl border border-glass-border text-center">
              <span className="text-[10px] text-text-muted block">Forensic Anomaly</span>
              <span className="font-bold text-accent text-sm">0.02 (Safe)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: DAG Hierarchy Visualizer + Document Forensics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: NetworkX Dependency Graph Visualizer */}
        <div className="lg:col-span-2 space-y-4">
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-sm text-text-primary">Credential Dependency Graph (DAG)</h3>
                <p className="text-xs text-text-muted">
                  Prerequisite hierarchy: MBBS Degree $\to$ MMC License $\to$ ACLS / Indemnity $\to$ Hospital Privileges
                </p>
              </div>
              <span className="text-xs font-mono text-primary-light bg-primary/10 px-2.5 py-1 rounded">
                NetworkX DiGraph: 5 Nodes / 4 Edges
              </span>
            </div>

            {/* Visual Step Nodes */}
            <div className="space-y-3 relative">
              {CREDENTIALS.map((doc, idx) => {
                const isSelected = selectedDoc.id === doc.id
                return (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDoc(doc)}
                    className={`p-4 rounded-xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-surface-2 border-primary shadow-lg shadow-primary/10'
                        : 'bg-surface-2/60 hover:bg-surface-2 border-glass-border'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 font-bold text-xs ${
                            doc.status === 'permanent' || doc.status === 'verified'
                              ? 'bg-accent/20 text-accent'
                              : 'bg-warning/20 text-warning'
                          }`}
                        >
                          L{idx + 1}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-sm text-text-primary">{doc.name}</h4>
                            {doc.status === 'permanent' ? (
                              <span className="text-[10px] bg-primary/15 text-primary-light font-bold px-2 py-0.5 rounded">
                                Permanent
                              </span>
                            ) : doc.status === 'expiring_soon' ? (
                              <span className="text-[10px] bg-warning/15 text-warning font-bold px-2 py-0.5 rounded flex items-center gap-1">
                                <AlertTriangle size={10} /> Renews in {doc.daysLeft}d
                              </span>
                            ) : (
                              <span className="text-[10px] bg-accent/15 text-accent font-bold px-2 py-0.5 rounded flex items-center gap-1">
                                <CheckCircle2 size={10} /> Valid
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-text-muted mt-0.5">{doc.issuer}</p>
                          <div className="text-[11px] font-mono text-text-secondary mt-1">
                            Reg: {doc.regNumber} • Valid thru: {doc.expiryDate}
                          </div>
                        </div>
                      </div>

                      <div className="text-right sm:border-l sm:border-glass-border/40 sm:pl-4">
                        <div className="text-[10px] text-text-muted">Forensic Anomaly Score</div>
                        <div className="font-mono font-bold text-accent text-sm">
                          {doc.anomalyScore.toFixed(2)}
                        </div>
                        <span className="text-[10px] text-text-muted">IsolationForest</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Document Forensics Inspector */}
        <div className="glass-card p-5 space-y-5 flex flex-col">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <FileCheck size={18} className="text-accent" />
              <h3 className="font-bold text-sm text-text-primary">Forensic Document Inspector</h3>
            </div>
            <p className="text-xs text-text-muted">
              Live anomaly analysis for selected node: <strong className="text-text-primary">{selectedDoc.name}</strong>
            </p>
          </div>

          <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-3 text-xs">
            <div className="flex justify-between border-b border-glass-border/40 pb-2">
              <span className="text-text-muted">Issuing Authority:</span>
              <span className="font-semibold text-text-primary text-right max-w-[180px] truncate">{selectedDoc.issuer}</span>
            </div>
            <div className="flex justify-between border-b border-glass-border/40 pb-2">
              <span className="text-text-muted">License Identifier:</span>
              <span className="font-mono font-bold text-primary-light">{selectedDoc.regNumber}</span>
            </div>
            <div className="flex justify-between border-b border-glass-border/40 pb-2">
              <span className="text-text-muted">Expiration Window:</span>
              <span className="font-mono text-text-primary">{selectedDoc.expiryDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-muted">IsolationForest Anomaly:</span>
              <span className="font-mono font-bold text-accent">{selectedDoc.anomalyScore.toFixed(3)} (Low Risk)</span>
            </div>
          </div>

          {/* Forensic Checks Breakdown */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-text-primary block">
              Automated Forensic Verification Pipeline
            </span>
            <div className="space-y-1.5 text-xs text-text-secondary">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-surface-2/60 border border-glass-border">
                <Check size={14} className="text-accent shrink-0" />
                <span>State council registry regex match verified</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-surface-2/60 border border-glass-border">
                <Check size={14} className="text-accent shrink-0" />
                <span>Digital authority cryptographic seal detected</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-surface-2/60 border border-glass-border">
                <Check size={14} className="text-accent shrink-0" />
                <span>Layout & font typography tampering score: 0.012</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-surface-2/60 border border-glass-border">
                <Check size={14} className="text-accent shrink-0" />
                <span>Prerequisites satisfied in DAG topology</span>
              </div>
            </div>
          </div>

          <div className="mt-auto pt-4 border-t border-glass-border">
            <button
              onClick={() => showToast(`Digital passport token exported for ${selectedDoc.name}`)}
              className="w-full py-2.5 rounded-xl text-xs font-bold bg-primary hover:bg-primary-hover text-white shadow-md shadow-primary/20 transition-all flex items-center justify-center gap-2"
            >
              <Lock size={14} />
              <span>Generate Shareable Verified Token</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
