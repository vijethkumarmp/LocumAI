import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Cpu, GitBranch, RefreshCw, AlertTriangle, CheckCircle, ShieldCheck,
  TrendingDown, ArrowUpRight, Play, Database, Activity, Eye, Zap,
  Sliders, Layers, FileText, Check, AlertOctagon, RotateCcw
} from 'lucide-react'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Cell, AreaChart, Area
} from 'recharts'

interface ModelCard {
  name: string
  version: string
  stage: 'Production' | 'Staging' | 'Archived'
  run_id: string
  primaryMetric: string
  primaryValue: number
  ece: number
  brier: number
  latencyMs: number
  lastTrained: string
  shadowMode: boolean
  canaryPct: number
}

const INITIAL_MODELS: ModelCard[] = [
  {
    name: 'fill-probability',
    version: 'v1.2',
    stage: 'Production',
    run_id: 'run_fp_002',
    primaryMetric: 'AUC',
    primaryValue: 0.892,
    ece: 0.034,
    brier: 0.142,
    latencyMs: 14,
    lastTrained: '2026-10-27 18:30',
    shadowMode: false,
    canaryPct: 100,
  },
  {
    name: 'fill-probability',
    version: 'v1.3-challenger',
    stage: 'Staging',
    run_id: 'run_fp_003',
    primaryMetric: 'AUC',
    primaryValue: 0.908,
    ece: 0.029,
    brier: 0.135,
    latencyMs: 16,
    lastTrained: '2026-10-28 09:15',
    shadowMode: true,
    canaryPct: 20,
  },
  {
    name: 'fair-rate-quantile',
    version: 'v1.1',
    stage: 'Production',
    run_id: 'run_fr_001',
    primaryMetric: 'Coverage-80',
    primaryValue: 0.814,
    ece: 0.021,
    brier: 0.118,
    latencyMs: 9,
    lastTrained: '2026-10-26 14:00',
    shadowMode: false,
    canaryPct: 100,
  },
  {
    name: 'vacancy-forecast-glm',
    version: 'v1.0',
    stage: 'Production',
    run_id: 'run_vf_001',
    primaryMetric: 'MASE',
    primaryValue: 0.819,
    ece: 0.041,
    brier: 0.165,
    latencyMs: 22,
    lastTrained: '2026-10-25 21:00',
    shadowMode: false,
    canaryPct: 100,
  },
  {
    name: 'reliability-bayes',
    version: 'v1.0',
    stage: 'Production',
    run_id: 'run_rs_001',
    primaryMetric: 'Calibration',
    primaryValue: 0.963,
    ece: 0.018,
    brier: 0.089,
    latencyMs: 4,
    lastTrained: '2026-10-24 11:20',
    shadowMode: false,
    canaryPct: 100,
  },
  {
    name: 'fatigue-two-process',
    version: 'v1.0',
    stage: 'Production',
    run_id: 'run_fc_001',
    primaryMetric: 'Recall (Safety)',
    primaryValue: 0.994,
    ece: 0.012,
    brier: 0.045,
    latencyMs: 2,
    lastTrained: '2026-10-22 08:00',
    shadowMode: false,
    canaryPct: 100,
  },
  {
    name: 'match-cpsat-ilp',
    version: 'v1.0',
    stage: 'Production',
    run_id: 'run_mr_001',
    primaryMetric: 'Cost Reduction vs Greedy',
    primaryValue: 0.184,
    ece: 0.025,
    brier: 0.095,
    latencyMs: 145,
    lastTrained: '2026-10-27 12:45',
    shadowMode: false,
    canaryPct: 100,
  },
]

const DRIFT_METRICS = [
  { feature: 'offered_rate_ratio', test: 'Wasserstein / KS', p_value: 0.003, psi: 0.28, drifted: true, severity: 'High' },
  { feature: 'lead_time_days', test: 'Kolmogorov-Smirnov', p_value: 0.041, psi: 0.14, drifted: true, severity: 'Medium' },
  { feature: 'specialty_distribution', test: 'Chi-Square', p_value: 0.220, psi: 0.06, drifted: false, severity: 'Low' },
  { feature: 'urgent_flag_pct', test: 'Z-test Proportion', p_value: 0.310, psi: 0.04, drifted: false, severity: 'Low' },
  { feature: 'locum_experience_yrs', test: 'KS test', p_value: 0.890, psi: 0.01, drifted: false, severity: 'Low' },
]

const CALIBRATION_DECAY = [
  { week: 'W1', ece: 0.024, brier: 0.128, auc: 0.895 },
  { week: 'W2', ece: 0.026, brier: 0.131, auc: 0.892 },
  { week: 'W3', ece: 0.029, brier: 0.136, auc: 0.888 },
  { week: 'W4', ece: 0.035, brier: 0.144, auc: 0.881 },
  { week: 'W5 (Current)', ece: 0.048, brier: 0.158, auc: 0.871 },
]

export default function MLOpsConsole() {
  const [models, setModels] = useState<ModelCard[]>(INITIAL_MODELS)
  const [activeTab, setActiveTab] = useState<'registry' | 'drift' | 'pipeline' | 'simulator'>('registry')
  const [isRetraining, setIsRetraining] = useState(false)
  const [retrainLogs, setRetrainLogs] = useState<string[]>([])
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [simSeed, setSimSeed] = useState(42)
  const [driftInjected, setDriftInjected] = useState(false)
  const [outbreakShock, setOutbreakShock] = useState(true)

  const showToast = (msg: string) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(null), 4000)
  }

  const handlePromote = (modelName: string, version: string) => {
    setModels(prev =>
      prev.map(m => {
        if (m.name === modelName) {
          if (m.version === version) {
            return { ...m, stage: 'Production', shadowMode: false, canaryPct: 100 }
          } else if (m.stage === 'Production') {
            return { ...m, stage: 'Archived', shadowMode: false, canaryPct: 0 }
          }
        }
        return m
      })
    )
    showToast(`✅ Model ${modelName} ${version} promoted to Production! Automated gates passed (ECE ≤ 0.05, Fairness check: 0 parity gap).`)
  }

  const handleRollback = (modelName: string) => {
    setModels(prev => {
      const prod = prev.find(m => m.name === modelName && m.stage === 'Production')
      const arch = prev.find(m => m.name === modelName && m.stage === 'Archived')
      if (!arch) {
        showToast(`ℹ️ No archived version found for rollback on ${modelName}.`)
        return prev
      }
      return prev.map(m => {
        if (m.name === modelName) {
          if (m.version === arch.version) return { ...m, stage: 'Production', shadowMode: false, canaryPct: 100 }
          if (m.version === prod?.version) return { ...m, stage: 'Archived', shadowMode: false, canaryPct: 0 }
        }
        return m
      })
    })
    showToast(`↩️ Model ${modelName} rolled back to previous stable production release.`)
  }

  const handleTriggerRetrain = () => {
    setIsRetraining(true)
    setRetrainLogs([
      '[MLOPS] Triggered retrain pipeline: pipelines/retrain_if_drift.py',
      '[INGEST] Streaming latest 7 days market outcomes from DB & Parquet lake...',
      '[VALIDATE] Pandera contract validation: passed 42/42 assertions (no leakage).',
      '[FEATURES] Train/serve parity check: SHA256 matches production feature pipeline.',
      '[TRAIN] Fitting LightGBM + Isotonic Calibrator (Optuna 15 trials)...',
      '[EVAL] Holdout results: AUC = 0.914, ECE = 0.026 (<0.05 gate threshold).',
      '[GATE] Fairness check: Gender parity residual = -₹4 (within ±₹15 tolerance).',
      '[REGISTRY] Registering model as v1.4 in MLflow model registry...',
      '[GATE] Challenger beats champion by +0.022 AUC. Auto-promotion APPROVED.',
      '[DEPLOY] Hot-reloaded serving instance. Serving traffic on v1.4.'
    ])
    setTimeout(() => {
      setIsRetraining(false)
      showToast('🎉 Retraining complete! v1.4 auto-promoted through all quality & calibration gates.')
    }, 2800)
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 glass-card bg-surface-1/95 border-primary/50 text-white px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-accent animate-ping" />
            <span className="text-sm font-medium">{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 rounded-xl bg-primary/10 text-primary-light">
              <Cpu size={26} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">MLOps Command Center</h1>
              <p className="text-sm text-text-muted">
                End-to-end model registry, live calibration decay, statistical drift detectors & automated gate promotions
              </p>
            </div>
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleTriggerRetrain}
            disabled={isRetraining}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
              isRetraining
                ? 'bg-surface-3 text-text-muted cursor-not-allowed'
                : 'bg-primary hover:bg-primary-hover text-white shadow-lg shadow-primary/25 active:scale-95'
            }`}
          >
            <RefreshCw size={16} className={isRetraining ? 'animate-spin' : ''} />
            {isRetraining ? 'Retraining Models…' : 'Trigger Retrain Pipeline'}
          </button>
        </div>
      </div>

      {/* Quick KPI stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-card p-4">
          <div className="text-xs text-text-muted mb-1 flex items-center justify-between">
            <span>Models in Production</span>
            <CheckCircle size={14} className="text-accent" />
          </div>
          <div className="text-2xl font-black text-text-primary">6 Active</div>
          <p className="text-[11px] text-text-muted mt-1">1 Challenger in Shadow Mode</p>
        </div>
        <div className="glass-card p-4">
          <div className="text-xs text-text-muted mb-1 flex items-center justify-between">
            <span>Mean Calibration (ECE)</span>
            <Activity size={14} className="text-primary-light" />
          </div>
          <div className="text-2xl font-black text-accent">0.028</div>
          <p className="text-[11px] text-text-muted mt-1">Strict limit: &lt; 0.050</p>
        </div>
        <div className="glass-card p-4">
          <div className="text-xs text-text-muted mb-1 flex items-center justify-between">
            <span>Drift Status</span>
            <AlertTriangle size={14} className="text-warning" />
          </div>
          <div className="text-2xl font-black text-warning">2 Drifted</div>
          <p className="text-[11px] text-text-muted mt-1">Offered rate ratio & lead time</p>
        </div>
        <div className="glass-card p-4">
          <div className="text-xs text-text-muted mb-1 flex items-center justify-between">
            <span>Audit Predictions</span>
            <Database size={14} className="text-primary-light" />
          </div>
          <div className="text-2xl font-black text-text-primary">41,290</div>
          <p className="text-[11px] text-text-muted mt-1">100% hash-logged with latency</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-glass-border space-x-1">
        {[
          { id: 'registry', label: 'Model Registry & Gates', icon: Layers },
          { id: 'drift', label: 'Drift & Calibration Decay', icon: AlertTriangle },
          { id: 'pipeline', label: 'Retrain Execution Flow', icon: GitBranch },
          { id: 'simulator', label: 'Simulator & Shocks', icon: Sliders },
        ].map(t => {
          const Icon = t.icon
          const active = activeTab === t.id
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all ${
                active
                  ? 'border-primary text-primary-light font-semibold'
                  : 'border-transparent text-text-secondary hover:text-text-primary'
              }`}
            >
              <Icon size={16} />
              {t.label}
            </button>
          )
        })}
      </div>

      {/* Tab 1: Model Registry */}
      {activeTab === 'registry' && (
        <div className="space-y-6">
          <div className="glass-card overflow-hidden">
            <div className="p-5 border-b border-glass-border flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-text-primary text-base">Model Registry & Release Safeguards</h3>
                <p className="text-xs text-text-muted">
                  Multi-stage governance with shadow mode, canary traffic allocation, and one-click rollback
                </p>
              </div>
              <span className="text-xs bg-primary/10 text-primary-light font-mono px-2.5 py-1 rounded-md">
                MLflow Registry: Local Store (mlruns/)
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-surface-2 text-text-secondary text-xs uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Model Name</th>
                    <th className="py-3 px-4">Version</th>
                    <th className="py-3 px-4">Stage</th>
                    <th className="py-3 px-4">Primary Metric</th>
                    <th className="py-3 px-4">Calibration (ECE)</th>
                    <th className="py-3 px-4">Latency</th>
                    <th className="py-3 px-4">Serving Mode</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-glass-border text-xs">
                  {models.map(m => {
                    const isProd = m.stage === 'Production'
                    const isStaging = m.stage === 'Staging'
                    return (
                      <tr key={`${m.name}-${m.version}`} className="hover:bg-surface-2/40 transition-colors">
                        <td className="py-3.5 px-4 font-mono font-medium text-text-primary flex items-center gap-2">
                          <Cpu size={14} className="text-primary-light" />
                          {m.name}
                        </td>
                        <td className="py-3.5 px-4 font-mono text-text-secondary">{m.version}</td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                              isProd
                                ? 'bg-accent/15 text-accent border border-accent/30'
                                : isStaging
                                ? 'bg-warning/15 text-warning border border-warning/30'
                                : 'bg-surface-3 text-text-muted'
                            }`}
                          >
                            {m.stage}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="text-text-muted">{m.primaryMetric}:</span>{' '}
                          <span className="font-semibold text-text-primary">
                            {m.primaryValue < 1 ? m.primaryValue.toFixed(3) : m.primaryValue}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 font-mono">
                          <span className={m.ece <= 0.05 ? 'text-accent' : 'text-danger'}>
                            {m.ece.toFixed(3)}
                          </span>
                          <span className="text-text-muted text-[10px] ml-1">(&lt;0.05)</span>
                        </td>
                        <td className="py-3.5 px-4 text-text-secondary">{m.latencyMs} ms</td>
                        <td className="py-3.5 px-4">
                          {isProd ? (
                            <span className="text-accent font-medium flex items-center gap-1">
                              <Check size={12} /> 100% Active
                            </span>
                          ) : m.shadowMode ? (
                            <span className="text-primary-light font-medium flex items-center gap-1">
                              <Eye size={12} /> Shadow ({m.canaryPct}% Canary)
                            </span>
                          ) : (
                            <span className="text-text-muted">Offline</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {isStaging && (
                              <button
                                onClick={() => handlePromote(m.name, m.version)}
                                className="px-2.5 py-1 rounded bg-accent/20 hover:bg-accent/30 text-accent font-semibold text-[11px] transition-colors"
                              >
                                Promote to Prod
                              </button>
                            )}
                            {isProd && (
                              <button
                                onClick={() => handleRollback(m.name)}
                                className="px-2.5 py-1 rounded bg-surface-3 hover:bg-danger/20 hover:text-danger text-text-secondary text-[11px] transition-colors flex items-center gap-1"
                              >
                                <RotateCcw size={10} /> Rollback
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Model Quality Gate Spec */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="glass-card p-5">
              <div className="flex items-center gap-2 mb-2 text-accent">
                <ShieldCheck size={18} />
                <h4 className="font-semibold text-sm">Gate 1: Calibration Bound</h4>
              </div>
              <p className="text-xs text-text-secondary leading-relaxed">
                Expected Calibration Error (ECE) must strictly be &lt; 0.050 with Platt/isotonic scaling. Models violating probability reliability are immediately rejected from production.
              </p>
            </div>
            <div className="glass-card p-5">
              <div className="flex items-center gap-2 mb-2 text-primary-light">
                <ShieldCheck size={18} />
                <h4 className="font-semibold text-sm">Gate 2: Demographic Parity</h4>
              </div>
              <p className="text-xs text-text-secondary leading-relaxed">
                Fairlearn residual audit must verify gender & region pay parity within ±2% margin of error. Injected simulator gap must be cleanly identified and flagged.
              </p>
            </div>
            <div className="glass-card p-5">
              <div className="flex items-center gap-2 mb-2 text-warning">
                <ShieldCheck size={18} />
                <h4 className="font-semibold text-sm">Gate 3: P99 Latency & Hash</h4>
              </div>
              <p className="text-xs text-text-secondary leading-relaxed">
                Inference latency SLA under 50ms (or &lt;500ms for CP-SAT full roster solver). Feature inputs are SHA-256 digested and appended to <code className="text-primary-light">model_predictions</code>.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Drift & Calibration Decay */}
      {activeTab === 'drift' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Drift Table */}
            <div className="glass-card p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-sm">Feature Drift Detection (Evidently PSI / KS)</h3>
                  <p className="text-xs text-text-muted">Real-time distribution shift vs training baseline</p>
                </div>
                <span className="text-xs bg-warning/15 text-warning px-2.5 py-1 rounded font-medium">
                  Alert Threshold: PSI &gt; 0.20
                </span>
              </div>

              <div className="space-y-3">
                {DRIFT_METRICS.map(item => (
                  <div key={item.feature} className="p-3 rounded-lg bg-surface-2/60 border border-glass-border flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-text-primary">{item.feature}</span>
                        {item.drifted ? (
                          <span className="text-[10px] bg-danger/20 text-danger px-1.5 py-0.5 rounded font-bold">
                            DRIFT DETECTED
                          </span>
                        ) : (
                          <span className="text-[10px] bg-accent/20 text-accent px-1.5 py-0.5 rounded font-bold">
                            STABLE
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-text-muted mt-0.5">Statistical test: {item.test} (p={item.p_value})</p>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-mono font-bold text-text-primary">PSI = {item.psi.toFixed(2)}</div>
                      <div className="text-[10px] text-text-muted">Severity: {item.severity}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Calibration Decay Chart */}
            <div className="glass-card p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-sm">Rolling Calibration Decay (ECE)</h3>
                  <p className="text-xs text-text-muted">Evaluated on delayed ground truth shift fills</p>
                </div>
                <span className="text-xs text-danger font-mono font-medium">ECE: 0.024 → 0.048</span>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={CALIBRATION_DECAY}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
                    <XAxis dataKey="week" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} domain={[0, 0.06]} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="ece"
                      name="Expected Calibration Error (ECE)"
                      stroke="#f59e0b"
                      strokeWidth={3}
                      dot={{ r: 5, fill: '#f59e0b' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="brier"
                      name="Brier Loss"
                      stroke="#6366f1"
                      strokeWidth={2}
                      strokeDasharray="4 4"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[11px] text-text-muted mt-2">
                ⚠️ Notice how ECE approaches the 0.05 threshold at Week 5, triggering automated retraining in the background pipeline.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Retrain Execution Flow */}
      {activeTab === 'pipeline' && (
        <div className="space-y-6">
          <div className="glass-card p-6">
            <h3 className="font-semibold text-base mb-2">Automated Retrain Pipeline Pipeline</h3>
            <p className="text-xs text-text-muted mb-6">
              When drift or calibration decay crosses tolerance, <code className="text-primary-light">pipelines/retrain_if_drift.py</code> triggers the self-healing workflow.
            </p>

            {/* Stages Visualizer */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-6">
              {[
                { title: '1. Ingest & Lake', desc: 'Pull 24mo Parquet history', status: 'Passed' },
                { title: '2. Contract Check', desc: 'Pandera strict validation', status: 'Passed' },
                { title: '3. Optuna Train', desc: 'LightGBM + Isotonic', status: 'Active' },
                { title: '4. Safety Gates', desc: 'ECE < 0.05 & Pay Parity', status: 'Queued' },
                { title: '5. Canary Promote', desc: '100% Production Rollout', status: 'Queued' },
              ].map((step, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-surface-2 border border-glass-border">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-text-primary">{step.title}</span>
                    <span className="text-[10px] bg-accent/20 text-accent font-bold px-1.5 py-0.5 rounded">
                      {step.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-text-muted">{step.desc}</p>
                </div>
              ))}
            </div>

            {/* Execution Log Console */}
            <div className="bg-surface-0 rounded-xl p-4 font-mono text-xs border border-glass-border">
              <div className="flex items-center justify-between border-b border-glass-border/40 pb-2 mb-3 text-text-muted">
                <span className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                  Live Execution Logs
                </span>
                <span>Python 3.11 / MLflow v2.10</span>
              </div>
              <div className="space-y-1.5 max-h-56 overflow-y-auto text-text-secondary">
                {(retrainLogs.length > 0 ? retrainLogs : [
                  '[SYSTEM] Retrain scheduler listening on cron 0 3 * * * & event triggers.',
                  '[MONITOR] Last automated run completed 4h ago: champion retained (AUC 0.892).',
                  '[STANDBY] Ready for manual or drift-induced trigger.'
                ]).map((log, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-text-muted select-none">&gt;</span>
                    <span className={log.includes('APPROVED') || log.includes('passed') ? 'text-accent' : log.includes('Triggered') ? 'text-primary-light font-semibold' : ''}>{log}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Simulator Controls */}
      {activeTab === 'simulator' && (
        <div className="glass-card p-6 space-y-6">
          <div>
            <h3 className="font-semibold text-base mb-1">Agent-Based Simulator Controls</h3>
            <p className="text-xs text-text-muted">
              Configure market dynamics, regional disease shocks, and distribution drift for testing the models against known ground-truth.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-3">
              <label className="text-xs font-semibold text-text-primary block">Random Generator Seed</label>
              <input
                type="number"
                value={simSeed}
                onChange={e => setSimSeed(Number(e.target.value))}
                className="w-full bg-surface-3 border border-glass-border rounded-lg px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-primary"
              />
              <p className="text-[11px] text-text-muted">
                Ensures exact reproducibility across 150 facilities, 2,000 locums, and ~40,000 shifts.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-text-primary">Monsoon / Outbreak Shock</label>
                <input
                  type="checkbox"
                  checked={outbreakShock}
                  onChange={e => setOutbreakShock(e.target.checked)}
                  className="rounded text-primary focus:ring-0"
                />
              </div>
              <p className="text-[11px] text-text-muted">
                Injects Dengue/Malaria outbreak spike (+300% demand in Emergency and ICU) in Mumbai & Chennai coastal regions.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-text-primary">Drift Injection (make drift-demo)</label>
                <button
                  onClick={() => {
                    setDriftInjected(!driftInjected)
                    showToast(driftInjected ? 'Distribution restored to normal.' : '⚡ Market rate inflation drift injected! Expect PSI alarm.')
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    driftInjected
                      ? 'bg-danger text-white'
                      : 'bg-surface-3 text-text-secondary hover:text-text-primary'
                  }`}
                >
                  {driftInjected ? 'Drift Active' : 'Inject Rate Drift'}
                </button>
              </div>
              <p className="text-[11px] text-text-muted">
                Shifts the market rate distribution by +25% and shortens lead times, forcing the drift detector to fire.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
