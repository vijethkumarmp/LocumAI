import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Calendar, CheckCircle, AlertTriangle, ShieldAlert, Cpu, Sparkles,
  Zap, Clock, UserCheck, Users, HelpCircle, ArrowRight, BarChart2,
  TrendingDown, Check, SlidersHorizontal, ChevronRight, X
} from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Cell, ReferenceLine
} from 'recharts'
import RosterGanttView from '../components/RosterGanttView'
import { sound } from '../services/sound'

interface ShiftSlot {
  id: string
  department: string
  shiftDate: string
  timing: string
  assignedLocum: string
  locumReliability: number
  noShowProb: number
  riskLevel: 'low' | 'medium' | 'high'
  standbyAssigned: boolean
  standbyLocum?: string
  expectedCoverage: number
  costUnfilled: number
  retainerCost: number
}

const INITIAL_SLOTS: ShiftSlot[] = [
  {
    id: 'SH-201',
    department: 'Emergency Medicine',
    shiftDate: '2026-10-29',
    timing: 'Night (20:00 - 08:00)',
    assignedLocum: 'Dr. Priya Sharma',
    locumReliability: 0.94,
    noShowProb: 0.06,
    riskLevel: 'low',
    standbyAssigned: false,
    expectedCoverage: 0.94,
    costUnfilled: 25000,
    retainerCost: 1500,
  },
  {
    id: 'SH-202',
    department: 'ICU / Critical Care',
    shiftDate: '2026-10-29',
    timing: 'Night (20:00 - 08:00)',
    assignedLocum: 'Dr. Arjun Mehta',
    locumReliability: 0.81,
    noShowProb: 0.19,
    riskLevel: 'high',
    standbyAssigned: true,
    standbyLocum: 'Dr. Kavita Nair (Standby)',
    expectedCoverage: 0.985,
    costUnfilled: 40000,
    retainerCost: 2000,
  },
  {
    id: 'SH-203',
    department: 'Anesthesia (Surgical OT)',
    shiftDate: '2026-10-30',
    timing: 'Day (08:00 - 17:00)',
    assignedLocum: 'Dr. Rajesh Patel',
    locumReliability: 0.86,
    noShowProb: 0.14,
    riskLevel: 'medium',
    standbyAssigned: true,
    standbyLocum: 'Dr. Sneha Roy (Standby)',
    expectedCoverage: 0.982,
    costUnfilled: 35000,
    retainerCost: 1800,
  },
  {
    id: 'SH-204',
    department: 'Pediatrics OPD',
    shiftDate: '2026-10-30',
    timing: 'Day (09:00 - 18:00)',
    assignedLocum: 'Dr. Ananya Desai',
    locumReliability: 0.96,
    noShowProb: 0.04,
    riskLevel: 'low',
    standbyAssigned: false,
    expectedCoverage: 0.96,
    costUnfilled: 15000,
    retainerCost: 1200,
  },
  {
    id: 'SH-205',
    department: 'Obstetrics & Gynae',
    shiftDate: '2026-10-31',
    timing: 'Night (20:00 - 08:00)',
    assignedLocum: 'Dr. Vikram Rao',
    locumReliability: 0.82,
    noShowProb: 0.18,
    riskLevel: 'high',
    standbyAssigned: true,
    standbyLocum: 'Dr. Pooja Reddy (Standby)',
    expectedCoverage: 0.981,
    costUnfilled: 30000,
    retainerCost: 1600,
  },
]

// SHAP breakdown factors for Dr. Kavita Nair match
const SHAP_FACTORS = [
  { feature: 'Specialty & Sub-skill Adjacency', value: +0.38, direction: 'positive' },
  { feature: 'Bayesian Reliability (0.96 mean)', value: +0.28, direction: 'positive' },
  { feature: 'Travel Proximity (6.2 km)', value: +0.24, direction: 'positive' },
  { feature: 'Clean Rest Window (18h since last shift)', value: +0.19, direction: 'positive' },
  { feature: 'Expected Overbooking Cost Delta', value: -0.12, direction: 'negative' },
]

export default function RosterBoard() {
  const [slots, setSlots] = useState<ShiftSlot[]>(INITIAL_SLOTS)
  const [selectedSlot, setSelectedSlot] = useState<ShiftSlot | null>(slots[1])
  const [isSolving, setIsSolving] = useState(false)
  const [solverStats, setSolverStats] = useState({
    status: 'OPTIMAL',
    objectiveValue: '₹142,800',
    optimalityGap: '0.0%',
    solveTimeMs: 142,
    constraintsChecked: 216,
    greedyCostSavings: '18.4%',
  })
  const [targetCoverage, setTargetCoverage] = useState(98)
  const [viewMode, setViewMode] = useState<'matrix' | 'gantt'>('gantt')

  const handleRunOptimizer = () => {
    sound.playClick()
    setIsSolving(true)
    setTimeout(() => {
      setIsSolving(false)
      sound.playSuccess()
      setSolverStats({
        status: 'OPTIMAL (Global Solution Found)',
        objectiveValue: '₹139,200',
        optimalityGap: '0.0%',
        solveTimeMs: 128,
        constraintsChecked: 216,
        greedyCostSavings: '20.6%',
      })
    }, 1200)
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 rounded-xl bg-primary/10 text-primary-light">
              <Calendar size={26} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Roster Board & Probabilistic Overbooking</h1>
              <p className="text-sm text-text-muted">
                OR-Tools CP-SAT multi-shift match optimizer with automated standby overbooking & SHAP match explainability
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* View switcher */}
          <div className="p-1 rounded-xl bg-surface-2 border border-glass-border flex items-center gap-1">
            <button
              onClick={() => {
                setViewMode('gantt')
                sound.playSwitch()
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'gantt'
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-text-muted hover:text-text-primary'
              }`}
            >
              24h Gantt Timeline
            </button>
            <button
              onClick={() => {
                setViewMode('matrix')
                sound.playSwitch()
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'matrix'
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-text-muted hover:text-text-primary'
              }`}
            >
              Overbooking Matrix
            </button>
          </div>

          <button
            onClick={handleRunOptimizer}
            disabled={isSolving}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
              isSolving
                ? 'bg-surface-3 text-text-muted cursor-not-allowed'
                : 'bg-primary hover:bg-primary-hover text-white shadow-lg shadow-primary/25 active:scale-95'
            }`}
          >
            <Cpu size={16} className={isSolving ? 'animate-spin' : ''} />
            {isSolving ? 'Solving CP-SAT ILP…' : 'Run CP-SAT Optimizer'}
          </button>
        </div>
      </div>

      {/* Solver Performance Banner */}
      <div className="glass-card p-5 border-l-4 border-accent">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              <span className="text-xs uppercase font-mono font-bold text-accent">
                OR-Tools CP-SAT Integer Linear Programming
              </span>
            </div>
            <h3 className="font-bold text-sm text-text-primary">
              Multi-Shift Global Assignment: {solverStats.status}
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-surface-2 p-2.5 rounded-lg border border-glass-border">
              <span className="text-text-muted block text-[10px]">Optimality Gap</span>
              <span className="font-mono font-bold text-accent text-sm">{solverStats.optimalityGap}</span>
            </div>
            <div className="bg-surface-2 p-2.5 rounded-lg border border-glass-border">
              <span className="text-text-muted block text-[10px]">Solve Latency</span>
              <span className="font-mono font-bold text-primary-light text-sm">{solverStats.solveTimeMs} ms</span>
            </div>
            <div className="bg-surface-2 p-2.5 rounded-lg border border-glass-border">
              <span className="text-text-muted block text-[10px]">Cost vs Greedy</span>
              <span className="font-mono font-bold text-accent text-sm">-{solverStats.greedyCostSavings}</span>
            </div>
            <div className="bg-surface-2 p-2.5 rounded-lg border border-glass-border">
              <span className="text-text-muted block text-[10px]">Constraints</span>
              <span className="font-mono font-bold text-text-primary text-sm">{solverStats.constraintsChecked} OK</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Roster Table / Gantt + SHAP Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Gantt or Shadow Roster Slots */}
        <div className="lg:col-span-2 space-y-4">
          {viewMode === 'gantt' ? (
            <RosterGanttView />
          ) : (
            <div className="glass-card p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-sm">Probabilistic Overbooking Board</h3>
                  <p className="text-xs text-text-muted">
                    Guarantees expected coverage ≥ {targetCoverage}% by assigning standbys when no-show cost exceeds retainer
                  </p>
                </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-text-muted">Target Coverage:</span>
                <span className="text-xs font-mono font-bold text-accent">{targetCoverage}%</span>
              </div>
            </div>

            <div className="space-y-3">
              {slots.map((slot) => {
                const isSelected = selectedSlot?.id === slot.id
                return (
                  <div
                    key={slot.id}
                    onClick={() => setSelectedSlot(slot)}
                    className={`p-4 rounded-xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-surface-2 border-primary shadow-md'
                        : 'bg-surface-2/60 hover:bg-surface-2 border-glass-border'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-mono font-bold text-primary-light">{slot.id}</span>
                          <span className="font-semibold text-sm text-text-primary">{slot.department}</span>
                          {slot.standbyAssigned && (
                            <span className="text-[10px] bg-accent/15 text-accent font-bold px-2 py-0.5 rounded-full border border-accent/30 flex items-center gap-1">
                              <ShieldAlert size={10} /> STANDBY SECURED
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-text-muted flex items-center gap-3">
                          <span>{slot.shiftDate}</span>
                          <span>•</span>
                          <span>{slot.timing}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs">
                        <div className="text-right">
                          <div className="text-text-muted text-[10px]">Primary Locum</div>
                          <div className="font-medium text-text-primary">{slot.assignedLocum}</div>
                        </div>

                        <div className="text-right">
                          <div className="text-text-muted text-[10px]">No-Show Risk</div>
                          <div
                            className={`font-mono font-bold ${
                              slot.riskLevel === 'high'
                                ? 'text-danger'
                                : slot.riskLevel === 'medium'
                                ? 'text-warning'
                                : 'text-accent'
                            }`}
                          >
                            {(slot.noShowProb * 100).toFixed(0)}%
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-text-muted text-[10px]">Coverage</div>
                          <div className="font-mono font-bold text-accent">
                            {(slot.expectedCoverage * 100).toFixed(1)}%
                          </div>
                        </div>

                        <ChevronRight size={16} className="text-text-muted shrink-0" />
                      </div>
                    </div>

                    {slot.standbyAssigned && (
                      <div className="mt-3 pt-3 border-t border-glass-border/40 flex items-center justify-between text-xs text-text-secondary">
                        <span className="flex items-center gap-1.5 text-accent">
                          <UserCheck size={14} /> Backup standby: {slot.standbyLocum}
                        </span>
                        <span className="text-[11px] font-mono text-text-muted">
                          Expected Net Savings: ₹{(slot.costUnfilled * slot.noShowProb - slot.retainerCost).toFixed(0)}
                        </span>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )}
        </div>

        {/* Right 1 Col: SHAP Match Explainer Drawer */}
        <div className="glass-card p-5 space-y-5">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={16} className="text-primary-light" />
              <h3 className="font-semibold text-sm">"Why This Match?" (SHAP Explainer)</h3>
            </div>
            <p className="text-xs text-text-muted">
              Additive feature attributions for candidate {selectedSlot?.assignedLocum}
            </p>
          </div>

          <div className="space-y-3">
            {SHAP_FACTORS.map((factor, i) => (
              <div key={i} className="text-xs">
                <div className="flex justify-between mb-1">
                  <span className="text-text-secondary truncate pr-2">{factor.feature}</span>
                  <span
                    className={`font-mono font-bold shrink-0 ${
                      factor.direction === 'positive' ? 'text-accent' : 'text-danger'
                    }`}
                  >
                    {factor.value > 0 ? `+${factor.value}` : factor.value}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-surface-3 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${factor.direction === 'positive' ? 'bg-accent' : 'bg-danger'}`}
                    style={{ width: `${Math.abs(factor.value) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Counterfactuals */}
          <div className="p-3.5 rounded-xl bg-surface-2 border border-glass-border space-y-2">
            <span className="text-xs font-semibold text-text-primary block">
              Counterfactual What-If Recommendations
            </span>
            <div className="space-y-1.5 text-xs text-text-secondary">
              <div className="flex items-center gap-1.5">
                <ArrowRight size={12} className="text-primary-light shrink-0" />
                <span>+₹300 rate increase boosts fill chance from 64% → 85%</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ArrowRight size={12} className="text-primary-light shrink-0" />
                <span>Shift start at 08:30 avoids Mumbai peak traffic (+12% on-time)</span>
              </div>
            </div>
          </div>

          {/* Hard Safety Verification */}
          <div className="p-3.5 rounded-xl bg-accent/10 border border-accent/30 text-xs space-y-1.5">
            <span className="font-bold text-accent flex items-center gap-1.5">
              <CheckCircle size={14} /> All Hard Constraints Satisfied
            </span>
            <ul className="text-[11px] text-text-secondary space-y-1 list-disc pl-4">
              <li>Rest window: 18h &gt; 11h minimum</li>
              <li>7-day cumulative: 36h &lt; 60h weekly cap</li>
              <li>Consecutive nights: 1 &lt; 4 limit</li>
              <li>Credentials: Valid MCI registration until 2028</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
