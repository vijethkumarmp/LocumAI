import React, { useRef, useMemo, Suspense, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, useScroll, useTransform } from 'framer-motion'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, MeshDistortMaterial, Sphere, Stars, OrbitControls } from '@react-three/drei'
import {
  Activity, Brain, Shield, HeartPulse, Zap, BarChart3,
  ArrowRight, CheckCircle, Sparkles, TrendingUp, Clock, Users
} from 'lucide-react'
import * as THREE from 'three'

/* ─── 3D Animated DNA Helix / Neural Network ─── */
function NeuralNetwork() {
  const groupRef = useRef<THREE.Group>(null)
  const nodesRef = useRef<THREE.InstancedMesh>(null)
  
  const nodeCount = 80
  const positions = useMemo(() => {
    const pos = []
    for (let i = 0; i < nodeCount; i++) {
      const t = i / nodeCount * Math.PI * 4
      const r = 2 + Math.sin(t * 0.5) * 0.8
      pos.push(new THREE.Vector3(
        Math.cos(t) * r,
        (i / nodeCount - 0.5) * 6,
        Math.sin(t) * r
      ))
    }
    return pos
  }, [])

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.15
    }
    if (nodesRef.current) {
      const dummy = new THREE.Object3D()
      positions.forEach((pos, i) => {
        const time = state.clock.elapsedTime
        const scale = 0.06 + Math.sin(time * 2 + i * 0.3) * 0.02
        dummy.position.set(
          pos.x + Math.sin(time + i) * 0.1,
          pos.y + Math.cos(time * 0.7 + i * 0.5) * 0.05,
          pos.z + Math.sin(time * 0.5 + i * 0.7) * 0.1
        )
        dummy.scale.setScalar(scale)
        dummy.updateMatrix()
        nodesRef.current!.setMatrixAt(i, dummy.matrix)
      })
      nodesRef.current.instanceMatrix.needsUpdate = true
    }
  })

  return (
    <group ref={groupRef}>
      <Stars radius={10} depth={30} count={1500} factor={3} saturation={0.5} fade speed={1} />
      <instancedMesh ref={nodesRef} args={[undefined, undefined, nodeCount]}>
        <sphereGeometry args={[1, 12, 12]} />
        <meshStandardMaterial color="#818cf8" emissive="#6366f1" emissiveIntensity={0.8} />
      </instancedMesh>
      {/* Central glowing sphere */}
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <Sphere args={[0.8, 32, 32]}>
          <MeshDistortMaterial
            color="#6366f1"
            emissive="#4f46e5"
            emissiveIntensity={0.5}
            roughness={0.2}
            metalness={0.8}
            distort={0.4}
            speed={3}
          />
        </Sphere>
      </Float>
      <ambientLight intensity={0.3} />
      <pointLight position={[5, 5, 5]} intensity={1} color="#6366f1" />
      <pointLight position={[-5, -3, 3]} intensity={0.5} color="#06b6d4" />
    </group>
  )
}

/* ─── Animated Fill Probability Demo ─── */
function LiveFillDemo() {
  const [rate, setRate] = React.useState(4500)
  const baseRate = 4000
  const ratio = rate / baseRate
  const logit = -2.0 + 3.5 * ratio + 0.8 * 0.5 // lead_time effect
  const prob = 1 / (1 + Math.exp(-logit))

  const barColor = prob > 0.8 ? '#10b981' : prob > 0.5 ? '#f59e0b' : '#ef4444'

  return (
    <div className="glass-card p-6 max-w-md w-full">
      <div className="flex items-center gap-2 mb-4">
        <div className="pulse-dot" />
        <span className="text-xs text-text-muted uppercase tracking-wider">Live Model Output</span>
      </div>
      <h3 className="text-lg font-semibold mb-1">Fill Probability Meter</h3>
      <p className="text-text-muted text-sm mb-5">Drag the rate slider to see real-time predictions</p>

      <div className="mb-4">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-text-secondary">Offered Rate</span>
          <span className="font-bold text-primary-light">₹{rate.toLocaleString()}</span>
        </div>
        <input
          type="range"
          min={2000}
          max={8000}
          step={100}
          value={rate}
          onChange={(e) => setRate(Number(e.target.value))}
          className="w-full h-2 rounded-lg appearance-none cursor-pointer"
          style={{
            background: `linear-gradient(to right, #6366f1 ${((rate - 2000) / 6000) * 100}%, #334155 0%)`,
          }}
        />
        <div className="flex justify-between text-[10px] text-text-muted mt-1">
          <span>₹2,000</span>
          <span>₹8,000</span>
        </div>
      </div>

      <div className="text-center py-4">
        <motion.div
          key={Math.round(prob * 100)}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-5xl font-black mb-1"
          style={{ color: barColor }}
        >
          {(prob * 100).toFixed(1)}%
        </motion.div>
        <p className="text-text-muted text-xs">Probability of fill within 48h</p>
      </div>

      <div className="progress-bar">
        <motion.div
          className="progress-fill"
          style={{ background: barColor }}
          animate={{ width: `${prob * 100}%` }}
          transition={{ type: 'spring', stiffness: 120 }}
        />
      </div>

      <div className="mt-4 flex items-center justify-between text-xs text-text-muted">
        <span>95% CI: [{(Math.max(0, prob - 0.08) * 100).toFixed(0)}%, {(Math.min(1, prob + 0.08) * 100).toFixed(0)}%]</span>
        <span className="text-primary-light">v1.0-calibrated</span>
      </div>
    </div>
  )
}

/* ─── Feature Card ─── */
function FeatureCard({ icon: Icon, title, desc, color, delay }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ delay, duration: 0.5 }}
      className="glass-card p-6 group hover:scale-[1.02] transition-transform"
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
        style={{ background: `${color}15` }}
      >
        <Icon size={24} style={{ color }} />
      </div>
      <h3 className="font-semibold text-text-primary mb-2">{title}</h3>
      <p className="text-sm text-text-secondary leading-relaxed">{desc}</p>
    </motion.div>
  )
}

/* ─── Stat Counter ─── */
function StatCounter({ value, label, suffix = '' }: { value: number; label: string; suffix?: string }) {
  const [count, setCount] = React.useState(0)
  const ref = useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        let start = 0
        const duration = 2000
        const step = (timestamp: number) => {
          if (!start) start = timestamp
          const progress = Math.min((timestamp - start) / duration, 1)
          const eased = 1 - Math.pow(1 - progress, 3)
          setCount(Math.round(eased * value))
          if (progress < 1) requestAnimationFrame(step)
        }
        requestAnimationFrame(step)
        observer.disconnect()
      }
    })
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [value])

  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl font-black gradient-text mb-1">
        {count.toLocaleString()}{suffix}
      </div>
      <p className="text-text-muted text-sm">{label}</p>
    </div>
  )
}

import DemoTourModal from '../components/DemoTourModal'
import MedicalNetwork3D from '../components/MedicalNetwork3D'

/* ─── Main Landing Page ─── */
export default function Landing() {
  const { scrollYProgress } = useScroll()
  const heroOpacity = useTransform(scrollYProgress, [0, 0.15], [1, 0])
  const heroY = useTransform(scrollYProgress, [0, 0.15], [0, -60])
  const [tourOpen, setTourOpen] = useState(false)

  const features = [
    { icon: Activity, title: 'Fill-Probability Meter', desc: 'Real-time calibrated predictions with what-if rate curves. Know your odds before posting.', color: '#6366f1' },
    { icon: Brain, title: 'Vacancy Forecasting', desc: 'Hierarchical time series with fan charts showing 50/80/95% prediction intervals.', color: '#06b6d4' },
    { icon: Shield, title: 'Bayesian Reliability', desc: 'Two-sided trust scores with credible intervals. New-user shrinkage prevents unfair ratings.', color: '#10b981' },
    { icon: HeartPulse, title: 'Fatigue-Safe Scheduling', desc: 'Hard safety constraints that block unsafe bookings. Cumulative fatigue scoring with timeline.', color: '#ef4444' },
    { icon: Zap, title: 'Multi-Shift Optimizer', desc: 'OR-Tools CP-SAT solver for whole-roster assignment. Minimizes cost + travel + fatigue risk.', color: '#f59e0b' },
    { icon: BarChart3, title: 'Fair Rate Engine', desc: 'Quantile regression with empirical-Bayes shrinkage. Surge-capped to prevent exploitation.', color: '#8b5cf6' },
    { icon: TrendingUp, title: 'Pay-Equity Auditor', desc: 'Detects pay gaps with statistical rigor. Fairlearn metrics with bootstrap CIs.', color: '#ec4899' },
    { icon: Clock, title: 'Shadow Roster', desc: 'Probabilistic overbooking with expected-cost optimization. 98% coverage guarantee.', color: '#14b8a6' },
    { icon: Users, title: 'Experimentation Lab', desc: 'A/B testing with CUPED, sequential testing, diff-in-diff, and causal inference toolkit.', color: '#f97316' },
  ]

  return (
    <div className="min-h-screen">
      {/* Synthetic data banner */}
      <div className="synthetic-banner flex items-center justify-between px-6 py-1">
        <span>🔬 Synthetic Data Demo — All clinical records are simulated for demonstration purposes</span>
        <button
          onClick={() => setTourOpen(true)}
          className="font-bold underline text-white hover:text-accent flex items-center gap-1 text-xs"
        >
          <Sparkles size={12} /> Start 5-Min Tour
        </button>
      </div>

      {/* Navigation */}
      <nav className="fixed top-8 left-0 right-0 z-50">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-primary/25">
              L
            </div>
            <span className="text-xl font-bold gradient-text">LocumIQ</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-text-secondary">
            <a href="#features" className="hover:text-text-primary transition-colors">Features</a>
            <a href="#stats" className="hover:text-text-primary transition-colors">Impact</a>
            <a href="#how" className="hover:text-text-primary transition-colors">How It Works</a>
            <button
              onClick={() => setTourOpen(true)}
              className="hover:text-primary-light font-semibold transition-colors flex items-center gap-1"
            >
              <Sparkles size={14} className="text-accent" /> Tour
            </button>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setTourOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-primary/15 text-primary-light border border-primary/30 hover:bg-primary/25 transition-all"
            >
              <Sparkles size={14} /> Guided Tour
            </button>
            <Link to="/dashboard" className="btn-primary text-sm flex items-center gap-2">
              Launch Demo <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <motion.section
        style={{ opacity: heroOpacity, y: heroY }}
        className="relative min-h-screen flex items-center overflow-hidden"
      >
        {/* 3D Background */}
        <div className="absolute inset-0 z-0">
          <Canvas camera={{ position: [0, 0, 6], fov: 60 }}>
            <Suspense fallback={null}>
              <NeuralNetwork />
              <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
            </Suspense>
          </Canvas>
        </div>

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-surface/40 via-surface/60 to-surface z-10" />

        {/* Hero Content */}
        <div className="relative z-20 max-w-6xl mx-auto px-6 py-32 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-1.5 text-xs text-primary-light mb-6"
            >
              <Sparkles size={14} />
              India's First Predictive Staffing Exchange
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-5xl lg:text-7xl font-black leading-[1.1] mb-6"
            >
              <span className="gradient-text">Forecast.</span>
              <br />
              <span className="gradient-text">Price.</span>
              <br />
              <span className="gradient-text">Match.</span>
              <br />
              <span className="text-text-primary">Protect.</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-lg text-text-secondary max-w-lg mb-8 leading-relaxed"
            >
              LocumIQ transforms locum staffing from a job board into an intelligent marketplace.
              Airline-style revenue management meets healthcare-grade safety — backed by 22 ML models
              with calibrated uncertainty.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap gap-4"
            >
              <Link to="/dashboard" className="btn-primary text-base px-8 py-3 flex items-center gap-2">
                Explore Dashboard <ArrowRight size={18} />
              </Link>
              <Link to="/fill-probability" className="btn-secondary text-base px-8 py-3">
                Try Fill Predictor
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="mt-8 flex items-center gap-6 text-xs text-text-muted"
            >
              {['22 ML Models', 'Free & Open Source', 'WCAG AA Accessible'].map((t) => (
                <div key={t} className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-success" />
                  <span>{t}</span>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Live Demo Widget */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6, type: 'spring' }}
            className="hidden lg:flex justify-center"
          >
            <LiveFillDemo />
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-text-muted/30 flex justify-center pt-2">
            <div className="w-1 h-2 rounded-full bg-text-muted/50" />
          </div>
        </motion.div>
      </motion.section>

      {/* Stats Section */}
      <section id="stats" className="py-20 border-y border-glass-border">
        <div className="max-w-5xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
          <StatCounter value={22} label="ML Models" />
          <StatCounter value={40000} label="Simulated Shifts" suffix="+" />
          <StatCounter value={98} label="Coverage Target" suffix="%" />
          <StatCounter value={2000} label="Locum Profiles" suffix="+" />
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24">
        <div className="max-w-6xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-black gradient-text mb-4">
              Every Feature. Backed by ML.
            </h2>
            <p className="text-text-secondary max-w-2xl mx-auto">
              Not just predictions — calibrated uncertainty, fairness audits, causal inference,
              and hard safety constraints. Every number shows its confidence interval.
            </p>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <FeatureCard key={f.title} {...f} delay={i * 0.08} />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how" className="py-24 bg-surface-2/30">
        <div className="max-w-5xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-black text-center gradient-text mb-16"
          >
            How LocumIQ Works
          </motion.h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Post & Predict', desc: 'Post a shift and instantly see fill probability, fair rate band, and time-to-fill estimates with confidence intervals.' },
              { step: '02', title: 'Match & Optimize', desc: 'Our optimizer finds the best candidates considering credentials, fatigue safety, travel, and cost — not just availability.' },
              { step: '03', title: 'Monitor & Learn', desc: 'MLOps pipeline continuously monitors drift, retrains models, and runs fairness audits. Full transparency via model cards.' },
            ].map(({ step, title, desc }, i) => (
              <motion.div
                key={step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center"
              >
                <div className="text-6xl font-black text-primary/10 mb-4">{step}</div>
                <h3 className="text-xl font-bold text-text-primary mb-2">{title}</h3>
                <p className="text-text-secondary text-sm leading-relaxed">{desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="glass-card p-12 gradient-border"
          >
            <h2 className="text-3xl font-black mb-4 gradient-text">Ready to Explore?</h2>
            <p className="text-text-secondary mb-8">
              Dive into the full predictive staffing dashboard with live ML models,
              interactive visualizations, and the complete MLOps pipeline.
            </p>
            <Link to="/dashboard" className="btn-primary text-lg px-10 py-4 inline-flex items-center gap-3">
              Launch Dashboard <ArrowRight size={20} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-glass-border py-8">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-xs font-bold">L</div>
            <span className="text-sm text-text-muted">LocumIQ — Predictive Staffing Exchange</span>
          </div>
          <p className="text-xs text-text-muted">
            Built with ❤️ for healthcare. Synthetic data only. Not clinical decision-making software.
          </p>
        </div>
      </footer>

      {/* Guided Tour Modal */}
      <DemoTourModal isOpen={tourOpen} onClose={() => setTourOpen(false)} />
    </div>
  )
}
