import React, { useState } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Cell
} from 'recharts'
import { HeartPulse, AlertTriangle, CheckCircle, Clock, Moon, Sun } from 'lucide-react'
import CircadianClock3D from '../components/CircadianClock3D'

export default function FatiguePage() {
  const [selectedLocum, setSelectedLocum] = useState('Dr. Priya Sharma')

  // Simulated fatigue timeline (14 days)
  const timeline = Array.from({ length: 14 }, (_, i) => {
    const hoursWorked = Math.random() > 0.3 ? Math.round(Math.random() * 14) : 0
    const isNight = Math.random() > 0.7
    const fatigue = Math.min(1, hoursWorked / 14 * 0.6 + (isNight ? 0.2 : 0) + Math.random() * 0.15)
    return {
      day: `Day ${i + 1}`,
      dayLabel: new Date(Date.now() - (13 - i) * 86400000).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' }),
      hoursWorked,
      fatigue: Math.round(fatigue * 100) / 100,
      isNight,
      isRest: hoursWorked === 0,
    }
  })

  const currentFatigue = timeline[timeline.length - 1].fatigue
  const consNights = timeline.filter((t, i) => i >= timeline.length - 4 && t.isNight).length
  const hours7d = timeline.slice(-7).reduce((s, t) => s + t.hoursWorked, 0)
  const lastShift = timeline.filter(t => t.hoursWorked > 0).pop()
  const restSince = lastShift ? Math.round((Date.now() - (Date.now() - 8 * 3600000)) / 3600000) : 24

  const isSafe = consNights < 4 && hours7d <= 60 && restSince >= 11
  const blockReasons: string[] = []
  if (consNights >= 4) blockReasons.push(`⛔ ${consNights} consecutive night shifts (max 4). 24h rest required.`)
  if (hours7d > 60) blockReasons.push(`⛔ ${hours7d}h in last 7 days exceeds 60h weekly cap.`)
  if (restSince < 11) blockReasons.push(`⛔ Only ${restSince}h rest since last shift (min 11h required).`)

  const fatigueColor = (v: number) => v > 0.7 ? '#ef4444' : v > 0.4 ? '#f59e0b' : '#10b981'

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Fatigue-Safe Scheduler</h1>
        <p className="text-text-secondary text-sm mt-1">
          Hard safety constraints that <span className="font-semibold text-danger">block</span> unsafe bookings. Never overridable by model.
        </p>
      </div>

      {/* Locum selector */}
      <div className="glass-card px-4 py-3 inline-flex items-center gap-3">
        <HeartPulse size={18} className="text-primary-light" />
        <select
          value={selectedLocum}
          onChange={(e) => setSelectedLocum(e.target.value)}
          className="bg-transparent text-sm text-text-primary focus:outline-none"
        >
          {['Dr. Priya Sharma', 'Dr. Rahul Verma', 'Nurse Anita Desai', 'Dr. Sanjay Patel'].map((n) => (
            <option key={n} value={n}>{n}</option>
          ))}
        </select>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Current Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`glass-card p-6 ${isSafe ? 'border-success/20' : 'border-danger/30'} border`}
        >
          <div className="flex items-center gap-3 mb-6">
            {isSafe ? (
              <CheckCircle size={24} className="text-success" />
            ) : (
              <AlertTriangle size={24} className="text-danger" />
            )}
            <div>
              <h3 className="font-semibold">{isSafe ? 'Safe to Work' : 'BOOKING BLOCKED'}</h3>
              <p className="text-xs text-text-muted">{selectedLocum}</p>
            </div>
          </div>

          {/* Fatigue gauge */}
          <div className="text-center mb-6">
            <div className="relative w-32 h-32 mx-auto">
              <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
                <circle cx="60" cy="60" r="52" fill="none" stroke="#334155" strokeWidth="8" />
                <circle
                  cx="60" cy="60" r="52" fill="none"
                  stroke={fatigueColor(currentFatigue)}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${currentFatigue * 327} 327`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-black" style={{ color: fatigueColor(currentFatigue) }}>
                  {(currentFatigue * 100).toFixed(0)}
                </span>
                <span className="text-[10px] text-text-muted">Fatigue Score</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="space-y-3">
            <div className="flex justify-between items-center p-2.5 rounded-lg bg-surface-2/50">
              <div className="flex items-center gap-2 text-sm text-text-secondary">
                <Moon size={14} /> Consecutive Nights
              </div>
              <span className={`text-sm font-bold ${consNights >= 4 ? 'text-danger' : 'text-text-primary'}`}>
                {consNights}/4
              </span>
            </div>
            <div className="flex justify-between items-center p-2.5 rounded-lg bg-surface-2/50">
              <div className="flex items-center gap-2 text-sm text-text-secondary">
                <Clock size={14} /> Hours (7 days)
              </div>
              <span className={`text-sm font-bold ${hours7d > 60 ? 'text-danger' : 'text-text-primary'}`}>
                {hours7d}h/60h
              </span>
            </div>
            <div className="flex justify-between items-center p-2.5 rounded-lg bg-surface-2/50">
              <div className="flex items-center gap-2 text-sm text-text-secondary">
                <Sun size={14} /> Rest Since Last
              </div>
              <span className={`text-sm font-bold ${restSince < 11 ? 'text-danger' : 'text-success'}`}>
                {restSince}h
              </span>
            </div>
          </div>

          {/* Block reasons */}
          {blockReasons.length > 0 && (
            <div className="mt-4 space-y-2">
              {blockReasons.map((reason, i) => (
                <div key={i} className="p-3 rounded-xl bg-danger/5 border border-danger/20 text-xs text-danger">
                  {reason}
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Fatigue Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-6 lg:col-span-2"
        >
          <h3 className="font-semibold mb-1">14-Day Fatigue Timeline</h3>
          <p className="text-xs text-text-muted mb-4">Exponential-decay cumulative fatigue model</p>

          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={timeline}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
              <XAxis dataKey="dayLabel" tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} domain={[0, 1]} tickFormatter={(v) => `${Math.round(v * 100)}%`} />
              <Tooltip content={({ active, payload }: any) => {
                if (!active || !payload?.[0]) return null
                const d = payload[0].payload
                return (
                  <div className="custom-tooltip">
                    <p className="text-sm font-bold">{d.dayLabel}</p>
                    <p className="text-xs">Hours: {d.hoursWorked}h {d.isNight ? '🌙' : '☀️'}</p>
                    <p className="text-xs" style={{ color: fatigueColor(d.fatigue) }}>
                      Fatigue: {(d.fatigue * 100).toFixed(0)}%
                    </p>
                    {d.isRest && <p className="text-xs text-success">Rest day</p>}
                  </div>
                )
              }} />
              <Bar dataKey="fatigue" radius={[4, 4, 0, 0]}>
                {timeline.map((entry, i) => (
                  <Cell key={i} fill={entry.isRest ? '#334155' : fatigueColor(entry.fatigue)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          {/* Hours worked overlay */}
          <div className="mt-4">
            <p className="text-xs text-text-muted mb-2">Hours Worked</p>
            <div className="flex gap-1">
              {timeline.map((t, i) => (
                <div key={i} className="flex-1 text-center">
                  <div
                    className="h-8 rounded-md flex items-end justify-center mb-1"
                    style={{ background: t.isRest ? '#1e293b' : `${t.isNight ? '#8b5cf620' : '#06b6d420'}` }}
                  >
                    <div
                      className="w-full rounded-md"
                      style={{
                        height: `${(t.hoursWorked / 14) * 100}%`,
                        background: t.isNight ? '#8b5cf6' : '#06b6d4',
                      }}
                    />
                  </div>
                  <span className="text-[8px] text-text-muted">{t.hoursWorked}h</span>
                </div>
              ))}
            </div>
          </div>

          {/* Hard constraints info */}
          <div className="mt-6 p-4 rounded-xl bg-surface-2/30 border border-glass-border">
            <h4 className="text-xs font-semibold text-text-secondary mb-2">⚕️ Hard Safety Constraints (Never Model-Overridable)</h4>
            <div className="grid grid-cols-2 gap-2 text-[10px] text-text-muted">
              <div>• Max consecutive nights: <span className="font-bold text-text-secondary">4</span></div>
              <div>• Min rest between shifts: <span className="font-bold text-text-secondary">11h</span></div>
              <div>• Weekly hour cap: <span className="font-bold text-text-secondary">60h</span></div>
              <div>• Daily hour limit: <span className="font-bold text-text-secondary">14h</span></div>
            </div>
            <p className="text-[10px] text-text-muted mt-2 italic">
              Humans can override soft recommendations with audit-logged reason. Hard constraints are absolute.
            </p>
          </div>
        </motion.div>
      </div>

      {/* 3D Interactive Neuro-Fatigue Borbély Orbit */}
      <CircadianClock3D />
    </div>
  )
}
