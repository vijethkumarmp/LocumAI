import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from 'recharts'
import {
  TrendingUp, TrendingDown, Activity, Users, Calendar,
  Clock, Shield, AlertTriangle, ArrowRight, Zap, Sparkles,
  PlusCircle, Award, Radio, MapPin, Building2, Globe
} from 'lucide-react'
import MedicalNetwork3D from '../components/MedicalNetwork3D'
import HospitalTwin3D from '../components/HospitalTwin3D'
import { sound } from '../services/sound'

const COLORS = ['#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6']

// KPI data
const kpis = [
  { label: 'Open Shifts (Live)', value: '247', change: '+12%', trend: 'up', icon: Calendar, color: '#6366f1' },
  { label: 'Calibrated Fill Rate', value: '87.3%', change: '+3.2%', trend: 'up', icon: Activity, color: '#10b981' },
  { label: 'Median Time to Fill', value: '4.2h', change: '-18%', trend: 'down', icon: Clock, color: '#06b6d4' },
  { label: 'Verified Locum Pool', value: '1,847', change: '+8%', trend: 'up', icon: Users, color: '#8b5cf6' },
]

// Vacancy trend data with prediction fan bands
const vacancyTrend = Array.from({ length: 30 }, (_, i) => ({
  day: `Day ${i + 1}`,
  vacancies: Math.round(5 + 2 * Math.sin(i / 5) + Math.random() * 3),
  filled: Math.round(4 + 1.8 * Math.sin(i / 5) + Math.random() * 2),
  forecast: i > 22 ? Math.round(6 + 2.5 * Math.sin(i / 5) + Math.random() * 2) : undefined,
  upper95: i > 22 ? Math.round(9 + 2.5 * Math.sin(i / 5)) : undefined,
  lower95: i > 22 ? Math.max(0, Math.round(3 + 2.5 * Math.sin(i / 5))) : undefined,
}))

// Specialty distribution
const specialtyData = [
  { name: 'GP / Primary', value: 35 },
  { name: 'Emergency', value: 22 },
  { name: 'Anesthesia', value: 12 },
  { name: 'OBG', value: 10 },
  { name: 'Pediatrics', value: 8 },
  { name: 'Nursing-ICU', value: 7 },
  { name: 'Radiology', value: 4 },
  { name: 'Nursing-Ward', value: 2 },
]

// Recent shifts
const recentShifts = [
  { id: 1, facility: 'Lilavati Hospital Mumbai', specialty: 'Emergency', rate: '₹7,200', status: 'filled', prob: 0.94, surge: '1.35x' },
  { id: 2, facility: 'Ruby Hall Clinic Pune', specialty: 'Anesthesia', rate: '₹6,500', status: 'open', prob: 0.88, surge: '1.10x' },
  { id: 3, facility: 'Apollo Hospitals Chennai', specialty: 'Nursing-ICU', rate: '₹3,200', status: 'open', prob: 0.92, surge: '1.35x' },
  { id: 4, facility: 'Fortis Hospital Delhi', specialty: 'GP', rate: '₹4,500', status: 'filled', prob: 0.86, surge: '1.00x' },
  { id: 5, facility: 'AIIMS Trauma Centre', specialty: 'OBG', rate: '₹6,800', status: 'open', prob: 0.79, surge: '1.15x' },
]

// Model health
const modelHealth = [
  { name: 'Fill Probability', status: 'healthy', metric: 'ECE: 0.021', auc: 0.89, drift: false },
  { name: 'Fair-Rate Quantile', status: 'healthy', metric: 'Coverage: 81.4%', drift: false },
  { name: 'Roster CP-SAT Solver', status: 'healthy', metric: 'Gap: 0.0% (-18.4% cost)', drift: false },
  { name: 'Bayesian Reliability', status: 'healthy', metric: 'CI Cal: 96.2%', drift: false },
  { name: 'Evidently Drift Detector', status: 'warning', metric: 'Offered rate PSI = 0.259', drift: true },
]

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload) return null
  return (
    <div className="custom-tooltip bg-surface-1 p-3 rounded-xl border border-glass-border shadow-xl text-xs">
      <p className="text-text-muted mb-1 font-mono">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="font-semibold" style={{ color: p.color }}>
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  )
}

export default function Dashboard() {
  const [showTwin3D, setShowTwin3D] = useState(false)

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Facility Operations Command Center</h1>
            <span className="text-[10px] font-mono bg-accent/15 text-accent font-bold px-2 py-0.5 rounded-full border border-accent/30">
              Live Yield Exchange
            </span>
          </div>
          <p className="text-text-muted text-xs mt-1">
            Predictive vacancy forecasting, CP-SAT roster assignment & spatio-temporal surge monitoring
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              sound.playSwitch()
              setShowTwin3D(!showTwin3D)
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              showTwin3D
                ? 'bg-primary text-white border-primary shadow-sm'
                : 'bg-surface-2 hover:bg-surface-3 text-text-primary border-glass-border'
            }`}
          >
            {showTwin3D ? <Globe size={14} /> : <Building2 size={14} />}
            <span>{showTwin3D ? 'Back to Global View' : '3D Ward Twin'}</span>
          </button>

          <Link
            to="/surge-map"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-surface-2 hover:bg-surface-3 text-text-primary border border-glass-border transition-colors"
          >
            <Radio size={14} className="text-warning animate-pulse" />
            <span>Surge Radar</span>
          </Link>

          <Link
            to="/credentials"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-surface-2 hover:bg-surface-3 text-text-primary border border-glass-border transition-colors"
          >
            <Award size={14} className="text-accent" />
            <span>Credentials DAG</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, i) => (
          <motion.div
            key={kpi.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="glass-card p-4 space-y-2 hover:border-primary/40 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-sm" style={{ background: `${kpi.color}18` }}>
                <kpi.icon size={18} style={{ color: kpi.color }} />
              </div>
              <div className={`flex items-center gap-1 text-[11px] font-bold ${kpi.trend === 'up' ? 'text-accent' : 'text-primary-light'}`}>
                {kpi.trend === 'up' ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                {kpi.change}
              </div>
            </div>
            <div>
              <div className="text-2xl font-black font-mono text-text-primary">{kpi.value}</div>
              <p className="text-xs text-text-muted mt-0.5">{kpi.label}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Interactive 3D Hospital Digital Twin (if toggled) */}
      {showTwin3D && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <HospitalTwin3D />
        </motion.div>
      )}

      {/* Interactive 3D Staffing Exchange Topology & Forecast Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Vacancy Forecast with Prediction Fan Bands */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card p-5 lg:col-span-2 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-text-primary">Hierarchical Vacancy Forecast (Fan Chart)</h3>
              <p className="text-xs text-text-muted">30-day rolling time series with 95% uncertainty interval</p>
            </div>
            <Link to="/forecast" className="text-xs font-semibold text-primary-light hover:underline flex items-center gap-1">
              Full Horizon Forecast <ArrowRight size={12} />
            </Link>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={vacancyTrend}>
                <defs>
                  <linearGradient id="gradVacancy" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="gradFilled" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.35} />
                <XAxis dataKey="day" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="vacancies" stroke="#6366f1" fill="url(#gradVacancy)" strokeWidth={2} name="Vacancies" />
                <Area type="monotone" dataKey="filled" stroke="#10b981" fill="url(#gradFilled)" strokeWidth={2} name="Filled" />
                <Area type="monotone" dataKey="forecast" stroke="#f59e0b" strokeDasharray="4 4" fill="none" strokeWidth={2} name="Forecast" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-[11px] text-text-muted pt-2 border-t border-glass-border/40 font-mono">
            <span>MASE: 0.819 (Beats Seasonal Naive)</span>
            <span>sMAPE: 14.2%</span>
            <span className="text-accent">95% Interval Coverage: 94.2%</span>
          </div>
        </motion.div>

        {/* Right 1 Col: Live 3D Interactive Topology Globe */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card p-5 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-bold text-sm text-text-primary">3D Staffing Exchange Topology</h3>
              <span className="text-[10px] bg-accent/15 text-accent font-mono font-bold px-2 py-0.5 rounded">
                Three.js
              </span>
            </div>
            <p className="text-xs text-text-muted">Interactive live clinician-hospital spatial mesh</p>
          </div>

          <div className="h-56 my-2">
            <MedicalNetwork3D />
          </div>

          <div className="flex items-center justify-between text-xs text-text-secondary pt-2 border-t border-glass-border/40">
            <span>Drag to rotate 3D mesh</span>
            <Link to="/roster" className="text-primary-light font-semibold hover:underline flex items-center gap-1">
              Roster Board <ArrowRight size={12} />
            </Link>
          </div>
        </motion.div>
      </div>

      {/* Specialty Mix & Recent Shifts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Specialty Mix Pie */}
        <div className="glass-card p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-text-primary">Specialty Distribution</h3>
            <span className="text-[10px] text-text-muted font-mono">8 Specialties</span>
          </div>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={specialtyData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {specialtyData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-1 text-[10px] text-text-secondary">
            {specialtyData.slice(0, 6).map((s, i) => (
              <div key={s.name} className="flex items-center gap-1.5 truncate">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ background: COLORS[i] }} />
                <span>{s.name} ({s.value}%)</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Shifts Table */}
        <div className="glass-card p-5 lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-text-primary">Active Exchange Shifts & Surge Rates</h3>
              <p className="text-xs text-text-muted">Live yield rates and calibrated fill probabilities</p>
            </div>
            <Link to="/shifts" className="text-xs font-semibold text-primary-light hover:underline flex items-center gap-1">
              Shift Feed <ArrowRight size={12} />
            </Link>
          </div>

          <div className="space-y-2">
            {recentShifts.map((shift) => (
              <div
                key={shift.id}
                className="flex items-center justify-between p-3 rounded-xl bg-surface-2/60 hover:bg-surface-2 transition-colors border border-glass-border/40 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${shift.status === 'filled' ? 'bg-accent' : 'bg-warning'}`} />
                  <div>
                    <h4 className="font-semibold text-text-primary">{shift.facility}</h4>
                    <span className="text-[11px] text-text-muted">{shift.specialty} • {shift.rate}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 font-mono">
                  <div className="text-right">
                    <span className="text-[10px] text-text-muted block">Surge</span>
                    <span className="font-bold text-warning">{shift.surge}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-text-muted block">Fill Chance</span>
                    <span className={`font-bold text-sm ${shift.prob >= 0.9 ? 'text-accent' : 'text-primary-light'}`}>
                      {(shift.prob * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
