import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  MapPin, AlertTriangle, Zap, Radio, Users, CheckCircle2,
  Clock, ArrowRight, ShieldAlert, Sparkles, Send, Search
} from 'lucide-react'

interface DistrictData {
  id: string
  name: string
  lat: number
  lng: number
  demandIndex: number // 0 to 1
  specialtySpike: string
  activeOutbreak: boolean
  outbreakType?: string
  surgeMultiplier: number
  openVacancies: number
  locumsInRange: number
}

const DISTRICTS: DistrictData[] = [
  {
    id: 'd1',
    name: 'Mumbai Urban & Coastal',
    lat: 19.076,
    lng: 72.877,
    demandIndex: 0.94,
    specialtySpike: 'Emergency Medicine',
    activeOutbreak: true,
    outbreakType: 'Monsoon Dengue / Acute Febrile Shock',
    surgeMultiplier: 1.35,
    openVacancies: 38,
    locumsInRange: 142
  },
  {
    id: 'd2',
    name: 'Chennai Metro & Industrial',
    lat: 13.082,
    lng: 80.270,
    demandIndex: 0.89,
    specialtySpike: 'Nursing-ICU & Critical Care',
    activeOutbreak: true,
    outbreakType: 'Post-Monsoon Waterborne Illness Surge',
    surgeMultiplier: 1.35,
    openVacancies: 29,
    locumsInRange: 96
  },
  {
    id: 'd3',
    name: 'Hyderabad Cyberabad',
    lat: 17.385,
    lng: 78.486,
    demandIndex: 0.82,
    specialtySpike: 'Anesthesia (Surgical OT)',
    activeOutbreak: false,
    surgeMultiplier: 1.20,
    openVacancies: 19,
    locumsInRange: 88
  },
  {
    id: 'd4',
    name: 'Pune IT & Semi-Urban',
    lat: 18.520,
    lng: 73.856,
    demandIndex: 0.74,
    specialtySpike: 'GP / Primary Care',
    activeOutbreak: false,
    surgeMultiplier: 1.10,
    openVacancies: 14,
    locumsInRange: 110
  },
  {
    id: 'd5',
    name: 'Bengaluru Tech Corridor',
    lat: 12.971,
    lng: 77.594,
    demandIndex: 0.68,
    specialtySpike: 'Pediatrics OPD',
    activeOutbreak: false,
    surgeMultiplier: 1.05,
    openVacancies: 12,
    locumsInRange: 130
  },
  {
    id: 'd6',
    name: 'Lucknow Central District',
    lat: 26.846,
    lng: 80.946,
    demandIndex: 0.78,
    specialtySpike: 'Emergency & Trauma',
    activeOutbreak: false,
    surgeMultiplier: 1.18,
    openVacancies: 17,
    locumsInRange: 72
  }
]

interface GeofencedCandidate {
  id: string
  name: string
  specialty: string
  distanceKm: number
  reliability: number
  fatigueScore: number
  fatigueSafe: boolean
  matchScore: number
  etaMins: number
}

const GEOFENCED_LOCUMS: GeofencedCandidate[] = [
  {
    id: 'l1',
    name: 'Dr. Priya Sharma',
    specialty: 'Emergency Medicine',
    distanceKm: 6.2,
    reliability: 0.96,
    fatigueScore: 0.18,
    fatigueSafe: true,
    matchScore: 0.95,
    etaMins: 22
  },
  {
    id: 'l2',
    name: 'Dr. Arjun Mehta',
    specialty: 'Emergency Medicine',
    distanceKm: 11.5,
    reliability: 0.91,
    fatigueScore: 0.22,
    fatigueSafe: true,
    matchScore: 0.89,
    etaMins: 38
  },
  {
    id: 'l3',
    name: 'Dr. Sneha Roy',
    specialty: 'Emergency Medicine',
    distanceKm: 18.0,
    reliability: 0.88,
    fatigueScore: 0.32,
    fatigueSafe: true,
    matchScore: 0.82,
    etaMins: 55
  }
]

export default function SurgeAlertsMap() {
  const [selectedDistrict, setSelectedDistrict] = useState<DistrictData>(DISTRICTS[0])
  const [broadcastSent, setBroadcastSent] = useState(false)

  const handleBroadcastNudges = () => {
    setBroadcastSent(true)
    setTimeout(() => setBroadcastSent(false), 3500)
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 rounded-xl bg-warning/15 text-warning">
              <Zap size={26} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Spatio-Temporal Surge Mode & District Alerts</h1>
              <p className="text-sm text-text-muted">
                Epidemiological disease spike forecasts, real-time geofenced candidate matching & dynamic surge pricing bounds
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleBroadcastNudges}
          disabled={broadcastSent}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            broadcastSent
              ? 'bg-accent/20 text-accent border border-accent/40'
              : 'bg-primary hover:bg-primary-hover text-white shadow-lg shadow-primary/20 active:scale-95'
          }`}
        >
          <Send size={14} className={broadcastSent ? 'animate-bounce' : ''} />
          {broadcastSent ? '✅ Broadcast Sent to 142 Locums' : 'Broadcast Geofenced Nudges'}
        </button>
      </div>

      {/* Outbreak Alert Bar */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-warning/20 via-primary/15 to-danger/15 border border-warning/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-warning/20 text-warning flex items-center justify-center shrink-0 font-bold">
            <AlertTriangle size={20} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-text-primary uppercase tracking-wider">
              Active Surge State: Monsoon Outbreak Index = 0.78 (Elevated Demand)
            </h4>
            <p className="text-xs text-text-muted mt-0.5">
              Coastal emergency departments qualify for up to 1.35x surge multiplier (clamped at 1.50x fair-rate limit).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="bg-surface-2 px-3 py-1 rounded-lg border border-glass-border text-text-primary">
            Surge Cap: 1.50x Max
          </span>
        </div>
      </div>

      {/* Grid: District Heat Selector + Geofenced Candidates */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Districts Heatmap Grid */}
        <div className="lg:col-span-2 space-y-4">
          <div className="glass-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-sm text-text-primary">District-Level Demand Radar</h3>
                <p className="text-xs text-text-muted">Select a healthcare district to view localized candidate pool</p>
              </div>
              <span className="text-xs font-mono text-text-muted bg-surface-2 px-2.5 py-1 rounded">
                6 Active Monitored Hubs
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {DISTRICTS.map(dist => {
                const isSelected = selectedDistrict.id === dist.id
                const isOutbreak = dist.activeOutbreak

                return (
                  <div
                    key={dist.id}
                    onClick={() => setSelectedDistrict(dist)}
                    className={`p-4 rounded-xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-surface-2 border-primary shadow-lg shadow-primary/15'
                        : 'bg-surface-2/60 hover:bg-surface-2 border-glass-border'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <MapPin size={16} className={isOutbreak ? 'text-warning' : 'text-primary-light'} />
                        <h4 className="font-bold text-sm text-text-primary">{dist.name}</h4>
                      </div>
                      {isOutbreak ? (
                        <span className="text-[10px] bg-danger/20 text-danger font-bold px-1.5 py-0.5 rounded border border-danger/30 flex items-center gap-1">
                          <Radio size={10} className="animate-pulse" /> OUTBREAK
                        </span>
                      ) : (
                        <span className="text-[10px] bg-surface-3 text-text-muted font-bold px-1.5 py-0.5 rounded">
                          NORMAL
                        </span>
                      )}
                    </div>

                    <div className="space-y-1.5 text-xs text-text-secondary">
                      <div className="flex justify-between">
                        <span>Spike Specialty:</span>
                        <span className="font-semibold text-text-primary">{dist.specialtySpike}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Demand Heat Index:</span>
                        <span className="font-mono font-bold text-accent">
                          {(dist.demandIndex * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Surge Pricing:</span>
                        <span className="font-mono font-bold text-warning">{dist.surgeMultiplier.toFixed(2)}x</span>
                      </div>
                    </div>

                    {isOutbreak && dist.outbreakType && (
                      <div className="mt-2.5 pt-2 border-t border-glass-border/40 text-[10px] text-warning truncate">
                        ⚠️ {dist.outbreakType}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Geofenced Candidate Dispatch */}
        <div className="glass-card p-5 space-y-5 flex flex-col">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Users size={18} className="text-primary-light" />
              <h3 className="font-bold text-sm text-text-primary">Geofenced Locum Candidates</h3>
            </div>
            <p className="text-xs text-text-muted">
              Matching candidates within travel radius of <strong className="text-text-primary">{selectedDistrict.name}</strong>
            </p>
          </div>

          <div className="space-y-3">
            {GEOFENCED_LOCUMS.map(loc => (
              <div key={loc.id} className="p-3.5 rounded-xl bg-surface-2 border border-glass-border space-y-2 text-xs">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-text-primary">{loc.name}</h4>
                    <span className="text-[11px] text-text-muted">{loc.specialty}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-accent text-sm">
                      {(loc.matchScore * 100).toFixed(0)}%
                    </span>
                    <span className="text-[10px] text-text-muted block">Match</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-text-secondary pt-1 border-t border-glass-border/40">
                  <div>
                    <span className="text-text-muted block">Distance</span>
                    <span>{loc.distanceKm} km</span>
                  </div>
                  <div>
                    <span className="text-text-muted block">Transit ETA</span>
                    <span>~{loc.etaMins} mins</span>
                  </div>
                  <div>
                    <span className="text-text-muted block">Fatigue Safe</span>
                    <span className="text-accent font-bold">Yes (0.18)</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-surface-2/60 rounded-xl border border-glass-border text-xs text-text-muted space-y-1">
            <div className="flex justify-between text-text-primary font-semibold">
              <span>District Pool Size:</span>
              <span className="font-mono">{selectedDistrict.locumsInRange} Available</span>
            </div>
            <p className="text-[11px]">
              Bandit nudge optimizer selects optimal dispatch channel (WhatsApp vs SMS) per locum based on historical conversion velocity.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
