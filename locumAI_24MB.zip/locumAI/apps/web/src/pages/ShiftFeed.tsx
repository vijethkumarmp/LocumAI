import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Stethoscope, MapPin, Calendar, Clock, DollarSign, Shield,
  HeartPulse, Activity, AlertTriangle, CheckCircle, MessageSquare,
  Send, Sparkles, Filter, ChevronDown, ChevronUp, User, Info, Building2
} from 'lucide-react'

interface ShiftItem {
  id: string
  facilityName: string
  specialty: string
  location: string
  tier: 'metro' | 'tier-2' | 'rural'
  date: string
  timing: string
  isNight: boolean
  isUrgent: boolean
  offeredRate: number
  fairBandP50: number
  facilityReliability: {
    mean: number
    ci: [number, number]
    nBookings: number
    summary: string
  }
  workload: {
    avgPatients: number
    highAcuityPct: number
    seniorBackup: boolean
    cluster: string
  }
  distanceKm: number
}

const MOCK_SHIFTS: ShiftItem[] = [
  {
    id: 'SF-101',
    facilityName: 'Lilavati Hospital & Research Centre',
    specialty: 'Emergency Medicine',
    location: 'Bandra, Mumbai',
    tier: 'metro',
    date: 'Tomorrow, Oct 29',
    timing: 'Night (20:00 - 08:00)',
    isNight: true,
    isUrgent: true,
    offeredRate: 7200,
    fairBandP50: 6800,
    facilityReliability: {
      mean: 0.94,
      ci: [0.91, 0.97],
      nBookings: 142,
      summary: 'Prompt 24h payments. Workload accurately represented.'
    },
    workload: {
      avgPatients: 46,
      highAcuityPct: 32,
      seniorBackup: true,
      cluster: 'High-Volume Tertiary'
    },
    distanceKm: 8.5
  },
  {
    id: 'SF-102',
    facilityName: 'Ruby Hall Clinic',
    specialty: 'Anesthesia',
    location: 'Sassoon Road, Pune',
    tier: 'tier-2',
    date: 'Friday, Oct 30',
    timing: 'Day (08:00 - 17:00)',
    isNight: false,
    isUrgent: false,
    offeredRate: 6500,
    fairBandP50: 6200,
    facilityReliability: {
      mean: 0.88,
      ci: [0.83, 0.93],
      nBookings: 88,
      summary: 'Reliable payment record within 48h. Verified OT backup.'
    },
    workload: {
      avgPatients: 14,
      highAcuityPct: 24,
      seniorBackup: true,
      cluster: 'Surgical Specialty'
    },
    distanceKm: 14.0
  },
  {
    id: 'SF-103',
    facilityName: 'District Civil Hospital',
    specialty: 'GP / Primary Care',
    location: 'Alibag, Rural Maharashtra',
    tier: 'rural',
    date: 'Saturday, Oct 31',
    timing: 'Day (09:00 - 18:00)',
    isNight: false,
    isUrgent: true,
    offeredRate: 4800,
    fairBandP50: 3800,
    facilityReliability: {
      mean: 0.79,
      ci: [0.72, 0.86],
      nBookings: 34,
      summary: 'Occasional government treasury disbursement delays.'
    },
    workload: {
      avgPatients: 58,
      highAcuityPct: 15,
      seniorBackup: false,
      cluster: 'High-Volume Primary'
    },
    distanceKm: 42.0
  },
  {
    id: 'SF-104',
    facilityName: 'Apollo Hospitals Greams Road',
    specialty: 'Nursing-ICU',
    location: 'Chennai, Tamil Nadu',
    tier: 'metro',
    date: 'Sunday, Nov 01',
    timing: 'Night (20:00 - 08:00)',
    isNight: true,
    isUrgent: false,
    offeredRate: 3200,
    fairBandP50: 3000,
    facilityReliability: {
      mean: 0.97,
      ci: [0.94, 0.99],
      nBookings: 310,
      summary: 'Flawless same-day settlement. Full clinical senior staff on duty.'
    },
    workload: {
      avgPatients: 6,
      highAcuityPct: 85,
      seniorBackup: true,
      cluster: 'Critical Care ICU'
    },
    distanceKm: 11.2
  }
]

export default function ShiftFeed() {
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all')
  const [selectedShift, setSelectedShift] = useState<ShiftItem | null>(null)
  const [netPayDetailsOpen, setNetPayDetailsOpen] = useState<string | null>(null)
  const [bookingStatus, setBookingStatus] = useState<Record<string, 'booked' | 'blocked'>>({})
  
  // WhatsApp Agent Chat State
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'agent' | 'user'; text: string; time: string }>>([
    {
      sender: 'agent',
      text: 'Namaste Dr. Sharma! 👋 I noticed you have 2 days off before your next shift. We have a high-demand Emergency shift at Lilavati Hospital paying ₹7,200 (+₹400 surge). Would you like me to book it?',
      time: '18:42'
    }
  ])
  const [inputMessage, setInputMessage] = useState('')

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return
    const userText = inputMessage
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    setChatMessages(prev => [...prev, { sender: 'user', text: userText, time }])
    setInputMessage('')

    setTimeout(() => {
      let reply = "Understood! I verified your 7-day fatigue score (0.32 - Safe) and confirmed your MCI certificate is active. Shift SH-101 has been reserved for you! 🩺"
      if (userText.toLowerCase().includes('fatigue') || userText.toLowerCase().includes('night')) {
        reply = "I checked your schedule: you have 18 hours of continuous rest before this shift, which fully satisfies the 11h mandatory rest rule."
      }
      setChatMessages(prev => [...prev, { sender: 'agent', text: reply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }])
    }, 900)
  }

  const handleBook = (shift: ShiftItem) => {
    // If shift is night and user simulated consecutive nights limit:
    if (shift.isNight && shift.id === 'SF-104') {
      setBookingStatus(prev => ({ ...prev, [shift.id]: 'blocked' }))
      return
    }
    setBookingStatus(prev => ({ ...prev, [shift.id]: 'booked' }))
  }

  const calculateNetPay = (gross: number, distanceKm: number) => {
    const tds = Math.round(gross * 0.10) // 10% illustrative TDS
    const travel = Math.round(distanceKm * 8) // ₹8/km travel allowance
    const insurance = 150
    const net = gross - tds - travel - insurance
    return { gross, tds, travel, insurance, net, hourly: Math.round(net / 12) }
  }

  const filteredShifts = selectedSpecialty === 'all'
    ? MOCK_SHIFTS
    : MOCK_SHIFTS.filter(s => s.specialty.toLowerCase().includes(selectedSpecialty.toLowerCase()))

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2.5 rounded-xl bg-primary/10 text-primary-light">
              <Stethoscope size={26} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Locum Exchange Feed</h1>
              <p className="text-sm text-text-muted">
                Transparent shifts with workload fingerprints, true net-pay breakdowns & automated fatigue guardrails
              </p>
            </div>
          </div>
        </div>

        {/* Specialty Filter */}
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-text-muted" />
          <select
            value={selectedSpecialty}
            onChange={e => setSelectedSpecialty(e.target.value)}
            className="bg-surface-2 border border-glass-border rounded-xl px-3 py-2 text-xs text-text-primary focus:outline-none focus:border-primary"
          >
            <option value="all">All Specialties</option>
            <option value="Emergency">Emergency</option>
            <option value="Anesthesia">Anesthesia</option>
            <option value="GP">GP / Primary Care</option>
            <option value="Nursing">Nursing-ICU</option>
          </select>
        </div>
      </div>

      {/* Surge Alert Banner */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-warning/15 via-primary/15 to-accent/15 border border-warning/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-warning/20 text-warning flex items-center justify-center font-bold">
            ⚡
          </div>
          <div>
            <h4 className="text-xs font-bold text-text-primary uppercase tracking-wider">
              Monsoon Dengue Spike Alert: Mumbai & Chennai Metro Clusters
            </h4>
            <p className="text-xs text-text-muted">
              Emergency & ICU shifts currently qualify for 1.35x surge multiplier (capped at 1.50x by Fair-Rate Engine).
            </p>
          </div>
        </div>
        <span className="text-xs font-mono font-bold text-warning bg-warning/10 px-3 py-1 rounded-md hidden md:inline">
          Active Outbreak Index: 0.78
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Shift Cards List */}
        <div className="lg:col-span-2 space-y-4">
          {filteredShifts.map(shift => {
            const netPay = calculateNetPay(shift.offeredRate, shift.distanceKm)
            const isDetailsOpen = netPayDetailsOpen === shift.id
            const status = bookingStatus[shift.id]

            return (
              <div key={shift.id} className="glass-card p-5 space-y-4 transition-all hover:border-primary/40">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-bold text-base text-text-primary">{shift.specialty}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface-3 text-text-secondary uppercase">
                        {shift.tier}
                      </span>
                      {shift.isUrgent && (
                        <span className="text-[10px] bg-danger/15 text-danger font-bold px-2 py-0.5 rounded border border-danger/30">
                          URGENT FILL
                        </span>
                      )}
                      {shift.isNight && (
                        <span className="text-[10px] bg-primary/15 text-primary-light font-bold px-2 py-0.5 rounded border border-primary/30">
                          NIGHT SHIFT
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-xs text-text-secondary">
                      <Building2 size={14} className="text-text-muted" />
                      <span className="font-medium text-text-primary">{shift.facilityName}</span>
                      <span>•</span>
                      <MapPin size={13} className="text-text-muted" />
                      <span>{shift.location} ({shift.distanceKm} km away)</span>
                    </div>
                  </div>

                  {/* Rate Badge */}
                  <div className="text-right">
                    <div className="text-2xl font-black text-accent font-mono">
                      ₹{shift.offeredRate.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-text-muted">
                      Market Median: ₹{shift.fairBandP50.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Badges: Workload Fingerprint & Bayesian Reliability */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-glass-border/40">
                  {/* Workload Fingerprint */}
                  <div className="p-3 rounded-lg bg-surface-2 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-text-primary flex items-center gap-1.5">
                        <Activity size={13} className="text-primary-light" /> Workload Fingerprint
                      </span>
                      <span className="text-[10px] font-mono text-text-muted">{shift.workload.cluster}</span>
                    </div>
                    <p className="text-[11px] text-text-secondary">
                      ~{shift.workload.avgPatients} patients/shift • {shift.workload.highAcuityPct}% high acuity
                      • {shift.workload.seniorBackup ? 'Senior backup on duty' : 'Solo coverage'}
                    </p>
                  </div>

                  {/* Bayesian Reliability Score */}
                  <div className="p-3 rounded-lg bg-surface-2 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-text-primary flex items-center gap-1.5">
                        <Shield size={13} className="text-accent" /> Facility Trust Score
                      </span>
                      <span className="font-mono font-bold text-accent">
                        {(shift.facilityReliability.mean * 100).toFixed(0)}%
                        <span className="text-[10px] text-text-muted font-normal ml-1">
                          [{(shift.facilityReliability.ci[0] * 100).toFixed(0)}-{(shift.facilityReliability.ci[1] * 100).toFixed(0)}%]
                        </span>
                      </span>
                    </div>
                    <p className="text-[11px] text-text-secondary truncate">
                      {shift.facilityReliability.summary}
                    </p>
                  </div>
                </div>

                {/* Net-Pay Calculator Accordion */}
                <div>
                  <button
                    onClick={() => setNetPayDetailsOpen(isDetailsOpen ? null : shift.id)}
                    className="flex items-center gap-1 text-xs text-primary-light hover:underline font-medium"
                  >
                    <span>True Net-Pay Calculator (Est. in-pocket: ₹{netPay.net.toLocaleString()})</span>
                    {isDetailsOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </button>

                  <AnimatePresence>
                    {isDetailsOpen && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-3 p-3.5 rounded-xl bg-surface-0 border border-glass-border space-y-2 text-xs font-mono"
                      >
                        <div className="flex justify-between text-text-secondary">
                          <span>Gross Offered Amount:</span>
                          <span className="text-text-primary">+₹{netPay.gross.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-text-secondary">
                          <span>Illustrative TDS (10% slab):</span>
                          <span className="text-danger">-₹{netPay.tds.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-text-secondary">
                          <span>Estimated Travel Expense ({shift.distanceKm}km @ ₹8/km):</span>
                          <span className="text-danger">-₹{netPay.travel.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-text-secondary">
                          <span>Professional Indemnity Micro-Insurance:</span>
                          <span className="text-danger">-₹{netPay.insurance}</span>
                        </div>
                        <div className="flex justify-between border-t border-glass-border/40 pt-2 font-bold text-sm">
                          <span className="text-accent">Estimated Net in Pocket:</span>
                          <span className="text-accent font-black">₹{netPay.net.toLocaleString()} (~₹{netPay.hourly}/hr)</span>
                        </div>
                        <p className="text-[10px] text-text-muted font-sans italic mt-1">
                          Disclaimer: Illustrative estimate for planning only; does not constitute formal tax advice.
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Action Bar */}
                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-1.5 text-xs text-text-muted">
                    <Clock size={13} />
                    <span>{shift.timing}</span>
                  </div>

                  <div>
                    {status === 'booked' ? (
                      <span className="flex items-center gap-1.5 text-xs font-bold text-accent bg-accent/15 px-3 py-1.5 rounded-lg border border-accent/30">
                        <CheckCircle size={14} /> Booking Confirmed!
                      </span>
                    ) : status === 'blocked' ? (
                      <span className="flex items-center gap-1.5 text-xs font-bold text-danger bg-danger/15 px-3 py-1.5 rounded-lg border border-danger/30">
                        <AlertTriangle size={14} /> ⛔ Blocked: 4 Consecutive Nights Limit Reached
                      </span>
                    ) : (
                      <button
                        onClick={() => handleBook(shift)}
                        className="px-4 py-2 rounded-xl text-xs font-bold bg-primary hover:bg-primary-hover text-white shadow-md shadow-primary/20 transition-all active:scale-95"
                      >
                        Accept & Verify Safety
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Right 1 Col: Simulated WhatsApp Booking Agent */}
        <div className="glass-card p-5 flex flex-col h-[640px]">
          <div className="flex items-center gap-3 border-b border-glass-border pb-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg">
              💬
            </div>
            <div>
              <h3 className="font-bold text-sm text-text-primary">LocumIQ WhatsApp Assistant</h3>
              <p className="text-[11px] text-text-muted flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Online • AI Dispatcher
              </p>
            </div>
          </div>

          {/* Chat transcript */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
            {chatMessages.map((msg, i) => (
              <div
                key={i}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-primary text-white rounded-br-none'
                      : 'bg-surface-2 text-text-primary rounded-bl-none border border-glass-border'
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[9px] text-text-muted mt-1 px-1">{msg.time}</span>
              </div>
            ))}
          </div>

          {/* Message Input */}
          <div className="pt-3 border-t border-glass-border flex gap-2">
            <input
              type="text"
              placeholder="e.g. Can I take a night shift in Mumbai?"
              value={inputMessage}
              onChange={e => setInputMessage(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 bg-surface-2 border border-glass-border rounded-xl px-3 py-2 text-xs text-text-primary focus:outline-none focus:border-primary"
            />
            <button
              onClick={handleSendMessage}
              className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
            >
              <Send size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
