import React, { useState } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Cell
} from 'recharts'
import { Shield, Star, Clock, AlertCircle, TrendingUp, Users } from 'lucide-react'

interface ReliabilityData {
  name: string
  type: 'locum' | 'facility'
  score: number
  ci: [number, number]
  n: number
  isNew: boolean
  components: Record<string, number>
  plainLanguage: string
}

const mockData: ReliabilityData[] = [
  {
    name: 'Dr. Priya Sharma', type: 'locum', score: 0.94, ci: [0.90, 0.97], n: 87,
    isNew: false,
    components: { show_rate: 0.96, on_time: 0.93, rating: 4.7, cancel_rate: 0.04 },
    plainLanguage: 'Score 94% (95% CI: 90%–97%) based on 87 shifts. Highly reliable.',
  },
  {
    name: 'Dr. Rahul Verma', type: 'locum', score: 0.72, ci: [0.58, 0.84], n: 15,
    isNew: true,
    components: { show_rate: 0.80, on_time: 0.87, rating: 4.1, cancel_rate: 0.13 },
    plainLanguage: 'New user — limited data. Score 72% (95% CI: 58%–84%) based on 15 shifts. Some reliability concerns.',
  },
  {
    name: 'Apollo Mumbai', type: 'facility', score: 0.91, ci: [0.88, 0.94], n: 230,
    isNew: false,
    components: { payment_timeliness: 0.95, workload_accuracy: 0.88, cancel_rate: 0.05, rating: 4.5 },
    plainLanguage: 'Score 91% (95% CI: 88%–94%) based on 230 bookings. Payment timeliness is excellent.',
  },
  {
    name: 'PHC Raigad', type: 'facility', score: 0.63, ci: [0.48, 0.77], n: 22,
    isNew: false,
    components: { payment_timeliness: 0.68, workload_accuracy: 0.72, cancel_rate: 0.14, rating: 3.6 },
    plainLanguage: 'Score 63% (95% CI: 48%–77%) based on 22 bookings. Payment timeliness is a concern.',
  },
]

const scoreColor = (s: number) => s > 0.85 ? '#10b981' : s > 0.65 ? '#f59e0b' : '#ef4444'

export default function ReliabilityPage() {
  const [selected, setSelected] = useState<ReliabilityData>(mockData[0])
  const [tab, setTab] = useState<'locum' | 'facility'>('locum')

  const filtered = mockData.filter((d) => d.type === tab)

  // Distribution data for the chart
  const distData = Array.from({ length: 20 }, (_, i) => {
    const bin = (i * 5)
    const density = Math.exp(-((bin - selected.score * 100) ** 2) / (2 * 10 ** 2))
    return { bin: `${bin}%`, density: Math.round(density * 100) / 100 }
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Bayesian Reliability Scores</h1>
        <p className="text-text-secondary text-sm mt-1">
          Beta-Binomial posterior with empirical-Bayes prior. Two-sided trust with credible intervals.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {[
          { key: 'locum' as const, label: 'Locum Scores', icon: Users },
          { key: 'facility' as const, label: 'Facility Scores', icon: Shield },
        ].map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => { setTab(key); setSelected(mockData.find((d) => d.type === key)!) }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm transition-all ${
              tab === key ? 'bg-primary/10 text-primary-light border border-primary/30' : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Score Cards */}
        <div className="space-y-3">
          {filtered.map((item) => (
            <motion.button
              key={item.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => setSelected(item)}
              className={`w-full text-left glass-card p-4 transition-all ${
                selected.name === item.name ? 'border-primary/30 glow-primary' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div>
                  <p className="font-medium text-sm">{item.name}</p>
                  <p className="text-[10px] text-text-muted">{item.n} observations</p>
                </div>
                <div className="text-right">
                  <span className="text-xl font-black" style={{ color: scoreColor(item.score) }}>
                    {(item.score * 100).toFixed(0)}%
                  </span>
                  {item.isNew && (
                    <p className="text-[10px] text-warning">NEW</p>
                  )}
                </div>
              </div>
              {/* CI bar */}
              <div className="ci-bar h-4 mt-2">
                <div
                  className="ci-range"
                  style={{
                    left: `${item.ci[0] * 100}%`,
                    right: `${(1 - item.ci[1]) * 100}%`,
                    background: scoreColor(item.score),
                  }}
                />
                <div
                  className="ci-point"
                  style={{
                    left: `${item.score * 100}%`,
                    transform: 'translateX(-50%)',
                    background: scoreColor(item.score),
                  }}
                />
              </div>
              <p className="text-[9px] text-text-muted mt-1">
                95% CI: [{(item.ci[0] * 100).toFixed(0)}%, {(item.ci[1] * 100).toFixed(0)}%]
              </p>
            </motion.button>
          ))}
        </div>

        {/* Detail Panel */}
        <motion.div
          key={selected.name}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 lg:col-span-2"
        >
          <div className="flex items-start justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold">{selected.name}</h3>
              <p className="text-xs text-text-muted mt-1">{selected.plainLanguage}</p>
            </div>
            <div className="text-right">
              <span className="text-4xl font-black" style={{ color: scoreColor(selected.score) }}>
                {(selected.score * 100).toFixed(0)}%
              </span>
              <p className="text-[10px] text-text-muted">Reliability Score</p>
            </div>
          </div>

          {/* Components */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            {Object.entries(selected.components).map(([key, value]) => {
              const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
              const isRate = key.includes('rate')
              const displayValue = key === 'rating' ? value.toFixed(1) : `${(value * 100).toFixed(0)}%`
              return (
                <div key={key} className="p-3 rounded-xl bg-surface-2/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-text-muted">{label}</span>
                    <span className="text-sm font-bold" style={{ color: key === 'cancel_rate' ? (value > 0.1 ? '#ef4444' : '#10b981') : scoreColor(typeof value === 'number' && value <= 1 ? value : value / 5) }}>
                      {displayValue}
                    </span>
                  </div>
                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${key === 'rating' ? (value / 5) * 100 : key === 'cancel_rate' ? (1 - value) * 100 : value * 100}%`,
                        background: key === 'cancel_rate' ? (value > 0.1 ? '#ef4444' : '#10b981') : '#6366f1',
                      }}
                    />
                  </div>
                </div>
              )
            })}
          </div>

          {/* Posterior distribution */}
          <div>
            <h4 className="text-sm font-semibold mb-2">Posterior Distribution</h4>
            <p className="text-[10px] text-text-muted mb-3">Beta-Binomial with empirical-Bayes cohort prior</p>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={distData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis dataKey="bin" tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} />
                <YAxis hide />
                <Tooltip content={({ active, payload }: any) => active && payload?.[0] ? (
                  <div className="custom-tooltip">
                    <p className="text-xs">P(score = {payload[0].payload.bin}) = {payload[0].value}</p>
                  </div>
                ) : null} />
                <Bar dataKey="density" radius={[2, 2, 0, 0]}>
                  {distData.map((_, i) => (
                    <Cell key={i} fill={`rgba(99, 102, 241, ${0.3 + distData[i].density * 0.7})`} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Shrinkage note */}
          {selected.isNew && (
            <div className="mt-4 p-3 rounded-xl bg-warning/5 border border-warning/20 flex items-start gap-2">
              <AlertCircle size={14} className="text-warning mt-0.5 shrink-0" />
              <p className="text-xs text-text-secondary">
                <span className="font-semibold text-warning">New user shrinkage applied.</span> With only {selected.n} observations,
                the score is pulled toward the cohort average to prevent unfair early ratings.
                The wide credible interval reflects genuine uncertainty.
              </p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
