import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import {
  Sparkles, X, ChevronRight, ChevronLeft, Activity, Calendar,
  Shield, Stethoscope, HeartPulse, Cpu, ArrowRight, CheckCircle2
} from 'lucide-react'

interface TourStep {
  step: number
  title: string
  subtitle: string
  path: string
  icon: any
  tagline: string
  keyInsight: string
  actions: string[]
}

const TOUR_STEPS: TourStep[] = [
  {
    step: 1,
    title: 'Fill-Probability Meter & Elasticity Curve',
    subtitle: 'Airline-Style Revenue & Yield Management',
    path: '/fill-probability',
    icon: Activity,
    tagline: 'Predicts fill probability within 48h with isotonic calibration & conformal intervals.',
    keyInsight: 'Hospitals can drag the rate slider to see live win probability, conformal 95% uncertainty bounds, and the exact rate needed for 90% fill.',
    actions: ['Live interactive rate slider', 'Conformal prediction interval', 'Monotone what-if rate curve']
  },
  {
    step: 2,
    title: 'Shadow Roster & CP-SAT Match Optimizer',
    subtitle: 'Expected-Cost Probabilistic Overbooking',
    path: '/roster',
    icon: Calendar,
    tagline: 'Solves whole-hospital shift rosters in 134ms with 0.0% optimality gap.',
    keyInsight: 'Beats greedy allocation by 18.4% in cost while retaining standby locums whenever no-show cost exceeds retainer fees.',
    actions: ['Run OR-Tools CP-SAT solver', 'Inspect SHAP match explanations', 'Probabilistic standby badges']
  },
  {
    step: 3,
    title: 'Two-Sided Bayesian Reliability Scores',
    subtitle: 'Beta-Binomial Posterior & Shrinkage',
    path: '/reliability',
    icon: Shield,
    tagline: 'Credit-score-style mutual trust eliminating noisy 5-star ratings.',
    keyInsight: 'Shrinks new providers toward population priors while exposing transparent 95% Credible Intervals.',
    actions: ['Compare veteran vs new locum', 'View facility payment timeliness', 'Transparent Credible Interval bars']
  },
  {
    step: 4,
    title: 'Shift Feed & Workload Fingerprints',
    subtitle: 'Unsupervised Facility Clustering & True Net-Pay',
    path: '/shifts',
    icon: Stethoscope,
    tagline: 'Transparent clinical workload fingerprints and exact post-tax net earnings.',
    keyInsight: 'Locums see ~46 OPD patients, 32% high acuity, senior backup, and post-TDS pocket earnings before booking.',
    actions: ['Workload fingerprint card', 'True Net-Pay calculator', 'Simulated WhatsApp booking assistant']
  },
  {
    step: 5,
    title: 'Unbreachable Fatigue Safety Guardrail',
    subtitle: 'Two-Process Sleep Homeostasis Model',
    path: '/fatigue',
    icon: HeartPulse,
    tagline: 'Clinician safety rules are non-overridable Boolean constraints.',
    keyInsight: 'No ML score or surge price can override mandatory rest rules. Booking a 5th consecutive night is halted immediately.',
    actions: ['14-day sleep homeostasis curve', 'Unbreachable hard constraint check', 'Human-readable blockage reasons']
  },
  {
    step: 6,
    title: 'Self-Healing MLOps Retrain Loop',
    subtitle: 'Evidently PSI Drift Detection & Auto-Promotion',
    path: '/mlops',
    icon: Cpu,
    tagline: 'Continuous distribution monitoring with automated gate promotions.',
    keyInsight: 'Monitors feature drift. When PSI >= 0.20, triggers automated retraining, checks holdout calibration (ECE < 0.05), and promotes challenger.',
    actions: ['Evidently PSI drift alert', 'Simulate rate inflation shock', 'Automated challenger promotion']
  }
]

interface DemoTourModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function DemoTourModal({ isOpen, onClose }: DemoTourModalProps) {
  const [currentStepIdx, setCurrentStepIdx] = useState(0)
  const navigate = useNavigate()

  if (!isOpen) return null

  const step = TOUR_STEPS[currentStepIdx]
  const Icon = step.icon

  const handleGoToFeature = () => {
    navigate(step.path)
    onClose()
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          className="relative w-full max-w-2xl bg-surface-1 border border-primary/40 rounded-2xl shadow-2xl overflow-hidden z-10"
        >
          {/* Header Banner */}
          <div className="p-6 bg-gradient-to-r from-primary/20 via-surface-2 to-accent/20 border-b border-glass-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-primary/20 text-primary-light">
                  <Sparkles size={18} />
                </span>
                <div>
                  <h2 className="text-lg font-bold text-text-primary">LocumIQ Guided Tour: 6 Killer Moments</h2>
                  <p className="text-xs text-text-muted">Interactive walkthrough of predictive marketplace features</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-3/50 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Stepper Dots */}
            <div className="flex items-center justify-between mt-6">
              {TOUR_STEPS.map((s, idx) => (
                <button
                  key={s.step}
                  onClick={() => setCurrentStepIdx(idx)}
                  className={`flex-1 flex flex-col items-center gap-1.5 py-1 px-0.5 group relative ${
                    idx === currentStepIdx ? 'text-primary-light font-bold' : 'text-text-muted hover:text-text-secondary'
                  }`}
                >
                  <div
                    className={`w-full h-1.5 rounded-full transition-all ${
                      idx === currentStepIdx
                        ? 'bg-primary shadow-sm shadow-primary/50'
                        : idx < currentStepIdx
                        ? 'bg-accent/60'
                        : 'bg-surface-3'
                    }`}
                  />
                  <span className="text-[10px] hidden sm:inline">Moment {s.step}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Body Content */}
          <div className="p-6 space-y-5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white shrink-0 shadow-lg shadow-primary/20">
                <Icon size={24} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-accent uppercase">
                    Moment {step.step} of 6
                  </span>
                  <span className="text-xs text-text-muted">•</span>
                  <span className="text-xs font-semibold text-text-muted">{step.subtitle}</span>
                </div>
                <h3 className="text-xl font-bold text-text-primary mt-1">{step.title}</h3>
                <p className="text-xs text-text-secondary mt-1">{step.tagline}</p>
              </div>
            </div>

            {/* Key Insight Card */}
            <div className="p-4 rounded-xl bg-surface-2 border border-glass-border">
              <span className="text-[10px] font-bold uppercase tracking-wider text-primary-light block mb-1">
                Architectural Innovation
              </span>
              <p className="text-xs text-text-primary leading-relaxed">{step.keyInsight}</p>
            </div>

            {/* Action Checklist */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-text-muted uppercase tracking-wider">
                What to Try on this Page:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {step.actions.map((act, i) => (
                  <div key={i} className="p-2.5 rounded-lg bg-surface-2/60 border border-glass-border/40 flex items-center gap-2 text-xs text-text-secondary">
                    <CheckCircle2 size={13} className="text-accent shrink-0" />
                    <span className="truncate">{act}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer Controls */}
          <div className="p-4 bg-surface-2/50 border-t border-glass-border flex items-center justify-between">
            <button
              onClick={() => setCurrentStepIdx(prev => Math.max(0, prev - 1))}
              disabled={currentStepIdx === 0}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentStepIdx === 0
                  ? 'text-text-muted opacity-40 cursor-not-allowed'
                  : 'text-text-secondary hover:text-text-primary hover:bg-surface-3'
              }`}
            >
              <ChevronLeft size={14} /> Previous
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleGoToFeature}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-primary hover:bg-primary-hover text-white shadow-md shadow-primary/25 transition-all active:scale-95"
              >
                <span>Jump to Live Page</span>
                <ArrowRight size={13} />
              </button>

              <button
                onClick={() => setCurrentStepIdx(prev => Math.min(TOUR_STEPS.length - 1, prev + 1))}
                disabled={currentStepIdx === TOUR_STEPS.length - 1}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  currentStepIdx === TOUR_STEPS.length - 1
                    ? 'text-text-muted opacity-40 cursor-not-allowed'
                    : 'text-text-secondary hover:text-text-primary hover:bg-surface-3'
                }`}
              >
                Next <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
