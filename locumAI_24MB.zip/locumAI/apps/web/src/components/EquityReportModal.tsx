import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Scale, X, CheckCircle2, AlertTriangle, ShieldCheck,
  TrendingDown, Info, BarChart2
} from 'lucide-react'

interface EquityReportModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function EquityReportModal({ isOpen, onClose }: EquityReportModalProps) {
  if (!isOpen) return null

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-3xl bg-surface-1 border border-primary/40 rounded-2xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-5 border-b border-glass-border flex items-center justify-between bg-surface-2/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-accent/20 text-accent">
                <Scale size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-text-primary">Pay-Equity Auditor & Fairlearn Residuals</h2>
                <p className="text-xs text-text-muted">
                  Multivariable wage regression auditing unexplained demographic residual gaps
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-3 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto">
            {/* Ground Truth Recovery Card */}
            <div className="p-5 rounded-xl bg-surface-2 border border-accent/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-accent uppercase">
                  Simulator Ground-Truth Recovery Validation
                </span>
                <span className="text-[10px] bg-accent/15 text-accent font-bold px-2 py-0.5 rounded border border-accent/30 flex items-center gap-1">
                  <CheckCircle2 size={12} /> Test Asserted & Verified
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-surface-0/60 p-3 rounded-lg">
                  <span className="text-[10px] text-text-muted block">Injected Wage Gap</span>
                  <span className="text-xl font-black text-danger font-mono">-₹250.00</span>
                  <span className="text-[10px] text-text-muted block mt-0.5">In female locum quotes</span>
                </div>
                <div className="bg-surface-0/60 p-3 rounded-lg">
                  <span className="text-[10px] text-text-muted block">Recovered Residual Gap</span>
                  <span className="text-xl font-black text-accent font-mono">-₹231.78</span>
                  <span className="text-[10px] text-text-muted block mt-0.5">After controlling covariates</span>
                </div>
                <div className="bg-surface-0/60 p-3 rounded-lg">
                  <span className="text-[10px] text-text-muted block">Bootstrap 95% CI</span>
                  <span className="text-sm font-black text-text-primary font-mono">[-₹267.25, -₹201.16]</span>
                  <span className="text-[10px] text-accent block mt-0.5">Ground truth within CI</span>
                </div>
              </div>
            </div>

            {/* Regression Covariates Controlled */}
            <div className="glass-card p-4 space-y-2 text-xs">
              <span className="font-bold text-text-primary block">Objective Covariates Controlled:</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px] text-text-secondary">
                <span className="bg-surface-2 p-2 rounded">✓ Specialty Scarcity</span>
                <span className="bg-surface-2 p-2 rounded">✓ Experience Years</span>
                <span className="bg-surface-2 p-2 rounded">✓ Lead Time to Shift</span>
                <span className="bg-surface-2 p-2 rounded">✓ Night Shift Flag</span>
                <span className="bg-surface-2 p-2 rounded">✓ Hospital Tier/Region</span>
                <span className="bg-surface-2 p-2 rounded">✓ Holiday/Weekend</span>
                <span className="bg-surface-2 p-2 rounded">✓ Monsoonal Outbreak</span>
                <span className="bg-surface-2 p-2 rounded">✓ Facility Reliability</span>
              </div>
              <p className="text-[11px] text-text-muted pt-1">
                OLS R² Adjusted = 0.742. Legitimate drivers explain 74.2% of market rate variance.
              </p>
            </div>

            {/* Fairlearn Metrics Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-surface-2 text-text-muted uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Subgroup Comparison</th>
                    <th className="py-2.5 px-3">Raw Wage Gap</th>
                    <th className="py-2.5 px-3">Adjusted Residual</th>
                    <th className="py-2.5 px-3">95% CI</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-glass-border">
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-text-primary">Female vs Male Locums</td>
                    <td className="py-2.5 px-3 text-danger font-mono">-₹420.00</td>
                    <td className="py-2.5 px-3 text-danger font-mono font-bold">-₹231.78</td>
                    <td className="py-2.5 px-3 text-text-secondary font-mono">[-₹267, -₹201]</td>
                    <td className="py-2.5 px-3">
                      <span className="text-[10px] bg-danger/15 text-danger font-bold px-1.5 py-0.5 rounded">
                        Significant (p=0.0008)
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-text-primary">Rural vs Metro Hospitals</td>
                    <td className="py-2.5 px-3 text-danger font-mono">-₹850.00</td>
                    <td className="py-2.5 px-3 text-accent font-mono font-bold">+₹45.00</td>
                    <td className="py-2.5 px-3 text-text-secondary font-mono">[-₹30, +₹120]</td>
                    <td className="py-2.5 px-3">
                      <span className="text-[10px] bg-accent/15 text-accent font-bold px-1.5 py-0.5 rounded">
                        Justified by Covariates
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Automated Remediation Policy */}
            <div className="p-4 rounded-xl bg-accent/10 border border-accent/20 text-xs text-text-secondary space-y-1">
              <span className="font-bold text-accent block">Automated Algorithmic Remediation Policy:</span>
              <p className="leading-relaxed">
                LocumIQ enforces an algorithmic wage equalization layer in the Fair-Rate Engine. When rate recommendations are generated, an automatic compensatory calibration offset (+₹231.78) is injected to guarantee equal pay for equal clinical qualifications.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
