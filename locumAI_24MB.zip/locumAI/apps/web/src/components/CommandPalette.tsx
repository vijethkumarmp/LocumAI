import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import {
  Search, ArrowRight, Activity, Calendar, Shield, HeartPulse,
  Cpu, FlaskConical, Stethoscope, PlusCircle, FileText, Scale, Lock, X
} from 'lucide-react'

interface CommandPaletteProps {
  isOpen: boolean
  onClose: () => void
  onOpenPostShift: () => void
  onOpenContractScanner: () => void
  onOpenEquityReport: () => void
  onOpenBenchmarks: () => void
  onOpenTour: () => void
}

export default function CommandPalette({
  isOpen,
  onClose,
  onOpenPostShift,
  onOpenContractScanner,
  onOpenEquityReport,
  onOpenBenchmarks,
  onOpenTour,
}: CommandPaletteProps) {
  const [query, setQuery] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        if (isOpen) onClose()
        else {
          // Open handled externally if passed
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose()
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [isOpen, onClose])

  if (!isOpen) return null

  const items = [
    { label: 'Fill Probability Meter', category: 'Predictions', path: '/fill-probability', icon: Activity },
    { label: 'Vacancy Forecast Fan Chart', category: 'Predictions', path: '/forecast', icon: Activity },
    { label: 'Roster Board & CP-SAT Optimizer', category: 'Operations', path: '/roster', icon: Calendar },
    { label: 'Locum Shift Feed & Net-Pay', category: 'Operations', path: '/shifts', icon: Stethoscope },
    { label: 'Fatigue Safety Engine', category: 'Safety', path: '/fatigue', icon: HeartPulse },
    { label: 'Bayesian Reliability Scores', category: 'Trust', path: '/reliability', icon: Shield },
    { label: 'MLOps Command Console', category: 'Admin', path: '/mlops', icon: Cpu },
    { label: 'Causal Experimentation Lab', category: 'Admin', path: '/experiments', icon: FlaskConical },
    { label: 'Post New Shift (Live AI Pricing)', category: 'Quick Action', action: onOpenPostShift, icon: PlusCircle },
    { label: 'Legal Contract Risk Scanner', category: 'Tool', action: onOpenContractScanner, icon: FileText },
    { label: 'Pay-Equity Auditor Report', category: 'Tool', action: onOpenEquityReport, icon: Scale },
    { label: 'Privacy Benchmarks (DP Laplace)', category: 'Tool', action: onOpenBenchmarks, icon: Lock },
    { label: 'Guided Demo Tour (6 Moments)', category: 'Guided', action: onOpenTour, icon: Activity },
  ]

  const filtered = items.filter(i =>
    i.label.toLowerCase().includes(query.toLowerCase()) ||
    i.category.toLowerCase().includes(query.toLowerCase())
  )

  const handleSelect = (item: any) => {
    onClose()
    if (item.action) {
      item.action()
    } else if (item.path) {
      navigate(item.path)
    }
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -10 }}
          className="relative w-full max-w-xl bg-surface-1 border border-primary/50 rounded-2xl shadow-2xl overflow-hidden z-10 flex flex-col"
        >
          {/* Search Input Bar */}
          <div className="p-4 border-b border-glass-border flex items-center gap-3 bg-surface-2/60">
            <Search size={18} className="text-primary-light shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder="Type a page, model, action, or tool… (ESC to close)"
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="flex-1 bg-transparent text-sm text-text-primary placeholder-text-muted focus:outline-none"
            />
            <span className="text-[10px] font-mono text-text-muted bg-surface-3/80 px-2 py-0.5 rounded">
              ESC
            </span>
          </div>

          {/* Results List */}
          <div className="max-h-80 overflow-y-auto p-2 space-y-1">
            {filtered.length === 0 ? (
              <div className="p-6 text-center text-xs text-text-muted">
                No matching results for "{query}"
              </div>
            ) : (
              filtered.map((item, idx) => {
                const Icon = item.icon
                return (
                  <button
                    key={idx}
                    onClick={() => handleSelect(item)}
                    className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-surface-2 transition-colors text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-surface-3 text-text-secondary group-hover:bg-primary/20 group-hover:text-primary-light transition-colors">
                        <Icon size={16} />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-text-primary group-hover:text-primary-light transition-colors">
                          {item.label}
                        </div>
                        <span className="text-[10px] text-text-muted uppercase tracking-wider">
                          {item.category}
                        </span>
                      </div>
                    </div>
                    <ArrowRight size={14} className="text-text-muted group-hover:text-primary-light group-hover:translate-x-1 transition-all" />
                  </button>
                )
              })
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
