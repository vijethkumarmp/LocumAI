import React, { useState, useEffect } from 'react'
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Activity, Brain, Shield, HeartPulse,
  Users, FlaskConical, Cpu, Calendar, Stethoscope,
  Menu, X, ChevronRight, Bell, Search, Sparkles, PlusCircle,
  FileText, Scale, Lock, ChevronDown, Check, Zap, Award,
  Volume2, VolumeX, Database
} from 'lucide-react'

import DemoTourModal from './DemoTourModal'
import PostShiftModal from './PostShiftModal'
import ContractScannerModal from './ContractScannerModal'
import EquityReportModal from './EquityReportModal'
import BenchmarksModal from './BenchmarksModal'
import CommandPalette from './CommandPalette'
import ExportAuditModal from './ExportAuditModal'
import { sound } from '../services/sound'
import { locumApi, ApiStatus } from '../services/api'

const NAV_ITEMS = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, section: 'Overview' },
  { path: '/fill-probability', label: 'Fill Probability', icon: Activity, section: 'Predictions' },
  { path: '/forecast', label: 'Vacancy Forecast', icon: Brain, section: 'Predictions' },
  { path: '/roster', label: 'Roster Board', icon: Calendar, section: 'Operations' },
  { path: '/shifts', label: 'Shift Feed', icon: Stethoscope, section: 'Operations' },
  { path: '/surge-map', label: 'Surge Alerts Map', icon: Zap, section: 'Operations' },
  { path: '/fatigue', label: 'Fatigue Safety', icon: HeartPulse, section: 'Safety' },
  { path: '/reliability', label: 'Reliability Scores', icon: Shield, section: 'Trust' },
  { path: '/credentials', label: 'Credential Passport', icon: Award, section: 'Trust' },
  { path: '/mlops', label: 'MLOps Console', icon: Cpu, section: 'Admin' },
  { path: '/experiments', label: 'Experiments Lab', icon: FlaskConical, section: 'Admin' },
]

export default function Layout() {
  const location = useLocation()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [mobileOpen, setMobileOpen] = useState(false)

  // Role persona state
  const [activeRole, setActiveRole] = useState<'facility' | 'locum' | 'mlops'>('facility')

  // Modals state
  const [tourOpen, setTourOpen] = useState(false)
  const [postShiftOpen, setPostShiftOpen] = useState(false)
  const [contractScannerOpen, setContractScannerOpen] = useState(false)
  const [equityReportOpen, setEquityReportOpen] = useState(false)
  const [benchmarksOpen, setBenchmarksOpen] = useState(false)
  const [exportModalOpen, setExportModalOpen] = useState(false)
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [toolsDropdownOpen, setToolsDropdownOpen] = useState(false)
  const [soundOn, setSoundOn] = useState(sound.isEnabled())
  const [apiStatus, setApiStatus] = useState<ApiStatus>({ isLive: false, lastChecked: 0, latencyMs: 0 })

  // Check backend health
  useEffect(() => {
    const check = async () => {
      const status = await locumApi.checkHealth()
      setApiStatus(status)
    }
    check()
    const timer = setInterval(check, 10000)
    return () => clearInterval(timer)
  }, [])

  // Global Ctrl+K / Cmd+K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setPaletteOpen(prev => !prev)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const grouped = NAV_ITEMS.reduce((acc, item) => {
    if (!acc[item.section]) acc[item.section] = []
    acc[item.section].push(item)
    return acc
  }, {} as Record<string, typeof NAV_ITEMS>)

  return (
    <div className="min-h-screen flex flex-col bg-surface-0 text-text-primary">
      {/* Synthetic data banner */}
      <div className="synthetic-banner flex items-center justify-between px-4 py-1 text-xs">
        <span className="flex items-center gap-1.5">
          🔬 <strong>Synthetic Data Demo:</strong> All clinician, shift & facility records are simulated for operational evaluation.
        </span>
        <button
          onClick={() => setTourOpen(true)}
          className="underline hover:text-white font-semibold flex items-center gap-1"
        >
          <Sparkles size={12} /> Start 5-Min Guided Tour
        </button>
      </div>

      <div className="flex flex-1">
        {/* Sidebar */}
        <motion.aside
          initial={false}
          animate={{ width: sidebarOpen ? 260 : 72 }}
          className="hidden lg:flex flex-col bg-surface-1/90 backdrop-blur-xl border-r border-glass-border relative z-20 shrink-0"
          style={{ minHeight: 'calc(100vh - 32px)' }}
        >
          {/* Logo */}
          <Link to="/" className="p-4 flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg shrink-0 shadow-lg shadow-primary/25 group-hover:scale-105 transition-transform">
              L
            </div>
            <AnimatePresence>
              {sidebarOpen && (
                <motion.div
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: 'auto' }}
                  exit={{ opacity: 0, width: 0 }}
                  className="overflow-hidden whitespace-nowrap"
                >
                  <h1 className="text-lg font-bold gradient-text">LocumIQ</h1>
                  <p className="text-[10px] text-text-muted -mt-1 font-mono">Predictive Staffing Exchange</p>
                </motion.div>
              )}
            </AnimatePresence>
          </Link>

          {/* Persona / Role Selector Badge */}
          {sidebarOpen && (
            <div className="px-3 mb-2">
              <div className="p-1 rounded-xl bg-surface-2 border border-glass-border flex text-[10px] font-semibold">
                <button
                  onClick={() => {
                    sound.playClick()
                    setActiveRole('facility')
                    navigate('/dashboard')
                  }}
                  className={`flex-1 py-1 rounded-lg transition-all cursor-pointer ${
                    activeRole === 'facility' ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  Hospital
                </button>
                <button
                  onClick={() => {
                    sound.playClick()
                    setActiveRole('locum')
                    navigate('/shifts')
                  }}
                  className={`flex-1 py-1 rounded-lg transition-all cursor-pointer ${
                    activeRole === 'locum' ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  Locum
                </button>
                <button
                  onClick={() => {
                    sound.playClick()
                    setActiveRole('mlops')
                    navigate('/mlops')
                  }}
                  className={`flex-1 py-1 rounded-lg transition-all cursor-pointer ${
                    activeRole === 'mlops' ? 'bg-primary text-white shadow-sm' : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  MLOps
                </button>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 px-3 py-3 space-y-5 overflow-y-auto">
            {Object.entries(grouped).map(([section, items]) => (
              <div key={section}>
                {sidebarOpen && (
                  <p className="text-[10px] uppercase tracking-widest text-text-muted px-3 mb-1.5 font-mono">{section}</p>
                )}
                <div className="space-y-1">
                  {items.map(({ path, label, icon: Icon }) => {
                    const isActive = location.pathname === path
                    return (
                      <Link
                        key={path}
                        to={path}
                        onClick={() => sound.playClick()}
                        className={`flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200 ${
                          isActive
                            ? 'bg-primary/15 text-primary-light border-l-2 border-primary font-semibold'
                            : 'text-text-secondary hover:text-text-primary hover:bg-surface-2/60'
                        }`}
                      >
                        <Icon size={16} className="shrink-0" />
                        <AnimatePresence>
                          {sidebarOpen && (
                            <motion.span
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                              className="truncate"
                            >
                              {label}
                            </motion.span>
                          )}
                        </AnimatePresence>
                        {isActive && sidebarOpen && (
                          <ChevronRight size={13} className="ml-auto text-primary-light" />
                        )}
                      </Link>
                    )
                  })}
                </div>
              </div>
            ))}
          </nav>

          {/* Collapse toggle */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-3 text-text-muted hover:text-text-primary transition-colors border-t border-glass-border flex items-center justify-center"
          >
            {sidebarOpen ? <X size={16} /> : <Menu size={16} />}
          </button>
        </motion.aside>

        {/* Mobile sidebar */}
        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/70 z-40 lg:hidden backdrop-blur-sm"
                onClick={() => setMobileOpen(false)}
              />
              <motion.aside
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                className="fixed left-0 top-0 bottom-0 w-[280px] bg-surface-1 z-50 lg:hidden p-4 flex flex-col border-r border-glass-border"
              >
                <div className="flex items-center justify-between mb-6">
                  <h1 className="text-lg font-bold gradient-text">LocumIQ</h1>
                  <button onClick={() => setMobileOpen(false)}><X size={20} /></button>
                </div>
                <nav className="space-y-1">
                  {NAV_ITEMS.map(({ path, label, icon: Icon }) => (
                    <Link
                      key={path}
                      to={path}
                      onClick={() => setMobileOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm ${
                        location.pathname === path ? 'bg-primary/10 text-primary-light font-semibold' : 'text-text-secondary'
                      }`}
                    >
                      <Icon size={18} />
                      <span>{label}</span>
                    </Link>
                  ))}
                </nav>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main content wrapper */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Top Navbar */}
          <header className="h-14 flex items-center justify-between px-4 lg:px-6 border-b border-glass-border bg-surface-1/80 backdrop-blur-md sticky top-0 z-30">
            <div className="flex items-center gap-3">
              <button className="lg:hidden text-text-secondary" onClick={() => setMobileOpen(true)}>
                <Menu size={20} />
              </button>

              {/* Command Palette Trigger Input */}
              <button
                onClick={() => setPaletteOpen(true)}
                className="flex items-center gap-2 bg-surface-2 border border-glass-border hover:border-primary/40 rounded-xl px-3 py-1.5 text-xs text-text-muted hover:text-text-secondary transition-all w-64 md:w-80 text-left"
              >
                <Search size={14} className="text-primary-light shrink-0" />
                <span className="truncate">Search shifts, models, experiments…</span>
                <span className="ml-auto font-mono text-[10px] bg-surface-3/80 px-1.5 py-0.5 rounded text-text-secondary">
                  ⌘K
                </span>
              </button>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center gap-2.5">
              {/* Guided Tour Trigger */}
              <button
                onClick={() => setTourOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-primary/15 hover:bg-primary/25 text-primary-light border border-primary/30 transition-all"
              >
                <Sparkles size={14} />
                <span>Guided Tour</span>
              </button>

              {/* Post Shift Trigger */}
              <button
                onClick={() => setPostShiftOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-primary hover:bg-primary-hover text-white shadow-md shadow-primary/25 transition-all active:scale-95"
              >
                <PlusCircle size={14} />
                <span className="hidden md:inline">Post Shift</span>
              </button>

              {/* Tools Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setToolsDropdownOpen(!toolsDropdownOpen)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium bg-surface-2 hover:bg-surface-3 text-text-secondary hover:text-text-primary border border-glass-border transition-colors"
                >
                  <span>Tools</span>
                  <ChevronDown size={13} />
                </button>

                <AnimatePresence>
                  {toolsDropdownOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      onClick={() => setToolsDropdownOpen(false)}
                      className="absolute right-0 mt-2 w-56 bg-surface-1 border border-glass-border rounded-xl shadow-2xl p-1.5 z-50 text-xs space-y-1"
                    >
                      <button
                        onClick={() => setContractScannerOpen(true)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-surface-2 text-text-secondary hover:text-text-primary text-left"
                      >
                        <FileText size={15} className="text-danger" />
                        <div>
                          <div className="font-semibold text-text-primary">Contract Scanner</div>
                          <div className="text-[10px] text-text-muted">Audit non-compete & tail liability</div>
                        </div>
                      </button>

                      <button
                        onClick={() => setEquityReportOpen(true)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-surface-2 text-text-secondary hover:text-text-primary text-left"
                      >
                        <Scale size={15} className="text-accent" />
                        <div>
                          <div className="font-semibold text-text-primary">Pay-Equity Audit</div>
                          <div className="text-[10px] text-text-muted">OLS wage residuals & parity</div>
                        </div>
                      </button>

                      <button
                        onClick={() => setBenchmarksOpen(true)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-surface-2 text-text-secondary hover:text-text-primary text-left"
                      >
                        <Lock size={15} className="text-primary-light" />
                        <div>
                          <div className="font-semibold text-text-primary">DP Benchmarks</div>
                          <div className="text-[10px] text-text-muted">Laplace noise & ε budget</div>
                        </div>
                      </button>

                      <div className="border-t border-glass-border/50 my-1" />

                      <button
                        onClick={() => setExportModalOpen(true)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-surface-2 text-text-secondary hover:text-text-primary text-left"
                      >
                        <Database size={15} className="text-emerald-400" />
                        <div>
                          <div className="font-semibold text-text-primary">Export Audit Suite</div>
                          <div className="text-[10px] text-text-muted">Download model cards & CSVs</div>
                        </div>
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Sound FX Synthesizer Toggle */}
              <button
                onClick={() => {
                  const newState = sound.toggle()
                  setSoundOn(newState)
                }}
                title={soundOn ? 'Sound FX Enabled (Click to mute)' : 'Sound FX Muted (Click to enable)'}
                className={`p-1.5 rounded-xl border text-xs transition-all cursor-pointer ${
                  soundOn
                    ? 'bg-primary/20 text-primary-light border-primary/40 hover:bg-primary/30'
                    : 'bg-surface-2 text-text-muted border-glass-border hover:text-text-primary'
                }`}
              >
                {soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </button>

              {/* API Status indicator */}
              <div
                className={`hidden lg:flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-full border ${
                  apiStatus.isLive
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : 'bg-surface-2 text-text-muted border-glass-border'
                }`}
                title={
                  apiStatus.isLive
                    ? `Connected to FastAPI Backend (Latency: ${apiStatus.latencyMs}ms)`
                    : 'FastAPI Backend offline - running high-fidelity local simulator'
                }
              >
                <div className={`w-2 h-2 rounded-full ${apiStatus.isLive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                <span className="font-medium">
                  {apiStatus.isLive ? `FastAPI (${apiStatus.latencyMs}ms)` : 'Simulated Core'}
                </span>
              </div>
            </div>
          </header>

          {/* Page content view */}
          <div className="flex-1 p-4 lg:p-6 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                <Outlet />
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Global Modals */}
      <DemoTourModal isOpen={tourOpen} onClose={() => setTourOpen(false)} />
      <PostShiftModal isOpen={postShiftOpen} onClose={() => setPostShiftOpen(false)} />
      <ContractScannerModal isOpen={contractScannerOpen} onClose={() => setContractScannerOpen(false)} />
      <EquityReportModal isOpen={equityReportOpen} onClose={() => setEquityReportOpen(false)} />
      <BenchmarksModal isOpen={benchmarksOpen} onClose={() => setBenchmarksOpen(false)} />
      <ExportAuditModal isOpen={exportModalOpen} onClose={() => setExportModalOpen(false)} />
      <CommandPalette
        isOpen={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        onOpenPostShift={() => setPostShiftOpen(true)}
        onOpenContractScanner={() => setContractScannerOpen(true)}
        onOpenEquityReport={() => setEquityReportOpen(true)}
        onOpenBenchmarks={() => setBenchmarksOpen(true)}
        onOpenTour={() => setTourOpen(true)}
      />
    </div>
  )
}
