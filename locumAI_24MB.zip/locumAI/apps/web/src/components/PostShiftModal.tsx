import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X, PlusCircle, Sparkles, AlertTriangle, CheckCircle2,
  Activity, DollarSign, Calendar, Clock, MapPin, Building2
} from 'lucide-react'

interface PostShiftModalProps {
  isOpen: boolean
  onClose: () => void
  onShiftCreated?: (shift: any) => void
}

const MARKET_BASE_RATES: Record<string, number> = {
  GP: 3500,
  Emergency: 5500,
  Anesthesia: 7000,
  OBG: 6000,
  Pediatrics: 5000,
  Radiology: 6500,
  'Nursing-ICU': 2500,
  'Nursing-Ward': 2000,
}

const TIER_MULTS: Record<string, number> = {
  metro: 1.30,
  'tier-2': 1.00,
  rural: 0.85,
}

export default function PostShiftModal({ isOpen, onClose, onShiftCreated }: PostShiftModalProps) {
  const [specialty, setSpecialty] = useState('Emergency')
  const [tier, setTier] = useState('metro')
  const [leadTimeDays, setLeadTimeDays] = useState(4)
  const [isNight, setIsNight] = useState(false)
  const [offeredRate, setOfferedRate] = useState(6500)
  const [department, setDepartment] = useState('Emergency Department - Triage')
  const [hospitalName, setHospitalName] = useState('Lilavati Hospital, Mumbai')
  const [submitted, setSubmitted] = useState(false)

  // Live model calculation
  const marketMedian = (MARKET_BASE_RATES[specialty] || 4000) * (TIER_MULTS[tier] || 1.0)
  const rateRatio = offeredRate / marketMedian
  const leadEffect = Math.min(leadTimeDays / 14.0, 1.0) * 0.8
  const nightPen = isNight ? -0.4 : 0.0
  const urgentPen = leadTimeDays <= 2 ? -0.3 : 0.0

  const logit = -2.0 + 3.5 * rateRatio + leadEffect + nightPen + urgentPen
  const fillProb = Math.min(0.99, Math.max(0.05, 1.0 / (1.0 + Math.exp(-logit))))
  const ciWidth = 0.08 * (1.0 - fillProb) * fillProb * 4.0
  const ciLow = Math.max(0.0, fillProb - ciWidth)
  const ciHigh = Math.min(1.0, fillProb + ciWidth)

  // Rate band
  const p10 = Math.round(marketMedian * 0.78)
  const p50 = Math.round(marketMedian)
  const p90 = Math.round(marketMedian * 1.25)
  const surgeMultiplier = Math.min(1.50, Math.max(1.0, rateRatio))
  const isSurgeCapped = rateRatio >= 1.50

  useEffect(() => {
    // Sync default rate on specialty/tier change
    setOfferedRate(Math.round(marketMedian))
  }, [specialty, tier])

  if (!isOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => {
      if (onShiftCreated) {
        onShiftCreated({
          id: `SH-${Math.floor(Math.random() * 900) + 100}`,
          facilityName: hospitalName,
          specialty,
          tier,
          offeredRate,
          timing: isNight ? 'Night (20:00 - 08:00)' : 'Day (08:00 - 17:00)',
          isNight,
          isUrgent: leadTimeDays <= 2,
        })
      }
      setSubmitted(false)
      onClose()
    }, 1000)
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-3xl bg-surface-1 border border-primary/40 rounded-2xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-5 border-b border-glass-border flex items-center justify-between bg-surface-2/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-primary/20 text-primary-light">
                <PlusCircle size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-text-primary">Post New Shift with Live ML Pricing</h2>
                <p className="text-xs text-text-muted">
                  Yield-calibrated fill probability & fair-rate corridor updated live as you configure
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-3 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {/* Form + Live Feedback Grid */}
          <div className="p-6 grid grid-cols-1 lg:grid-cols-5 gap-6 overflow-y-auto">
            {/* Left 3 Cols: Input Controls */}
            <form onSubmit={handleSubmit} className="lg:col-span-3 space-y-4">
              <div>
                <label className="text-xs font-semibold text-text-secondary block mb-1">Hospital / Facility</label>
                <input
                  type="text"
                  value={hospitalName}
                  onChange={e => setHospitalName(e.target.value)}
                  className="w-full bg-surface-2 border border-glass-border rounded-xl px-3 py-2 text-sm text-text-primary focus:outline-none focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-text-secondary block mb-1">Specialty</label>
                  <select
                    value={specialty}
                    onChange={e => setSpecialty(e.target.value)}
                    className="w-full bg-surface-2 border border-glass-border rounded-xl px-3 py-2 text-xs text-text-primary focus:outline-none focus:border-primary"
                  >
                    {Object.keys(MARKET_BASE_RATES).map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-text-secondary block mb-1">Region / Tier</label>
                  <select
                    value={tier}
                    onChange={e => setTier(e.target.value)}
                    className="w-full bg-surface-2 border border-glass-border rounded-xl px-3 py-2 text-xs text-text-primary focus:outline-none focus:border-primary"
                  >
                    <option value="metro">Tier-1 Metro (Mumbai/Delhi/Blr)</option>
                    <option value="tier-2">Tier-2 (Pune/Jaipur/Nagpur)</option>
                    <option value="rural">Rural / Sub-District PHC</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-text-secondary block mb-1">
                    Lead Time (Days: {leadTimeDays})
                  </label>
                  <input
                    type="range"
                    min={1}
                    max={21}
                    value={leadTimeDays}
                    onChange={e => setLeadTimeDays(Number(e.target.value))}
                    className="w-full h-1.5 bg-surface-3 rounded-lg cursor-pointer"
                  />
                  <span className="text-[10px] text-text-muted">
                    {leadTimeDays <= 2 ? '⚠️ Urgent Shift (<48h)' : 'Normal Booking Horizon'}
                  </span>
                </div>

                <div className="flex flex-col justify-center">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-surface-2 border border-glass-border">
                    <span className="text-xs font-semibold text-text-secondary">Night Shift</span>
                    <input
                      type="checkbox"
                      checked={isNight}
                      onChange={e => setIsNight(e.target.checked)}
                      className="rounded text-primary focus:ring-0"
                    />
                  </div>
                </div>
              </div>

              {/* Offered Rate Slider */}
              <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-text-secondary">Offered Shift Rate</span>
                  <span className="text-lg font-black text-accent font-mono">
                    ₹{offeredRate.toLocaleString()}
                  </span>
                </div>
                <input
                  type="range"
                  min={Math.round(marketMedian * 0.6)}
                  max={Math.round(marketMedian * 1.8)}
                  step={100}
                  value={offeredRate}
                  onChange={e => setOfferedRate(Number(e.target.value))}
                  className="w-full h-2 bg-surface-3 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-text-muted font-mono">
                  <span>P10: ₹{p10.toLocaleString()}</span>
                  <span>Market P50: ₹{p50.toLocaleString()}</span>
                  <span>P90: ₹{p90.toLocaleString()}</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={submitted}
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-primary hover:bg-primary-hover text-white shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2"
              >
                {submitted ? (
                  <>
                    <CheckCircle2 size={16} className="animate-spin" />
                    <span>Publishing Shift to Locum Exchange…</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={15} />
                    <span>Publish Shift with Active AI Pricing</span>
                  </>
                )}
              </button>
            </form>

            {/* Right 2 Cols: Real-Time ML Feedback Card */}
            <div className="lg:col-span-2 space-y-3">
              <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-primary-light flex items-center gap-1.5">
                    <Activity size={14} /> Live Fill Prediction
                  </span>
                  <span className="text-[10px] bg-accent/15 text-accent font-mono font-bold px-1.5 py-0.5 rounded">
                    Calibrated v1.2
                  </span>
                </div>

                <div className="text-center py-2">
                  <div
                    className={`text-4xl font-black font-mono ${
                      fillProb >= 0.80 ? 'text-accent' : fillProb >= 0.50 ? 'text-warning' : 'text-danger'
                    }`}
                  >
                    {(fillProb * 100).toFixed(1)}%
                  </div>
                  <p className="text-[11px] text-text-muted mt-1">
                    Fill probability within 48h
                  </p>
                </div>

                <div className="w-full h-2 bg-surface-3 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      fillProb >= 0.80 ? 'bg-accent' : fillProb >= 0.50 ? 'bg-warning' : 'bg-danger'
                    }`}
                    style={{ width: `${fillProb * 100}%` }}
                  />
                </div>

                <div className="flex justify-between text-[11px] text-text-secondary pt-1 border-t border-glass-border/40 font-mono">
                  <span>95% Conformal CI:</span>
                  <span>[{(ciLow * 100).toFixed(0)}%, {(ciHigh * 100).toFixed(0)}%]</span>
                </div>
              </div>

              {/* Fair-Rate Corridor Badge */}
              <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-2 text-xs">
                <span className="font-bold text-text-primary block">Fair-Rate Corridor Benchmark</span>
                <div className="space-y-1.5 text-text-secondary">
                  <div className="flex justify-between">
                    <span>Market Baseline:</span>
                    <span className="font-mono text-text-primary">₹{p50.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Surge Multiplier:</span>
                    <span className="font-mono text-accent">{surgeMultiplier.toFixed(2)}x</span>
                  </div>
                  {isSurgeCapped && (
                    <div className="text-[10px] text-warning flex items-center gap-1 mt-1">
                      <AlertTriangle size={12} /> Surge cap active (max 1.50x allowed)
                    </div>
                  )}
                </div>
              </div>

              <div className="p-3 bg-surface-3/40 rounded-xl text-[10px] text-text-muted leading-relaxed">
                💡 Tip: Offering ₹{Math.round(marketMedian * 1.15).toLocaleString()} raises fill probability to 88% while remaining well within the Fair-Rate P90 threshold.
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
