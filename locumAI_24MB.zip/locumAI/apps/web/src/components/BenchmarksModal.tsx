import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Shield, X, Lock, EyeOff, Database, CheckCircle2,
  Sliders, Info, Zap
} from 'lucide-react'

interface BenchmarksModalProps {
  isOpen: boolean
  onClose: () => void
}

interface BenchmarkCell {
  specialty: string
  tier: string
  sampleK: number
  p25: number
  p50: number
  p75: number
  dpNoiseAdded: boolean
}

const BENCHMARK_CELLS: BenchmarkCell[] = [
  { specialty: 'Emergency Medicine', tier: 'Metro (Mumbai)', sampleK: 184, p25: 5820, p50: 6780, p75: 7810, dpNoiseAdded: true },
  { specialty: 'Anesthesia', tier: 'Metro (Mumbai)', sampleK: 112, p25: 6240, p50: 7390, p75: 8590, dpNoiseAdded: true },
  { specialty: 'GP / Primary Care', tier: 'Tier-2 (Pune)', sampleK: 240, p25: 3210, p50: 3890, p75: 4580, dpNoiseAdded: true },
  { specialty: 'Nursing-ICU', tier: 'Metro (Chennai)', sampleK: 320, p25: 2390, p50: 2910, p75: 3420, dpNoiseAdded: true },
  { specialty: 'Pediatrics', tier: 'Tier-2 (Jaipur)', sampleK: 98, p25: 4420, p50: 5120, p75: 5930, dpNoiseAdded: true },
]

export default function BenchmarksModal({ isOpen, onClose }: BenchmarksModalProps) {
  const [epsilon, setEpsilon] = useState(0.5)
  const epsilonTotal = 2.0
  const epsilonRemaining = Math.max(0.0, epsilonTotal - epsilon)

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-3xl bg-surface-1 border border-primary/40 rounded-2xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-5 border-b border-glass-border flex items-center justify-between bg-surface-2/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-primary/20 text-primary-light">
                <Lock size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-text-primary">
                  Privacy-Preserving Benchmarks (Differential Privacy)
                </h2>
                <p className="text-xs text-text-muted">
                  k-Anonymity (k ≥ 5) suppression + Laplace DP noise injection with ε privacy budget tracking
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-3 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto">
            {/* Epsilon Budget Tracker */}
            <div className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-text-primary flex items-center gap-1.5">
                  <Shield size={14} className="text-accent" /> Privacy Budget (ε Tracker)
                </span>
                <span className="text-[10px] font-mono text-accent bg-accent/15 px-2 py-0.5 rounded font-bold">
                  Laplace Scale b = {(50.0 / Math.max(epsilon, 0.1)).toFixed(1)}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs font-mono">
                <div className="bg-surface-0/60 p-2.5 rounded-lg">
                  <span className="text-[10px] text-text-muted block">Budget Allocated</span>
                  <span className="font-bold text-text-primary text-sm">ε = {epsilonTotal.toFixed(1)}</span>
                </div>
                <div className="bg-surface-0/60 p-2.5 rounded-lg">
                  <span className="text-[10px] text-text-muted block">Query Cost (Current)</span>
                  <span className="font-bold text-warning text-sm">ε = {epsilon.toFixed(2)}</span>
                </div>
                <div className="bg-surface-0/60 p-2.5 rounded-lg">
                  <span className="text-[10px] text-text-muted block">Remaining Reserve</span>
                  <span className="font-bold text-accent text-sm">ε = {epsilonRemaining.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-text-muted">
                  <span>Privacy Parameter ε: {epsilon} (Lower = stronger privacy, higher noise)</span>
                  <span>Max ε = 2.0</span>
                </div>
                <input
                  type="range"
                  min={0.1}
                  max={1.5}
                  step={0.1}
                  value={epsilon}
                  onChange={e => setEpsilon(Number(e.target.value))}
                  className="w-full h-1.5 bg-surface-3 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Benchmarks Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-surface-2 text-text-muted uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Specialty</th>
                    <th className="py-2.5 px-3">Region / Tier</th>
                    <th className="py-2.5 px-3">Sample (k)</th>
                    <th className="py-2.5 px-3">P25 Rate</th>
                    <th className="py-2.5 px-3">P50 Median</th>
                    <th className="py-2.5 px-3">P75 Rate</th>
                    <th className="py-2.5 px-3">DP Protected</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-glass-border">
                  {BENCHMARK_CELLS.map((cell, idx) => (
                    <tr key={idx} className="hover:bg-surface-2/40 transition-colors">
                      <td className="py-2.5 px-3 font-semibold text-text-primary">{cell.specialty}</td>
                      <td className="py-2.5 px-3 text-text-secondary">{cell.tier}</td>
                      <td className="py-2.5 px-3 font-mono">
                        <span className="text-accent font-bold">k = {cell.sampleK}</span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-text-secondary">₹{cell.p25.toLocaleString()}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-text-primary">₹{cell.p50.toLocaleString()}</td>
                      <td className="py-2.5 px-3 font-mono text-text-secondary">₹{cell.p75.toLocaleString()}</td>
                      <td className="py-2.5 px-3">
                        <span className="text-[10px] bg-accent/15 text-accent font-bold px-1.5 py-0.5 rounded flex items-center gap-1 w-fit">
                          <CheckCircle2 size={10} /> Lap(b) Noise
                        </span>
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-surface-3/20 opacity-60">
                    <td className="py-2.5 px-3 font-semibold text-text-muted">Radiology (Specialist)</td>
                    <td className="py-2.5 px-3 text-text-muted">Rural Konkan</td>
                    <td className="py-2.5 px-3 font-mono text-danger font-bold">k = 3 (&lt; 5)</td>
                    <td colSpan={4} className="py-2.5 px-3 text-danger italic">
                      ⛔ Suppressed by k-anonymity rule (k &lt; 5 providers) to prevent re-identification
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="p-3.5 bg-surface-2/60 rounded-xl border border-glass-border text-[11px] text-text-muted leading-relaxed">
              🔒 <strong>Mathematical Guarantee:</strong> No individual doctor's or facility's contract can be reconstructed, even if an adversary possesses auxiliary knowledge of all other contracts in the healthcare district.
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
