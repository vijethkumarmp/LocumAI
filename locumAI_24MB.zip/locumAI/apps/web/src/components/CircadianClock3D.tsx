import React, { useRef, useMemo, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Text, Float } from '@react-three/drei'
import * as THREE from 'three'
import { sound } from '../services/sound'
import { Sun, Moon, AlertOctagon, Zap } from 'lucide-react'

// Borbély Two-Process Model 3D Ring
function BorbelyRing({
  wakeHours,
  currentHour,
}: {
  wakeHours: number
  currentHour: number
}) {
  const groupRef = useRef<THREE.Group>(null)
  const markerRef = useRef<THREE.Mesh>(null)

  // 24 Hour Dial Geometry
  const hourPoints = useMemo(() => {
    const pts: { pos: [number, number, number]; label: string; isNight: boolean }[] = []
    const radius = 2.6
    for (let h = 0; h < 24; h += 2) {
      const angle = (h / 24) * Math.PI * 2 - Math.PI / 2
      const x = Math.cos(angle) * radius
      const y = Math.sin(angle) * radius
      pts.push({
        pos: [x, y, 0],
        label: `${h.toString().padStart(2, '0')}:00`,
        isNight: h >= 22 || h < 6,
      })
    }
    return pts
  }, [])

  // Process C Circadian Sine Wave Line
  const processCLine = useMemo(() => {
    const pts: THREE.Vector3[] = []
    const radius = 2.0
    const segments = 64
    for (let i = 0; i <= segments; i++) {
      const angle = (i / segments) * Math.PI * 2
      // Circadian wave: peak at ~17:00 (angle ~ 2.6 rad), nadir at ~04:00
      const phase = angle - (17 / 24) * Math.PI * 2
      const cVal = Math.cos(phase) * 0.35 // amplitude
      const r = radius + cVal
      pts.push(new THREE.Vector3(Math.cos(angle) * r, Math.sin(angle) * r, 0))
    }
    const geometry = new THREE.BufferGeometry().setFromPoints(pts)
    const material = new THREE.LineBasicMaterial({ color: '#818cf8', linewidth: 2 })
    return new THREE.Line(geometry, material)
  }, [])

  // Marker Position for Current Hour
  const markerAngle = (currentHour / 24) * Math.PI * 2 - Math.PI / 2
  const markerX = Math.cos(markerAngle) * 2.3
  const markerY = Math.sin(markerAngle) * 2.3

  // Process S Homeostasis Load factor (0 to 1)
  const sLoad = Math.min(1.0, wakeHours / 24)
  const isDangerWindow = currentHour >= 2 && currentHour <= 6 && wakeHours > 14

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.1) * 0.05
    }
    if (markerRef.current) {
      markerRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 4) * 0.15)
    }
  })

  return (
    <group ref={groupRef}>
      {/* Outer 24h Clock Dial */}
      <mesh>
        <torusGeometry args={[2.6, 0.03, 16, 64]} />
        <meshStandardMaterial color="#475569" transparent opacity={0.6} />
      </mesh>

      {/* Inner Process C Circadian Rhythm Wave */}
      <primitive object={processCLine} />

      {/* Process S Homeostatic Sleep Debt Ring (expands with wakefulness) */}
      <mesh>
        <torusGeometry args={[1.5 + sLoad * 0.4, 0.04, 16, 64]} />
        <meshStandardMaterial
          color={sLoad > 0.65 ? '#ef4444' : sLoad > 0.45 ? '#f59e0b' : '#10b981'}
          emissive={sLoad > 0.65 ? '#ef4444' : sLoad > 0.45 ? '#f59e0b' : '#10b981'}
          emissiveIntensity={0.6}
        />
      </mesh>

      {/* Central Holographic Core */}
      <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.2}>
        <mesh>
          <icosahedronGeometry args={[0.7, 1]} />
          <meshStandardMaterial
            color={isDangerWindow ? '#ef4444' : '#06b6d4'}
            emissive={isDangerWindow ? '#b91c1c' : '#0284c7'}
            emissiveIntensity={0.8}
            wireframe
          />
        </mesh>
      </Float>

      {/* Hour Markers */}
      {hourPoints.map((hp, idx) => (
        <group key={idx} position={hp.pos}>
          <mesh>
            <sphereGeometry args={[0.06, 8, 8]} />
            <meshStandardMaterial
              color={hp.isNight ? '#a78bfa' : '#38bdf8'}
              emissive={hp.isNight ? '#7c3aed' : '#0284c7'}
              emissiveIntensity={0.6}
            />
          </mesh>
          <Text
            position={[0, -0.18, 0]}
            fontSize={0.16}
            color={hp.isNight ? '#c4b5fd' : '#94a3b8'}
            anchorX="center"
            anchorY="middle"
          >
            {hp.label}
          </Text>
        </group>
      ))}

      {/* Current Hour Clinician Needle / Orbit Beacon */}
      <mesh ref={markerRef} position={[markerX, markerY, 0.1]}>
        <sphereGeometry args={[0.16, 16, 16]} />
        <meshStandardMaterial
          color={isDangerWindow ? '#ff0033' : '#22c55e'}
          emissive={isDangerWindow ? '#ff0033' : '#15803d'}
          emissiveIntensity={1.2}
        />
      </mesh>
    </group>
  )
}

export default function CircadianClock3D() {
  const [wakeHours, setWakeHours] = useState<number>(14)
  const [currentHour, setCurrentHour] = useState<number>(4) // default 04:00 AM (critical nadir)

  // Calculate Borbély Two-Process metrics
  // Process S: homeostatic sleep pressure S(t) = 1 - exp(-t / 18.2)
  const processS = 1 - Math.exp(-wakeHours / 18.2)

  // Process C: circadian arousal C(t) = 0.5 + 0.45 * cos(2 * pi * (currentHour - 17) / 24)
  const processC = 0.5 + 0.45 * Math.cos((2 * Math.PI * (currentHour - 17)) / 24)

  // Cognitive Vulnerability = S - C (high when sleep debt is high and circadian drive is at trough)
  const cognitiveVulnerability = Math.max(0, Math.min(1.0, processS * 0.7 + (1 - processC) * 0.5))

  const isNightShift = currentHour >= 21 || currentHour <= 7
  const isCircadianNadir = currentHour >= 2 && currentHour <= 6
  const isHazardous = cognitiveVulnerability > 0.65 || (isCircadianNadir && wakeHours > 14)

  return (
    <div className="glass-card p-6 border border-glass-border space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-accent animate-pulse" />
            <h3 className="font-bold text-base text-text-primary">
              3D Neuro-Fatigue & Circadian Borbély Orbit
            </h3>
          </div>
          <p className="text-xs text-text-muted mt-0.5">
            Real-time interactive visualization of Process S (Sleep Debt) vs Process C (Circadian Pacemaker)
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span
            className={`px-2.5 py-1 rounded-full font-semibold border flex items-center gap-1.5 ${
              isHazardous
                ? 'bg-danger/20 text-danger border-danger/40 animate-pulse'
                : 'bg-success/20 text-success border-success/40'
            }`}
          >
            {isHazardous ? <AlertOctagon size={13} /> : <Zap size={13} />}
            {isHazardous ? 'VULNERABILITY HAZARD' : 'OPTIMAL COGNITION'}
          </span>
        </div>
      </div>

      {/* 3D Canvas Viewport */}
      <div className="relative w-full h-[320px] bg-surface-base/80 rounded-2xl overflow-hidden border border-glass-border">
        <Canvas camera={{ position: [0, 0, 5.8], fov: 48 }}>
          <ambientLight intensity={0.5} />
          <pointLight position={[5, 5, 8]} intensity={1.2} color="#818cf8" />
          <pointLight position={[-5, -5, -4]} intensity={0.6} color="#06b6d4" />
          <BorbelyRing wakeHours={wakeHours} currentHour={currentHour} />
          <OrbitControls enableZoom={false} enablePan={false} maxPolarAngle={Math.PI / 1.8} minPolarAngle={Math.PI / 2.5} />
        </Canvas>

        {/* Floating Telemetry Badge Overlay */}
        <div className="absolute top-3 left-3 bg-surface-1/80 backdrop-blur-md px-3 py-2 rounded-xl border border-glass-border text-xs space-y-1">
          <div className="flex items-center gap-1.5 text-text-secondary">
            {isNightShift ? <Moon size={13} className="text-indigo-400" /> : <Sun size={13} className="text-amber-400" />}
            <span className="font-bold text-text-primary">{currentHour.toString().padStart(2, '0')}:00 IST</span>
            {isCircadianNadir && <span className="text-[10px] text-danger font-mono">(Circadian Nadir)</span>}
          </div>
          <div className="text-[11px] text-text-muted">
            Cognitive Risk Index: <span className="font-mono font-bold text-accent">{(cognitiveVulnerability * 100).toFixed(0)}%</span>
          </div>
        </div>

        <div className="absolute bottom-3 right-3 text-[10px] text-text-muted bg-surface-1/70 backdrop-blur-xs px-2.5 py-1 rounded-md">
          Drag to rotate 3D orbit
        </div>
      </div>

      {/* Interactive Sliders */}
      <div className="grid md:grid-cols-2 gap-4 pt-2">
        {/* Continuous Hours Awake Slider */}
        <div className="p-3.5 rounded-xl bg-surface-2/60 border border-glass-border space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-text-secondary font-medium">Continuous Hours Awake (Process S):</span>
            <span className="font-bold text-text-primary font-mono">{wakeHours} hrs</span>
          </div>
          <input
            type="range"
            min="0"
            max="30"
            step="1"
            value={wakeHours}
            onChange={(e) => {
              setWakeHours(Number(e.target.value))
              sound.playClick()
            }}
            className="w-full accent-primary h-1.5 bg-surface-3 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-text-muted">
            <span>0h (Fresh)</span>
            <span>14h (Normal shift end)</span>
            <span className="text-danger font-semibold">24h+ (Extreme Debt)</span>
          </div>
        </div>

        {/* Current Shift Hour Slider */}
        <div className="p-3.5 rounded-xl bg-surface-2/60 border border-glass-border space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-text-secondary font-medium">Shift Time-of-Day (Process C Phase):</span>
            <span className="font-bold text-text-primary font-mono">{currentHour.toString().padStart(2, '0')}:00 IST</span>
          </div>
          <input
            type="range"
            min="0"
            max="23"
            step="1"
            value={currentHour}
            onChange={(e) => {
              setCurrentHour(Number(e.target.value))
              sound.playClick()
            }}
            className="w-full accent-accent h-1.5 bg-surface-3 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-text-muted">
            <span>00:00 (Night)</span>
            <span className="text-danger font-semibold">04:00 (Lowest Alertness)</span>
            <span>17:00 (Peak Arousal)</span>
          </div>
        </div>
      </div>

      {/* Mathematical Breakdown of Borbély Two-Process Equation */}
      <div className="p-3.5 rounded-xl bg-surface-2/40 border border-glass-border grid sm:grid-cols-3 gap-3 text-xs">
        <div>
          <span className="text-[10px] text-text-muted block">Process S (Sleep Load)</span>
          <span className="font-mono font-bold text-primary-light">{(processS * 100).toFixed(1)}%</span>
          <p className="text-[10px] text-text-muted mt-0.5">S(t) = 1 - e^(-t/18.2h)</p>
        </div>
        <div>
          <span className="text-[10px] text-text-muted block">Process C (Circadian Drive)</span>
          <span className="font-mono font-bold text-indigo-400">{(processC * 100).toFixed(1)}%</span>
          <p className="text-[10px] text-text-muted mt-0.5">Suprachiasmatic 24h phase</p>
        </div>
        <div>
          <span className="text-[10px] text-text-muted block">Reaction Saccade Latency</span>
          <span className={`font-mono font-bold ${isHazardous ? 'text-danger' : 'text-success'}`}>
            +{(cognitiveVulnerability * 140).toFixed(0)} ms
          </span>
          <p className="text-[10px] text-text-muted mt-0.5">Degradation vs baseline</p>
        </div>
      </div>
    </div>
  )
}
