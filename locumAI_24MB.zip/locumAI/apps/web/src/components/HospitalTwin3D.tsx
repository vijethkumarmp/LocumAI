import React, { useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Text, Float } from '@react-three/drei'
import * as THREE from 'three'
import { sound } from '../services/sound'
import { Shield, AlertTriangle, Users, Bed, Activity, PlusCircle } from 'lucide-react'

export interface DepartmentTwinData {
  id: string
  name: string
  code: string
  position: [number, number, number]
  size: [number, number, number]
  occupancy: number // e.g. 92%
  bedsTotal: number
  bedsOccupied: number
  locumsOnDuty: number
  predictedDeficit12h: number
  riskLevel: 'critical' | 'warning' | 'normal'
  doctorRatio: string
  color: string
  accentColor: string
}

const DEPARTMENTS: DepartmentTwinData[] = [
  {
    id: 'er',
    name: 'Emergency & Trauma Bay',
    code: 'ER-01',
    position: [-2.2, 0.4, 1.2],
    size: [1.8, 0.8, 1.6],
    occupancy: 96,
    bedsTotal: 25,
    bedsOccupied: 24,
    locumsOnDuty: 4,
    predictedDeficit12h: 2,
    riskLevel: 'critical',
    doctorRatio: '1:6 (Threshold 1:5)',
    color: '#ef4444',
    accentColor: '#f87171',
  },
  {
    id: 'icu',
    name: 'Intensive Care Unit (ICU/CCU)',
    code: 'ICU-B',
    position: [2.0, 0.5, 1.0],
    size: [2.0, 1.0, 1.8],
    occupancy: 90,
    bedsTotal: 20,
    bedsOccupied: 18,
    locumsOnDuty: 3,
    predictedDeficit12h: 1,
    riskLevel: 'warning',
    doctorRatio: '1:3 (Mandated 1:2)',
    color: '#8b5cf6',
    accentColor: '#a78bfa',
  },
  {
    id: 'ot',
    name: 'Modular Surgical Theatres',
    code: 'OT-SUITE',
    position: [0, 0.6, -1.8],
    size: [2.8, 1.2, 1.6],
    occupancy: 75,
    bedsTotal: 12,
    bedsOccupied: 9,
    locumsOnDuty: 2,
    predictedDeficit12h: 0,
    riskLevel: 'normal',
    doctorRatio: '1:2 (Optimal)',
    color: '#10b981',
    accentColor: '#34d399',
  },
  {
    id: 'nicu',
    name: 'Pediatrics & NICU',
    code: 'NICU-P',
    position: [-2.4, 0.35, -1.2],
    size: [1.6, 0.7, 1.4],
    occupancy: 82,
    bedsTotal: 16,
    bedsOccupied: 13,
    locumsOnDuty: 2,
    predictedDeficit12h: 1,
    riskLevel: 'warning',
    doctorRatio: '1:4 (Standard)',
    color: '#f59e0b',
    accentColor: '#fbbf24',
  },
  {
    id: 'ward',
    name: 'Inpatient Medical Wards',
    code: 'WARD-GEN',
    position: [2.2, 0.3, -1.2],
    size: [1.8, 0.6, 1.5],
    occupancy: 68,
    bedsTotal: 40,
    bedsOccupied: 27,
    locumsOnDuty: 2,
    predictedDeficit12h: 0,
    riskLevel: 'normal',
    doctorRatio: '1:10 (Optimal)',
    color: '#06b6d4',
    accentColor: '#22d3ee',
  },
]

function DepartmentBlock({
  dept,
  isSelected,
  onSelect,
}: {
  dept: DepartmentTwinData
  isSelected: boolean
  onSelect: () => void
}) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current && dept.riskLevel === 'critical') {
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.05
      meshRef.current.scale.set(pulse, pulse, pulse)
    }
  })

  return (
    <group position={dept.position}>
      <mesh
        ref={meshRef}
        onClick={(e) => {
          e.stopPropagation()
          onSelect()
        }}
        castShadow
        receiveShadow
      >
        <boxGeometry args={dept.size} />
        <meshStandardMaterial
          color={dept.color}
          emissive={dept.color}
          emissiveIntensity={isSelected ? 0.65 : dept.riskLevel === 'critical' ? 0.45 : 0.2}
          roughness={0.2}
          metalness={0.4}
          transparent
          opacity={0.88}
        />
      </mesh>

      {/* Wireframe Outline */}
      <mesh>
        <boxGeometry args={[dept.size[0] * 1.02, dept.size[1] * 1.02, dept.size[2] * 1.02]} />
        <meshBasicMaterial color={isSelected ? '#ffffff' : dept.accentColor} wireframe transparent opacity={0.4} />
      </mesh>

      {/* 3D Label */}
      <Text
        position={[0, dept.size[1] / 2 + 0.25, 0]}
        fontSize={0.22}
        color="#ffffff"
        anchorX="center"
        anchorY="bottom"
      >
        {dept.code}
      </Text>

      {/* Floating Occupancy Badge */}
      {dept.riskLevel === 'critical' && (
        <Float speed={3} rotationIntensity={0} floatIntensity={0.2}>
          <mesh position={[0, dept.size[1] / 2 + 0.55, 0]}>
            <sphereGeometry args={[0.1, 12, 12]} />
            <meshStandardMaterial color="#ff0044" emissive="#ff0044" emissiveIntensity={1} />
          </mesh>
        </Float>
      )}
    </group>
  )
}

function HospitalFoundation() {
  return (
    <group position={[0, -0.05, 0]}>
      {/* Base Grid Plate */}
      <mesh receiveShadow>
        <boxGeometry args={[8.0, 0.1, 6.5]} />
        <meshStandardMaterial color="#0f172a" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* Corridor Crossings */}
      <mesh position={[0, 0.06, 0]}>
        <planeGeometry args={[7.2, 0.6]} />
        <meshBasicMaterial color="#334155" />
      </mesh>
      <mesh position={[0, 0.06, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.6, 5.8]} />
        <meshBasicMaterial color="#334155" />
      </mesh>

      {/* Central Atrium */}
      <mesh position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.6, 0.6, 0.4, 24]} />
        <meshStandardMaterial color="#38bdf8" transparent opacity={0.3} wireframe />
      </mesh>
    </group>
  )
}

export default function HospitalTwin3D({ onPostShiftForDept }: { onPostShiftForDept?: (deptName: string) => void }) {
  const [selectedDeptId, setSelectedDeptId] = useState<string>('er')
  const selectedDept = DEPARTMENTS.find((d) => d.id === selectedDeptId) || DEPARTMENTS[0]

  return (
    <div className="glass-card p-6 border border-glass-border space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Activity size={18} className="text-primary-light" />
            <h3 className="font-bold text-base text-text-primary">
              Hospital Digital Twin (Ward Bed Vacancy & Staffing Map)
            </h3>
          </div>
          <p className="text-xs text-text-muted mt-0.5">
            Real-time 3D telemetry of clinical wings, bed occupancy strain, and locum coverage deficits
          </p>
        </div>

        {/* Quick Department Chips */}
        <div className="flex flex-wrap gap-1.5">
          {DEPARTMENTS.map((dept) => (
            <button
              key={dept.id}
              onClick={() => {
                setSelectedDeptId(dept.id)
                sound.playClick()
              }}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all flex items-center gap-1.5 border ${
                selectedDeptId === dept.id
                  ? 'bg-primary/20 text-primary-light border-primary/50 shadow-sm'
                  : 'bg-surface-2/60 text-text-secondary border-glass-border hover:bg-surface-3'
              }`}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: dept.color }} />
              {dept.code}
            </button>
          ))}
        </div>
      </div>

      {/* 3D Viewport */}
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 relative h-[360px] bg-surface-base/80 rounded-2xl overflow-hidden border border-glass-border">
          <Canvas camera={{ position: [0, 5.5, 7.5], fov: 42 }}>
            <ambientLight intensity={0.6} />
            <directionalLight position={[10, 15, 8]} intensity={1.2} castShadow />
            <pointLight position={[-8, 6, -5]} intensity={0.6} color="#6366f1" />
            <HospitalFoundation />
            {DEPARTMENTS.map((dept) => (
              <DepartmentBlock
                key={dept.id}
                dept={dept}
                isSelected={selectedDeptId === dept.id}
                onSelect={() => {
                  setSelectedDeptId(dept.id)
                  sound.playClick()
                }}
              />
            ))}
            <OrbitControls
              enablePan={false}
              maxPolarAngle={Math.PI / 2.2}
              minPolarAngle={Math.PI / 4}
              maxDistance={14}
              minDistance={5}
            />
          </Canvas>

          {/* Telemetry Overlay */}
          <div className="absolute top-3 left-3 bg-surface-1/80 backdrop-blur-md px-3 py-2 rounded-xl border border-glass-border text-xs flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-text-secondary font-medium">Beds Monitored:</span>
            <span className="font-mono font-bold text-text-primary">113 Operational</span>
          </div>

          <div className="absolute bottom-3 right-3 text-[10px] text-text-muted bg-surface-1/70 backdrop-blur-xs px-2.5 py-1 rounded-md">
            Click department or drag to orbit 3D model
          </div>
        </div>

        {/* Selected Department Live Telemetry Card */}
        <div className="glass-card p-5 border border-glass-border flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-text-muted">
                Department Telemetry
              </span>
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                  selectedDept.riskLevel === 'critical'
                    ? 'bg-danger/20 text-danger border border-danger/40'
                    : selectedDept.riskLevel === 'warning'
                    ? 'bg-warning/20 text-warning border border-warning/40'
                    : 'bg-success/20 text-success border border-success/40'
                }`}
              >
                {selectedDept.riskLevel}
              </span>
            </div>

            <h4 className="text-base font-bold text-text-primary mb-1">{selectedDept.name}</h4>
            <p className="text-xs text-text-muted mb-4">Wing ID: {selectedDept.code}</p>

            <div className="space-y-3">
              {/* Occupancy Bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-text-secondary flex items-center gap-1.5">
                    <Bed size={13} /> Bed Occupancy
                  </span>
                  <span className="font-mono font-bold text-text-primary">
                    {selectedDept.bedsOccupied}/{selectedDept.bedsTotal} ({selectedDept.occupancy}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-surface-3 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${selectedDept.occupancy}%`,
                      backgroundColor: selectedDept.color,
                    }}
                  />
                </div>
              </div>

              {/* Doctors on duty & ratio */}
              <div className="p-3 rounded-xl bg-surface-2/60 border border-glass-border space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-text-muted flex items-center gap-1.5">
                    <Users size={13} /> Active Locums on Shift:
                  </span>
                  <span className="font-bold text-text-primary font-mono">{selectedDept.locumsOnDuty} Clinicians</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-muted flex items-center gap-1.5">
                    <Shield size={13} /> Bed-to-Doctor Ratio:
                  </span>
                  <span className="font-bold text-text-secondary font-mono">{selectedDept.doctorRatio}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-muted flex items-center gap-1.5">
                    <AlertTriangle size={13} className={selectedDept.predictedDeficit12h > 0 ? 'text-danger' : 'text-success'} />
                    12h Predicted Gap:
                  </span>
                  <span
                    className={`font-mono font-bold ${
                      selectedDept.predictedDeficit12h > 0 ? 'text-danger' : 'text-success'
                    }`}
                  >
                    {selectedDept.predictedDeficit12h > 0 ? `-${selectedDept.predictedDeficit12h} Doctors` : 'Fully Covered'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Action Button */}
          {selectedDept.predictedDeficit12h > 0 && (
            <button
              onClick={() => {
                sound.playSuccess()
                if (onPostShiftForDept) {
                  onPostShiftForDept(selectedDept.name)
                }
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-primary hover:bg-primary-dark text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-primary/25 cursor-pointer"
            >
              <PlusCircle size={15} />
              Auto-Post Surge Shift for {selectedDept.code}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
