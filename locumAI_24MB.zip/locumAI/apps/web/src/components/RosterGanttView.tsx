import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { sound } from '../services/sound'
import { ShieldCheck, AlertCircle, Clock, CheckCircle2, RefreshCw } from 'lucide-react'

interface GanttShift {
  id: string
  department: string
  locum: string
  role: string
  startHour: number // 0 - 24
  durationHours: number
  isNight: boolean
  reliability: number
  standby?: string
  hasConflict?: boolean
}

const INITIAL_GANTT_DATA: GanttShift[] = [
  {
    id: 'G-1',
    department: 'Emergency Medicine',
    locum: 'Dr. Priya Sharma',
    role: 'ER Specialist',
    startHour: 20,
    durationHours: 8,
    isNight: true,
    reliability: 0.94,
  },
  {
    id: 'G-2',
    department: 'ICU / Critical Care',
    locum: 'Dr. Arjun Mehta',
    role: 'Intensivist',
    startHour: 20,
    durationHours: 8,
    isNight: true,
    reliability: 0.81,
    standby: 'Dr. Kavita Nair (Standby)',
  },
  {
    id: 'G-3',
    department: 'Surgical OT (Anesthesia)',
    locum: 'Dr. Rajesh Patel',
    role: 'Consultant Anesthetist',
    startHour: 8,
    durationHours: 9,
    isNight: false,
    reliability: 0.86,
    standby: 'Dr. Sneha Roy (Standby)',
  },
  {
    id: 'G-4',
    department: 'Pediatrics OPD',
    locum: 'Dr. Ananya Desai',
    role: 'Pediatrician',
    startHour: 9,
    durationHours: 9,
    isNight: false,
    reliability: 0.96,
  },
  {
    id: 'G-5',
    department: 'Obstetrics & Gynae',
    locum: 'Dr. Vikram Rao',
    role: 'OB/GYN Specialist',
    startHour: 20,
    durationHours: 8,
    isNight: true,
    reliability: 0.82,
    standby: 'Dr. Pooja Reddy (Standby)',
  },
]

const HOURS = Array.from({ length: 25 }, (_, i) => i) // 0 to 24

export default function RosterGanttView() {
  const [shifts, setShifts] = useState<GanttShift[]>(INITIAL_GANTT_DATA)
  const [hoveredShiftId, setHoveredShiftId] = useState<string | null>(null)
  const [isSolving, setIsSolving] = useState(false)
  const [simulatedConflict, setSimulatedConflict] = useState(false)

  const toggleConflictSimulation = () => {
    sound.playClick()
    if (!simulatedConflict) {
      // Introduce an intentional fatigue rest conflict: Dr. Priya working OT at 09:00 (only 1h rest after night shift!)
      setShifts((prev) => [
        ...prev,
        {
          id: 'G-CONFLICT',
          department: 'Emergency Medicine',
          locum: 'Dr. Priya Sharma',
          role: 'ER Specialist',
          startHour: 8.5,
          durationHours: 6,
          isNight: false,
          reliability: 0.94,
          hasConflict: true,
        },
      ])
      setSimulatedConflict(true)
      sound.playAlert()
    } else {
      // Resolve conflict via CP-SAT
      setIsSolving(true)
      setTimeout(() => {
        setShifts(INITIAL_GANTT_DATA)
        setSimulatedConflict(false)
        setIsSolving(false)
        sound.playSuccess()
      }, 700)
    }
  }

  const hoveredShift = shifts.find((s) => s.id === hoveredShiftId)

  return (
    <div className="glass-card p-6 border border-glass-border space-y-5">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Clock size={18} className="text-primary-light" />
            <h3 className="font-bold text-base text-text-primary">
              24-Hour Clinician Roster Gantt Timeline
            </h3>
          </div>
          <p className="text-xs text-text-muted mt-0.5">
            Hourly department schedule with interactive rest-rule buffers and CP-SAT constraint validation
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleConflictSimulation}
            disabled={isSolving}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer border ${
              simulatedConflict
                ? 'bg-accent/20 text-accent border-accent/40 hover:bg-accent/30'
                : 'bg-danger/20 text-danger border-danger/40 hover:bg-danger/30'
            }`}
          >
            {isSolving ? (
              <>
                <RefreshCw size={13} className="animate-spin" />
                OR-Tools CP-SAT Re-solving...
              </>
            ) : simulatedConflict ? (
              <>
                <RefreshCw size={13} />
                Auto-Resolve with CP-SAT Solver
              </>
            ) : (
              <>
                <AlertCircle size={13} />
                Inject Rest-Rule Conflict Test
              </>
            )}
          </button>
        </div>
      </div>

      {/* Gantt Timeline Board */}
      <div className="overflow-x-auto pb-2">
        <div className="min-w-[800px] border border-glass-border rounded-2xl bg-surface-base/80 p-4 space-y-4">
          {/* Hour Header Bar */}
          <div className="grid grid-cols-24 gap-0 border-b border-glass-border pb-2 text-[10px] text-text-muted font-mono">
            {HOURS.slice(0, 24).map((h) => (
              <div key={h} className="text-center">
                {h % 4 === 0 ? `${h.toString().padStart(2, '0')}:00` : '·'}
              </div>
            ))}
          </div>

          {/* Department Swimlanes */}
          <div className="space-y-4">
            {['Emergency Medicine', 'ICU / Critical Care', 'Surgical OT (Anesthesia)', 'Pediatrics OPD', 'Obstetrics & Gynae'].map(
              (dept) => {
                const deptShifts = shifts.filter((s) => s.department === dept)
                return (
                  <div key={dept} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-text-secondary">{dept}</span>
                      <span className="text-[10px] text-text-muted">{deptShifts.length} Shift Assigned</span>
                    </div>

                    {/* Timeline Row */}
                    <div className="relative h-12 bg-surface-2/40 rounded-xl border border-glass-border/50 overflow-hidden">
                      {/* Grid guideline dashes */}
                      <div className="absolute inset-0 grid grid-cols-24 pointer-events-none opacity-10">
                        {HOURS.slice(0, 24).map((h) => (
                          <div key={h} className="border-r border-slate-400 h-full" />
                        ))}
                      </div>

                      {/* Shift Blocks */}
                      {deptShifts.map((shift) => {
                        // Calculate left percentage and width
                        const leftPct = (shift.startHour / 24) * 100
                        const widthPct = (shift.durationHours / 24) * 100

                        return (
                          <div
                            key={shift.id}
                            onMouseEnter={() => {
                              setHoveredShiftId(shift.id)
                              sound.playClick()
                            }}
                            onMouseLeave={() => setHoveredShiftId(null)}
                            className={`absolute top-1.5 h-9 rounded-lg px-2 flex items-center justify-between transition-all cursor-pointer shadow-sm text-xs border ${
                              shift.hasConflict
                                ? 'bg-danger/80 border-danger text-white animate-pulse'
                                : shift.isNight
                                ? 'bg-indigo-900/80 border-indigo-500 text-indigo-100 hover:bg-indigo-800'
                                : 'bg-primary/80 border-primary-light text-white hover:bg-primary'
                            }`}
                            style={{
                              left: `${leftPct}%`,
                              width: `${widthPct}%`,
                              minWidth: '110px',
                            }}
                          >
                            <div className="truncate">
                              <span className="font-bold truncate block">{shift.locum}</span>
                              <span className="text-[9px] opacity-80 block truncate">
                                {shift.isNight ? '🌙 Night' : '☀️ Day'} ({(shift.reliability * 100).toFixed(0)}% Bayes)
                              </span>
                            </div>

                            {shift.standby && (
                              <span className="shrink-0 text-[8px] bg-amber-500/20 text-amber-300 px-1 py-0.5 rounded border border-amber-400/30">
                                Standby
                              </span>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )
              }
            )}
          </div>
        </div>
      </div>

      {/* Hovered Shift Rest Buffer Explainer */}
      <AnimatePresence>
        {hoveredShift && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 5 }}
            className={`p-4 rounded-xl border text-xs flex flex-wrap items-center justify-between gap-3 ${
              hoveredShift.hasConflict
                ? 'bg-danger/10 border-danger/40 text-danger'
                : 'bg-surface-2 border-glass-border text-text-secondary'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {hoveredShift.hasConflict ? (
                <AlertCircle size={18} className="text-danger shrink-0" />
              ) : (
                <ShieldCheck size={18} className="text-success shrink-0" />
              )}
              <div>
                <span className="font-bold text-text-primary block">
                  {hoveredShift.locum} — {hoveredShift.department}
                </span>
                <span className="text-[11px] text-text-muted">
                  Timing: {hoveredShift.startHour}:00 to {(hoveredShift.startHour + hoveredShift.durationHours) % 24}:00 | Mandatory 11h Rest Window enforced after shift end
                </span>
              </div>
            </div>

            {hoveredShift.hasConflict ? (
              <span className="px-2.5 py-1 rounded-lg bg-danger/20 text-danger font-bold text-xs border border-danger/30">
                HARD SAFETY VIOLATION: &lt;11h Rest Window Breached
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-lg bg-success/20 text-success font-semibold text-xs border border-success/30 flex items-center gap-1">
                <CheckCircle2 size={13} />
                Fatigue Safety Rules Verified
              </span>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
