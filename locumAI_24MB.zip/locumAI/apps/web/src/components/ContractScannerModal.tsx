import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  FileText, X, AlertTriangle, ShieldCheck, CheckCircle2,
  AlertCircle, Sparkles, ArrowRight, ShieldAlert, Check
} from 'lucide-react'

interface ContractScannerModalProps {
  isOpen: boolean
  onClose: () => void
}

interface ClauseFlag {
  category: string
  severity: 'high' | 'medium' | 'low'
  clauseText: string
  riskExplanation: string
  recommendation: string
}

const DEFAULT_FLAGS: ClauseFlag[] = [
  {
    category: 'Non-Compete Geographical Restriction',
    severity: 'high',
    clauseText: 'The Locum Practitioner shall not engage in clinical services within a 15 km radius of the Facility for a duration of 12 months following completion of assignment.',
    riskExplanation: 'Excessive radius in dense metropolitan corridors. Effectively restrains physician practice in violation of Section 27 of the Indian Contract Act.',
    recommendation: 'Strike clause entirely or limit strictly to non-solicitation of active private patients within 2 km.'
  },
  {
    category: 'Payment Terms & Extended Withholding',
    severity: 'medium',
    clauseText: 'Facility reserves the unconditional right to withhold invoice disbursements up to 60 days pending internal administrative reconciliations.',
    riskExplanation: 'Violates standard 48-hour LocumIQ liquidity guarantee, subjecting clinician to cash flow distress.',
    recommendation: 'Replace with mandatory payment settlement within 5 business days of shift completion.'
  },
  {
    category: 'Tail Medical Malpractice Liability',
    severity: 'high',
    clauseText: 'Locum agrees to personally defend and indemnify the Facility against any malpractice allegations filed up to 3 years post-shift without facility tail insurance.',
    riskExplanation: 'Leaves provider exposed to delayed civil suits without institutional vicarious liability protection.',
    recommendation: 'Require Facility to provide comprehensive on-duty vicarious indemnity coverage.'
  }
]

export default function ContractScannerModal({ isOpen, onClose }: ContractScannerModalProps) {
  const [contractText, setContractText] = useState(
    'STANDARD LOCUM ENGAGEMENT AGREEMENT\n\n1. OBLIGATIONS: Provider shall render emergency services...\n2. RESTRICTIONS: The Locum Practitioner shall not engage in clinical services within a 15 km radius of the Facility for a duration of 12 months...\n3. DISBURSEMENTS: Facility reserves the unconditional right to withhold invoice disbursements up to 60 days...\n4. INDEMNITY: Locum agrees to personally defend and indemnify the Facility without facility tail insurance...'
  )
  const [isScanning, setIsScanning] = useState(false)
  const [flags, setFlags] = useState<ClauseFlag[]>(DEFAULT_FLAGS)

  if (!isOpen) return null

  const handleScan = () => {
    setIsScanning(true)
    setTimeout(() => {
      setIsScanning(false)
    }, 800)
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-4xl bg-surface-1 border border-primary/40 rounded-2xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-5 border-b border-glass-border flex items-center justify-between bg-surface-2/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-danger/20 text-danger">
                <FileText size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-text-primary">Locum Contract Legal Risk Scanner</h2>
                <p className="text-xs text-text-muted">
                  Automated clause extraction, predatory non-compete detection & indemnification audit
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-3 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-y-auto">
            {/* Left Col: Contract Text Editor */}
            <div className="space-y-4 flex flex-col">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-text-secondary">Agreement Text / Labeled Clauses</label>
                <span className="text-[10px] font-mono text-text-muted">BM25 + Dense Semantic Retrieval</span>
              </div>

              <textarea
                value={contractText}
                onChange={e => setContractText(e.target.value)}
                rows={12}
                className="flex-1 w-full bg-surface-2 border border-glass-border rounded-xl p-3.5 text-xs text-text-primary font-mono focus:outline-none focus:border-primary resize-none leading-relaxed"
              />

              <button
                onClick={handleScan}
                disabled={isScanning}
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-primary hover:bg-primary-hover text-white shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles size={15} className={isScanning ? 'animate-spin' : ''} />
                {isScanning ? 'Extracting & Auditing Clauses…' : 'Re-Scan Contract Text'}
              </button>

              {/* Evaluation Benchmarks */}
              <div className="p-3.5 rounded-xl bg-surface-2 border border-glass-border space-y-1.5">
                <span className="text-[10px] uppercase font-mono font-bold text-text-muted">
                  Model Evaluation Benchmarks (LocumLegal-500 Dataset)
                </span>
                <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                  <div className="bg-surface-3/50 p-2 rounded-lg">
                    <span className="text-[10px] text-text-muted block">Precision</span>
                    <span className="font-bold text-accent">88.4%</span>
                  </div>
                  <div className="bg-surface-3/50 p-2 rounded-lg">
                    <span className="text-[10px] text-text-muted block">Recall</span>
                    <span className="font-bold text-primary-light">82.6%</span>
                  </div>
                  <div className="bg-surface-3/50 p-2 rounded-lg">
                    <span className="text-[10px] text-text-muted block">Latency</span>
                    <span className="font-bold text-text-primary">38 ms</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Col: Extracted Flagged Risks */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-text-primary flex items-center gap-1.5">
                  <ShieldAlert size={14} className="text-danger" /> Flagged Predatory Clauses ({flags.length})
                </span>
                <span className="text-[10px] bg-danger/15 text-danger font-bold px-2 py-0.5 rounded">
                  Status: Unsafe to Sign
                </span>
              </div>

              <div className="space-y-3">
                {flags.map((flag, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-surface-2 border border-glass-border space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-text-primary">{flag.category}</span>
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          flag.severity === 'high'
                            ? 'bg-danger/20 text-danger border border-danger/30'
                            : 'bg-warning/20 text-warning border border-warning/30'
                        }`}
                      >
                        {flag.severity} Risk
                      </span>
                    </div>

                    <div className="p-2.5 rounded-lg bg-surface-0/60 font-mono text-[11px] text-text-secondary border-l-2 border-danger/60 italic">
                      "{flag.clauseText}"
                    </div>

                    <p className="text-[11px] text-text-muted leading-relaxed">
                      <strong>Risk:</strong> {flag.riskExplanation}
                    </p>

                    <div className="p-2.5 rounded-lg bg-accent/10 border border-accent/20 text-[11px] text-accent flex items-start gap-1.5">
                      <Check size={13} className="shrink-0 mt-0.5" />
                      <span><strong>Fix:</strong> {flag.recommendation}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
