import React, { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Stars, Float } from '@react-three/drei'
import * as THREE from 'three'

function NetworkGlobe() {
  const globeRef = useRef<THREE.Group>(null)
  const particlesRef = useRef<THREE.Points>(null)

  // Generate hospital nodes on sphere
  const nodes = useMemo(() => {
    const pts = []
    const count = 48
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count)
      const theta = Math.sqrt(count * Math.PI) * phi
      const r = 2.4
      pts.push(new THREE.Vector3(
        r * Math.cos(theta) * Math.sin(phi),
        r * Math.sin(theta) * Math.sin(phi),
        r * Math.cos(phi)
      ))
    }
    return pts
  }, [])

  // Floating pulses between nodes
  const particleGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry()
    const pos = new Float32Array(nodes.length * 3)
    nodes.forEach((v, i) => {
      pos[i * 3] = v.x
      pos[i * 3 + 1] = v.y
      pos[i * 3 + 2] = v.z
    })
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    return geo
  }, [nodes])

  useFrame((state) => {
    if (globeRef.current) {
      globeRef.current.rotation.y = state.clock.elapsedTime * 0.12
      globeRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.05) * 0.1
    }
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.12
    }
  })

  return (
    <group ref={globeRef}>
      {/* Central Wireframe Sphere */}
      <mesh>
        <sphereGeometry args={[2.38, 24, 24]} />
        <meshStandardMaterial
          color="#4f46e5"
          wireframe
          transparent
          opacity={0.18}
          roughness={0.2}
        />
      </mesh>

      {/* Inner Glowing Core */}
      <mesh>
        <sphereGeometry args={[1.5, 32, 32]} />
        <meshStandardMaterial
          color="#06b6d4"
          emissive="#6366f1"
          emissiveIntensity={0.4}
          transparent
          opacity={0.25}
        />
      </mesh>

      {/* Hospital Nodes */}
      <points ref={particlesRef} geometry={particleGeo}>
        <pointsMaterial
          size={0.14}
          color="#22d3ee"
          transparent
          opacity={0.85}
          sizeAttenuation
        />
      </points>

      {/* Surrounding Ambient Floating Nodes */}
      {nodes.slice(0, 12).map((node, i) => (
        <Float key={i} speed={2} rotationIntensity={0.2} floatIntensity={0.3}>
          <mesh position={[node.x * 1.05, node.y * 1.05, node.z * 1.05]}>
            <sphereGeometry args={[0.06, 12, 12]} />
            <meshStandardMaterial
              color="#10b981"
              emissive="#10b981"
              emissiveIntensity={0.8}
            />
          </mesh>
        </Float>
      ))}
    </group>
  )
}

export default function MedicalNetwork3D() {
  return (
    <div className="w-full h-full min-h-[380px] relative rounded-2xl overflow-hidden">
      <Canvas camera={{ position: [0, 0, 6], fov: 45 }}>
        <ambientLight intensity={0.4} />
        <pointLight position={[10, 10, 10]} intensity={1.2} color="#6366f1" />
        <pointLight position={[-10, -10, -5]} intensity={0.8} color="#06b6d4" />
        <Stars radius={25} depth={50} count={1200} factor={3} saturation={0.5} fade speed={1} />
        <NetworkGlobe />
        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
      </Canvas>

      {/* Overlay Badge */}
      <div className="absolute bottom-3 left-3 bg-surface-1/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-glass-border text-[11px] font-mono text-text-secondary pointer-events-none flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-accent animate-ping" />
        <span>Live 3D Staffing Exchange Topology</span>
      </div>
    </div>
  )
}
