// Web Audio API pure programmatic sound synthesizer for LocumIQ
// 100% free, zero external sound files/dependencies.

class SoundEngine {
  private ctx: AudioContext | null = null
  private enabled: boolean = true

  constructor() {
    // Check saved preference
    const saved = localStorage.getItem('locumiq_sound_enabled')
    if (saved !== null) {
      this.enabled = saved === 'true'
    }
  }

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      if (AudioCtx) {
        this.ctx = new AudioCtx()
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume()
    }
  }

  public isEnabled(): boolean {
    return this.enabled
  }

  public toggle(): boolean {
    this.enabled = !this.enabled
    localStorage.setItem('locumiq_sound_enabled', String(this.enabled))
    if (this.enabled) {
      this.playSuccess()
    }
    return this.enabled
  }

  // Crisp micro-haptic click (800Hz -> 200Hz in 15ms)
  public playClick() {
    if (!this.enabled) return
    try {
      this.initContext()
      if (!this.ctx) return
      const osc = this.ctx.createOscillator()
      const gain = this.ctx.createGain()

      osc.type = 'sine'
      const t = this.ctx.currentTime
      osc.frequency.setValueAtTime(800, t)
      osc.frequency.exponentialRampToValueAtTime(150, t + 0.02)

      gain.gain.setValueAtTime(0.08, t)
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.02)

      osc.connect(gain)
      gain.connect(this.ctx.destination)

      osc.start(t)
      osc.stop(t + 0.025)
    } catch {
      // AudioContext muted/unsupported
    }
  }

  // Sci-fi arpeggio completion chime (C5, E5, G5, C6)
  public playSuccess() {
    if (!this.enabled) return
    try {
      this.initContext()
      if (!this.ctx) return

      const freqs = [523.25, 659.25, 783.99, 1046.50]
      const t = this.ctx.currentTime

      freqs.forEach((f, idx) => {
        if (!this.ctx) return
        const osc = this.ctx.createOscillator()
        const gain = this.ctx.createGain()

        osc.type = 'triangle'
        osc.frequency.setValueAtTime(f, t + idx * 0.05)

        const startT = t + idx * 0.05
        gain.gain.setValueAtTime(0.001, startT)
        gain.gain.linearRampToValueAtTime(0.09, startT + 0.01)
        gain.gain.exponentialRampToValueAtTime(0.0001, startT + 0.25)

        osc.connect(gain)
        gain.connect(this.ctx.destination)

        osc.start(startT)
        osc.stop(startT + 0.26)
      })
    } catch {
      // Ignore audio error
    }
  }

  // Urgent harmonic safety alert pulse
  public playAlert() {
    if (!this.enabled) return
    try {
      this.initContext()
      if (!this.ctx) return
      const t = this.ctx.currentTime

      const osc1 = this.ctx.createOscillator()
      const osc2 = this.ctx.createOscillator()
      const gain = this.ctx.createGain()

      osc1.type = 'sawtooth'
      osc2.type = 'square'

      osc1.frequency.setValueAtTime(440, t)
      osc2.frequency.setValueAtTime(446, t) // slight detune creates tension beat

      gain.gain.setValueAtTime(0.08, t)
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18)

      osc1.connect(gain)
      osc2.connect(gain)
      gain.connect(this.ctx.destination)

      osc1.start(t)
      osc2.start(t)
      osc1.stop(t + 0.2)
      osc2.stop(t + 0.2)
    } catch {
      // Ignore audio error
    }
  }

  // Smooth filter sweep for mode switches or slide interactions
  public playSwitch() {
    if (!this.enabled) return
    try {
      this.initContext()
      if (!this.ctx) return
      const t = this.ctx.currentTime
      const osc = this.ctx.createOscillator()
      const gain = this.ctx.createGain()

      osc.type = 'sine'
      osc.frequency.setValueAtTime(320, t)
      osc.frequency.exponentialRampToValueAtTime(640, t + 0.04)

      gain.gain.setValueAtTime(0.06, t)
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04)

      osc.connect(gain)
      gain.connect(this.ctx.destination)

      osc.start(t)
      osc.stop(t + 0.05)
    } catch {
      // Ignore
    }
  }
}

export const sound = new SoundEngine()
